// Meeting home: overview, next steps, and the way into the notes.
import SwiftUI
import Combine
import UniformTypeIdentifiers

// MARK: - Meeting

struct ContentView: View {
    @Environment(MeetingStore.self) private var store
    @State private var pageScroll = SpotlightPageScroll()
    @State private var spotlight = PeopleSpotlightState()
    @State private var note: Note?
    @State private var library = false
    @State private var sidebar = false
    @State private var transcript = false
    @State private var speakers = false
    @State private var replace = false
    @State private var arrival = false
    @State private var notesSection: NoteSection?
    @State private var pressedResourceID: String?
    private let clock = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    var body: some View {
        RecordingSidebarContainer(isExpanded: $sidebar) {
            RecordingsSidebar(close: { sidebar = false }, importRecording: {
                sidebar = false
                store.importError = nil
                library = true
            })
        } content: {
            meetingPage
        }
        .foregroundStyle(ink).tint(appAccent)
        .overlay(alignment: .top) { if let toast = store.toast { Text(toast).font(.footnote.weight(.medium)).padding(16).background(.regularMaterial, in: Capsule()).padding(.top, 60).allowsHitTesting(false) } }
        .onReceive(clock) { _ in store.tick() }
        .task { spotlight.reconcile(store.otherPeople); arrival = store.hasTimeline && !store.complete && !ProcessInfo.processInfo.arguments.contains("-preview-time") }
        .onChange(of: store.package?.key) { _, _ in spotlight = PeopleSpotlightState(); spotlight.reconcile(store.otherPeople); note = nil; notesSection = nil; transcript = false; arrival = false; sidebar = false }
        .onChange(of: store.otherPeople.map(\.id)) { _, _ in spotlight.reconcile(store.otherPeople) }
        .sheet(item: $note, onDismiss: store.stop) { ReviewPage(note: $0) }
        .sheet(item: $notesSection, onDismiss: store.stop) { NotesSectionPage(section: $0) }
        .sheet(isPresented: $library) { LibraryPage() }
        .sheet(isPresented: $transcript, onDismiss: store.stop) { TranscriptPage() }
        .sheet(isPresented: $speakers, onDismiss: store.stop) { SpeakersPage() }
        .sheet(isPresented: $replace) { ReplacePage() }
        .fullScreenCover(isPresented: $arrival) { ArrivalPage() }
    }
    private var meetingPage: some View {
        NavigationStack {
            Group {
                if let error = store.loadError {
                    ContentUnavailableView("Recording couldn’t open", systemImage: "doc.badge.ellipsis", description: Text(error))
                } else {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 20) {
                            heading
                            PeopleSpotlight(selection: $spotlight, people: store.otherPeople, pageScroll: pageScroll)
                                .id("peopleSpotlight")
                            Divider().accessibilityHidden(true)
                            overview
                            nextSteps
                            recordingResources
                            if !(store.package?.warnings.isEmpty ?? true) {
                                DisclosureGroup("Recording details") { ForEach(store.package?.warnings ?? [], id: \.self) { Text($0).font(.footnote).foregroundStyle(.secondary).padding(.top, 8) } }.font(.subheadline).card()
                            }
                        }.padding(20).id("meetingTop")
                            .background { SpotlightPageScrollReader(pageScroll: pageScroll) }
                    }
                    // Each recording gets its own scroll and People layout. Keep
                    // the native navigation bar mounted while replacing the page.
                    .id(store.package?.key)
                    .scrollIndicators(.hidden)
                }
            }
            .background(paper)
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { navigation }
        }
    }
    @ToolbarContentBuilder private var navigation: some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            Button("Recordings", systemImage: "sidebar.left") {
                store.stop(); store.haptic(); sidebar = true
            }
            .tint(ink).accessibilityIdentifier("openRecordingsSidebar")
        }
        ToolbarItem(placement: .principal) {
            Text("Pocket").font(.system(.title2, design: .serif, weight: .medium))
                .foregroundStyle(ink)
        }
        ToolbarItem(placement: .topBarTrailing) {
            MeetingOptionsMenu(
                hasTimeline: store.hasTimeline,
                complete: store.complete,
                replay: {
                    store.restart(); spotlight = PeopleSpotlightState(); spotlight.reconcile(store.otherPeople); arrival = true
                },
                skip: { store.stop(); store.skip(); store.haptic() },
                speakers: { speakers = true },
                replace: { replace = true }
            ).equatable()
        }
    }
    private var heading: some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 5) {
                if let date = store.recordingDate { eyebrow(date.formatted(.dateTime.month(.wide).day()).uppercased()) }
                let minutes = Int(ceil(store.recordingDuration / 60))
                Text("\(minutes) \(minutes == 1 ? "minute" : "minutes")")
                    .font(.system(.caption, weight: .medium).width(.expanded))
                    .foregroundStyle(.secondary)
            }
            Text(store.package?.calendar?.event.title ?? store.title).font(.system(.largeTitle, weight: .semibold).width(.expanded)).tracking(-1).fixedSize(horizontal: false, vertical: true)

        }
    }
    private var overview: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Top priority").font(.headline).accessibilityAddTraits(.isHeader)
            if let answer = store.priorityDateAnswer {
                PriorityDateOverview(answer: answer)
            } else {
                ordinaryOverview
            }
        }
    }
    private var ordinaryOverview: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Spacer()
                    if let item = store.overviewNote, store.isPrivate(item) {
                        Label("Private", systemImage: "lock").font(.caption).foregroundStyle(.secondary)
                    }
                }
                if let item = store.overviewNote {
                    Text(store.text(item)).font(.system(.title2, design: .serif)).lineSpacing(3).fixedSize(horizontal: false, vertical: true)
                } else if !store.complete {
                    WaitingText(text: store.stage, active: store.running)
                        .font(.system(.title3, design: .serif))
                        .frame(maxWidth: .infinity, minHeight: 84, alignment: .topLeading)
                        .accessibilityValue("\(Int(store.elapsed / max(1, store.duration) * 100)) percent")
                } else {
                    Text("Room for the important things.")
                        .font(.system(.title2, design: .serif)).frame(maxWidth: .infinity, minHeight: 84, alignment: .topLeading)
                }
                if !store.complete, store.overviewNote != nil {
                    WaitingText(text: store.stage, active: store.running)
                        .font(.system(.title3, design: .serif))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }.padding(22)
            if let item = store.overviewNote {
                ReviewHintCard(note: item) { note = item }.padding(9).accessibilityIdentifier("leadReview")
            }
        }
        .background {
            RoundedRectangle(cornerRadius: 29, style: .continuous).fill(.white)
                .overlay {
                    if !store.complete { ProcessingBorder(running: store.running) }
                }
        }
    }
    private var nextSteps: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text("Next steps").font(.headline)
                Spacer()
                Button("See all") { notesSection = .nextSteps }
                    .font(.subheadline).frame(minWidth: 44, minHeight: 44)
            }
            if store.actions.isEmpty {
                Text(store.complete ? "No next steps in this recording." : "Next steps will appear here.").font(.subheadline).foregroundStyle(.secondary).frame(maxWidth: .infinity, minHeight: 65, alignment: .leading).padding(.horizontal, 16).background(.white, in: .rect(cornerRadius: 24))
            } else {
                VStack(spacing: 14) {
                    ForEach(store.actions.prefix(3)) { item in Button { note = item } label: { NoteRow(note: item, compact: true) }.buttonStyle(.plain) }
                }
            }
        }
    }
    private var recordingResources: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Notes & recording")
                .font(.headline).foregroundStyle(ink)
                .accessibilityAddTraits(.isHeader)
            VStack(spacing: 0) {
                ForEach(Array(NoteSection.allCases.enumerated()), id: \.element.id) { index, section in
                    Button { notesSection = section } label: {
                        resourceRow(section.rawValue, symbol: section.symbol)
                    }
                    .buttonStyle(RecordingResourceButtonStyle(roundsTop: index == 0) { updateResourcePress(section.id, pressed: $0) })
                    let nextID = index + 1 < NoteSection.allCases.count ? NoteSection.allCases[index + 1].id : "Meeting Transcript"
                    Divider().overlay(ink.opacity(0.025)).padding(.leading, 58).padding(.trailing, 20)
                        .opacity(pressedResourceID == section.id || pressedResourceID == nextID ? 0 : 1)
                        .accessibilityHidden(true)
                }
                Button { transcript = true } label: {
                    resourceRow("Meeting Transcript", symbol: "waveform")
                }
                .buttonStyle(RecordingResourceButtonStyle(roundsBottom: true) { updateResourcePress("Meeting Transcript", pressed: $0) })
            }
            .buttonBorderShape(.roundedRectangle(radius: 0))
            .background(.white, in: .rect(cornerRadius: 29))
            .clipShape(.rect(cornerRadius: 29))
        }
    }
    private func updateResourcePress(_ id: String, pressed: Bool) {
        if pressed { pressedResourceID = id }
        else if pressedResourceID == id { pressedResourceID = nil }
    }
    private func resourceRow(_ title: String, symbol: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: symbol).font(.system(size: 17, weight: .medium))
                .foregroundStyle(ink.opacity(0.7))
                .frame(width: 26, height: 32)
                .accessibilityHidden(true)
            Text(title).font(.body.weight(.medium)).foregroundStyle(ink)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 8)
            Image(systemName: "chevron.right").font(.caption.weight(.semibold))
                .foregroundStyle(.tertiary).accessibilityHidden(true)
        }
        .padding(.horizontal, 20).padding(.vertical, 16)
        .frame(maxWidth: .infinity, minHeight: 64, alignment: .leading)
        .contentShape(Rectangle())
    }
}

// MARK: - Resource rows

private struct RecordingResourceButtonStyle: ButtonStyle {
    var roundsTop = false
    var roundsBottom = false
    let onPressChanged: (Bool) -> Void

    func makeBody(configuration: Configuration) -> some View {
        let shape = UnevenRoundedRectangle(
            topLeadingRadius: roundsTop ? 29 : 0,
            bottomLeadingRadius: roundsBottom ? 29 : 0,
            bottomTrailingRadius: roundsBottom ? 29 : 0,
            topTrailingRadius: roundsTop ? 29 : 0,
            style: .continuous
        )
        return configuration.label
            .background(configuration.isPressed ? Color(hex: 0xDFE1E4) : .clear, in: shape)
            .contentShape([.interaction, .hoverEffect], shape)
            .clipShape(shape)
            .onChange(of: configuration.isPressed) { _, pressed in onPressChanged(pressed) }
            .onDisappear { onPressChanged(false) }
    }
}

// MARK: - Notes list

enum NoteSection: String, CaseIterable, Identifiable {
    case summary = "Summary"
    case decisions = "Decisions"
    case nextSteps = "Next steps"

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .summary: "text.alignleft"
        case .decisions: "checklist"
        case .nextSteps: "checkmark.circle"
        }
    }
    func notes(in file: NotesFile?) -> [Note] {
        switch self {
        case .summary: file?.summary ?? []
        case .decisions: file?.decisions ?? []
        case .nextSteps: file?.actionItems ?? []
        }
    }
}

struct NotesSectionPage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let section: NoteSection
    @State private var note: Note?
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 14) {
                    let items = section.notes(in: store.notes).filter { store.available($0.id) }
                    if items.isEmpty {
                        ContentUnavailableView(store.complete ? "No \(section.rawValue.lowercased())" : "Preparing \(section.rawValue.lowercased())",
                                               systemImage: section.symbol,
                                               description: Text(store.complete ? "This recording has no notes in this section." : "Complete notes appear here as they’re ready."))
                    }
                    ForEach(items) { item in
                        Button { note = item } label: { NoteRow(note: item) }.buttonStyle(.plain)
                    }
                }.padding(20)
            }.background(paper).navigationTitle(section.rawValue).navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { SheetDoneButton { dismiss() } } }
                .sheet(item: $note, onDismiss: store.stop) { ReviewPage(note: $0) }
        }.tint(appAccent).presentationDragIndicator(.visible)
    }
}

// MARK: - Shared controls

func eyebrow(_ text: String) -> some View {
    Text(text)
        .font(.system(size: 10, weight: .semibold).width(.expanded))
        .tracking(1.2)
        .foregroundStyle(.secondary)
}

extension View {
    func card() -> some View {
        padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.white, in: .rect(cornerRadius: 26))
    }
    func primaryPill() -> some View {
        font(.subheadline.weight(.semibold))
            .padding(17)
            .frame(maxWidth: .infinity)
            .background(ink, in: Capsule())
            .foregroundStyle(.white)
    }
}

struct Avatar: View {
    let person: Person
    var size: CGFloat = 48
    var body: some View {
        Text(person.initials)
            .font(.system(size: size * 0.29, weight: .medium, design: .rounded))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(person.tint.gradient, in: Circle())
            .accessibilityLabel(person.name)
    }
}

// MARK: - Note rows

struct NoteRow: View {
    @Environment(MeetingStore.self) private var store
    let note: Note
    var compact = false
    private var hasReviewHint: Bool {
        !store.state.excluded.contains(note.id) && !store.state.reviewed.contains(note.id) && !store.flags(note).isEmpty
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 10) {
                if store.section(note) == "Next step" {
                    HStack(alignment: .firstTextBaseline) {
                        Text(store.owner(note)).font(.subheadline.weight(.semibold))
                        Spacer()
                        if !store.due(note).isEmpty { Text(displayDate(store.due(note))).font(.caption).foregroundStyle(.secondary) }
                    }
                }
                Text(store.text(note)).font(.body).foregroundStyle(ink).multilineTextAlignment(.leading).lineLimit(compact ? 2 : nil)
                if store.isPrivate(note) && hasReviewHint { Label("Private", systemImage: "lock.fill").font(.caption).foregroundStyle(.secondary) }
            }.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            if hasReviewHint {
                // The surrounding row is already a button; keep the inset free of nested controls.
                ReviewHintContent(note: note).padding(9)
            } else {
                HStack(spacing: 5) {
                    if store.state.excluded.contains(note.id) {
                        Label("Excluded · tap to restore", systemImage: "minus.circle")
                    } else if store.isPrivate(note) {
                        Label("Private", systemImage: "lock.fill")
                    } else if store.state.reviewed.contains(note.id) {
                        Label("Reviewed", systemImage: "checkmark.circle")
                    } else { Text("Not reviewed") }
                    Spacer()
                    Image(systemName: "chevron.right").font(.caption2.weight(.semibold))
                }.font(.caption).foregroundStyle(.secondary).padding(.horizontal, 20).padding(.bottom, 18)
            }
        }.background(.white, in: .rect(cornerRadius: 29))
            .opacity(store.state.excluded.contains(note.id) ? 0.55 : 1)
    }
}

// MARK: - Source excerpts

struct EvidenceCard: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    let segment: Segment
    var recipient: Person? = nil
    var allowsReply = true
    @State private var reply: ReplySeed?
    var body: some View {
        if allowsReply {
            excerpt
                .simultaneousGesture(DragGesture(minimumDistance: 30).onEnded { value in
                    if abs(value.translation.width) > 65 && abs(value.translation.width) > abs(value.translation.height) * 1.5 { reply = store.replySeed(for: segment) }
                })
                .accessibilityAction(named: "Draft reply") { reply = store.replySeed(for: segment) }
                .sheet(item: $reply, onDismiss: store.stop) { ReplyDraftPage(seed: $0, recipient: recipient) }
        } else {
            excerpt
        }
    }
    private var excerpt: some View {
        VStack(alignment: .leading, spacing: 16) {
            SourceExcerptHeader(segment: segment, showsPlayback: false)
            Text("“\(segment.text)”").font(.system(.body, design: .serif)).lineSpacing(3).fixedSize(horizontal: false, vertical: true)
            let uncertain = (segment.words ?? []).filter { ($0.confidence ?? 1) < 0.6 || !($0.alternatives ?? []).isEmpty }
            if !uncertain.isEmpty { Text("Unclear: " + uncertain.map { word in ([word.text] + (word.alternatives ?? []).map(\.text)).joined(separator: " / ") }.joined(separator: "; ")).font(.caption).foregroundStyle(.secondary) }
            if allowsReply && !store.canDraftSource(segment) {
                Label("Private or excluded · kept out of replies", systemImage: "lock").font(.caption).foregroundStyle(.secondary)
            }
            if store.package?.audioURL == nil { Text("Audio not included · you can still read and check this excerpt.").font(.caption).foregroundStyle(.secondary) }
            if dynamicTypeSize.isAccessibilitySize {
                VStack(spacing: 12) { sourceActions }
            } else {
                HStack(spacing: 12) { sourceActions }
            }
        }.padding(20).background(.white, in: .rect(cornerRadius: 26))
    }
    @ViewBuilder private var sourceActions: some View {
        let isPlaying = store.playingID == segment.id
        SourceActionButton(title: isPlaying ? "Pause" : "Play", symbol: isPlaying ? "pause.fill" : "play.fill") {
            store.haptic(); store.play(segment)
        }
        .disabled(store.package?.audioURL == nil)
        .accessibilityHint(isPlaying ? "Pause this source moment." : "Play \(Int(ceil(segment.end - segment.start))) seconds of the original recording.")
        if allowsReply && store.canDraftSource(segment) {
            SourceActionButton(title: "Draft reply", symbol: "arrowshape.turn.up.left.fill") {
                store.haptic(); store.stop(); reply = store.replySeed(for: segment)
            }
            .accessibilityHint("Use this excerpt in a reply. You can also swipe the card horizontally.")
        }
    }
}

// MARK: - Review cues

struct ReviewHintCard: View {
    let note: Note
    let action: () -> Void
    var body: some View {
        Button(action: action) { ReviewHintContent(note: note) }
            .buttonStyle(.plain)
            .accessibilityHint("Open the explanation and review the source.")
    }
}

/// A quiet entry point; explanations and evidence belong in the review sheet.
struct ReviewHintContent: View {
    @Environment(MeetingStore.self) private var store
    let note: Note
    var body: some View {
        let reviewed = store.state.reviewed.contains(note.id)
        let flag = store.flags(note).first
        HStack(spacing: 10) {
            ReviewCheckSymbol(flag: flag, reviewed: reviewed)
            Text(reviewed ? "Reviewed by you" : flag?.title ?? "Check this note")
                .font(.subheadline.weight(.semibold))
                .multilineTextAlignment(.leading)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold)).opacity(0.65)
                .accessibilityHidden(true)
        }
        .padding(.horizontal, 17).padding(.vertical, 12)
        .frame(maxWidth: .infinity, minHeight: 48, alignment: .leading)
        .foregroundStyle(reviewed ? Color(hex: 0x47613C) : reviewAccent)
        .background(reviewed ? sage.opacity(0.65) : appAccent.opacity(0.08), in: .rect(cornerRadius: 20))
    }
}

/// Use distinct, quiet cues for the kind of source check being requested.
struct ReviewCheckSymbol: View {
    let flag: ReviewFlag?
    var reviewed = false
    private var symbol: String {
        if reviewed { return "checkmark.circle" }
        switch flag?.id.split(separator: ":").last {
        case "later":
            if #available(iOS 27.0, *) { return "square.grid.month" }
            return "calendar"
        case "owner": return "person.3.sequence.fill"
        case "confidence", "words": return "text.quote"
        case "privacy": return "lock"
        case "source": return "doc.text.magnifyingglass"
        default: return "text.badge.checkmark"
        }
    }
    var body: some View {
        Image(systemName: symbol).symbolRenderingMode(.hierarchical)
            .font(.body.weight(.medium)).frame(width: 24)
            .accessibilityHidden(true)
    }
}

// MARK: - Dates and confirmation

func displayDate(_ value: String) -> String {
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.dateFormat = "yyyy-MM-dd"
    guard let date = formatter.date(from: value) else { return value }
    return date.formatted(.dateTime.month(.abbreviated).day())
}

/// Use the system-provided confirmation appearance where supported.
struct SheetDoneButton: View {
    let action: () -> Void
    var body: some View {
        if #available(iOS 26.0, *) {
            Button(role: .confirm, action: action)
                .tint(appAccent)
                .accessibilityLabel("Done")
        } else {
            Button(action: action) { Label("Done", systemImage: "checkmark") }
                .tint(appAccent)
                .labelStyle(.iconOnly)
                .accessibilityLabel("Done")
        }
    }
}

/// Keep the native menu independent of 10 Hz arrival updates. Its content only
/// changes when the recording's available actions change, never on each tick.
private struct MeetingOptionsMenu: View, Equatable {
    let hasTimeline: Bool
    let complete: Bool
    let replay: () -> Void
    let skip: () -> Void
    let speakers: () -> Void
    let replace: () -> Void

    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.hasTimeline == rhs.hasTimeline && lhs.complete == rhs.complete
    }
    var body: some View {
        Menu {
            if hasTimeline {
                Button("Replay arrival", systemImage: "arrow.counterclockwise", action: replay)
                if !complete {
                    Button("Skip to end", systemImage: "forward.end", action: skip)
                        .accessibilityIdentifier("skipArrivalToEnd")
                }
            }
            Button("Manage speakers", systemImage: "person.2", action: speakers)
            Button("Replace across notes", systemImage: "text.badge.checkmark", action: replace)
        } label: {
            Image(systemName: "ellipsis").font(.body.weight(.semibold)).frame(width: 22, height: 22)
        }
        .tint(ink).accessibilityLabel("Meeting options")
    }
}
