import SwiftUI

// MARK: - Sidebar

/// Adapts the supplied XStyleSideBar's page-reveal motion. Opening is button-only
/// so the People carousel, vertical drawer, and source-card swipes keep ownership.
struct RecordingSidebarContainer<Sidebar: View, Content: View>: View {
    @Binding var isExpanded: Bool
    @ViewBuilder let sidebar: () -> Sidebar
    @ViewBuilder let content: () -> Content
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        GeometryReader { geometry in
            let width = min(320, geometry.size.width * 0.82)
            let motion: Animation? = reduceMotion ? nil : .easeInOut(duration: 0.28)
            ZStack(alignment: .leading) {
                sidebar()
                    .frame(width: width, height: geometry.size.height)
                    .animation(motion) { menu in
                        menu.opacity(isExpanded ? 1 : 0)
                            .scaleEffect(reduceMotion || isExpanded ? 1 : 0.96, anchor: .leading)
                    }
                    .allowsHitTesting(isExpanded)
                    .accessibilityHidden(!isExpanded)

                content()
                    .allowsHitTesting(!isExpanded)
                    .accessibilityHidden(isExpanded)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .background(paper.ignoresSafeArea())
                    // The page, dimming layer, corners, and shadow use one animated
                    // value, without passing the animation into the recording layout.
                    .animation(motion) { page in
                        page.modifier(SidebarPagePresentation(
                            progress: isExpanded ? 1 : 0,
                            width: width,
                            isExpanded: isExpanded,
                            close: { isExpanded = false }
                        ))
                    }
            }
        }
        .background(paper.ignoresSafeArea())
        .accessibilityAction(.escape) { isExpanded = false }
    }
}

private struct SidebarPagePresentation: AnimatableModifier {
    var progress: CGFloat
    let width: CGFloat
    let isExpanded: Bool
    let close: () -> Void

    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }

    func body(content: Content) -> some View {
        // Progress is already interpolated. These effects must render that exact
        // frame, not start a second implicit animation toward every new value.
        content.transaction { transaction in
            transaction.animation = nil
            transaction.disablesAnimations = true
        } body: { page in
            page.overlay {
                Button(action: close) {
                    Color.black.opacity(0.07 * progress).ignoresSafeArea()
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .allowsHitTesting(isExpanded)
                .accessibilityHidden(!isExpanded)
                .accessibilityLabel("Close recordings")
            }
            .mask { RoundedRectangle(cornerRadius: 30 * progress, style: .continuous).ignoresSafeArea() }
            // Move one composited page instead of separately moving its dim layer.
            .compositingGroup()
            .shadow(color: .black.opacity(0.08 * progress), radius: 12, x: -4 * progress)
            .offset(x: width * progress)
        }
    }
}

// MARK: - Recordings

struct RecordingsSidebar: View {
    @Environment(MeetingStore.self) private var store
    let close: () -> Void
    let importRecording: () -> Void
    @State private var examples: [SidebarRecording] = []

    private var recordings: [SidebarRecording] {
        // Selection changes the highlight, never the list's order.
        var result = examples
        for item in store.library where !result.contains(where: { $0.id == item.id }) {
            result.append(SidebarRecording(id: item.id, title: item.title, source: .imported(item)))
        }
        if let package = store.package, !result.contains(where: { $0.id == package.key }) {
            result.append(SidebarRecording(id: package.key,
                title: package.calendar?.event.title ?? store.title, source: .current))
        }
        return result
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Recordings").font(.title2.weight(.bold)).accessibilityAddTraits(.isHeader)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 20).padding(.top, 16)

            ScrollView {
                VStack(spacing: 8) {
                    ForEach(recordings) { recording in
                        recordingRow(recording)
                    }
                    if let error = store.importError {
                        Text(error).font(.footnote).foregroundStyle(.red)
                            .frame(maxWidth: .infinity, alignment: .leading).padding(12)
                    }
                }.padding(.horizontal, 12)
            }.scrollIndicators(.hidden)

            Button(action: importRecording) {
                Label("Import recording", systemImage: "plus")
                    .font(.headline).foregroundStyle(.white)
                    .frame(maxWidth: .infinity).padding(.vertical, 4)
            }
            .modifier(OwnerApplyButtonStyle())
            .accessibilityIdentifier("sidebarImportRecording")
            .padding(.horizontal, 20).padding(.bottom, 16)
        }
        .foregroundStyle(ink)
        .task {
            guard examples.isEmpty, let folder = Bundle.main.resourceURL else { return }
            examples = [false, true].compactMap { sample in
                guard let package = try? MeetingPackage.load(folder: folder, prefix: sample ? "sample_" : "") else { return nil }
                return SidebarRecording(id: package.key,
                    title: package.calendar?.event.title ?? package.notes.title, source: .bundled(sample))
            }
        }
    }

    private func recordingRow(_ recording: SidebarRecording) -> some View {
        let selected = recording.id == store.package?.key
        return Button { open(recording) } label: {
            Text(recording.title.isEmpty ? "Untitled recording" : recording.title)
                .font(.body.weight(.medium)).fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
                .multilineTextAlignment(.leading)
                .padding(.horizontal, 16).padding(.vertical, 18)
                .background(selected ? .white : .clear, in: .rect(cornerRadius: 22))
                .contentShape(.rect(cornerRadius: 22))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }

    private func open(_ recording: SidebarRecording) {
        guard recording.id != store.package?.key else { close(); return }
        switch recording.source {
        case .current: break
        case .imported(let item): store.open(item)
        case .bundled(let sample):
            do { try store.loadBundled(sample: sample, ready: true) }
            catch { store.importError = error.localizedDescription }
        }
        if store.importError == nil { close() }
    }
}

private struct SidebarRecording: Identifiable {
    enum Source {
        case current
        case imported(LibraryItem)
        case bundled(Bool)
    }
    let id: String
    let title: String
    let source: Source
}
