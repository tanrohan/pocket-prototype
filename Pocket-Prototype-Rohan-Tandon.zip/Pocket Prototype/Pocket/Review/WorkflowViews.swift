// Note review, the transcript, speakers, and the arrival preview.
import SwiftUI
import UniformTypeIdentifiers

// MARK: - Review

struct ReviewPage: View {
    @Environment(MeetingStore.self) private var store
    let note: Note
    var recipient: Person? = nil
    var body: some View {
        if !store.state.excluded.contains(note.id), store.ownerReviewContext(for: note) != nil {
            OwnerReviewPage(note: note, recipient: recipient)
        } else {
            NoteReviewPage(note: note, recipient: recipient)
        }
    }
}

// MARK: - Note review

struct NoteReviewPage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let note: Note
    var recipient: Person? = nil
    var editingTask = false
    @State private var text = ""
    @FocusState private var editingText: Bool
    @State private var owner = "unassigned"
    @State private var due = ""
    @State private var privateItem = false
    @State private var search = false
    @State private var transcriptStartID: String?
    @State private var selectedDateSourceID: String?
    @State private var loaded = false
    @State private var original: NoteEdit?
    @State private var showDuePicker = false
    @State private var dueSelection = Date()
    private var isTask: Bool { store.section(note) == "Next step" }
    private var itemName: String { isTask ? "task" : "note" }
    private var launchAnswer: PriorityDateAnswer? { store.launchDateAnswer(for: note) }
    private var hasFreezeUpdate: Bool {
        let originalSources = Set(note.sources.map(\.segmentId))
        return store.clip(store.detectedFlags(note).flatMap(\.segmentIDs)).contains {
            !originalSources.contains($0.id) && $0.text.localizedCaseInsensitiveContains("code freeze")
        }
    }
    private var pageTitle: String {
        if editingTask { return "Edit task" }
        if store.state.reviewed.contains(note.id) { return "Edit \(itemName)" }
        return store.flags(note).first?.title ?? "Review \(itemName)"
    }
    private var hasChanges: Bool {
        guard let original else { return false }
        return text != original.text || owner != original.owner || due != original.due || privateItem != original.privateItem
    }
    private var canSave: Bool { store.transcriptReady && !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && validDue }
    private func saveChanges() {
        guard canSave else { return }
        store.review(note, text: text.trimmingCharacters(in: .whitespacesAndNewlines), owner: owner, due: due, privateItem: privateItem)
        dismiss()
    }
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }
    private var validDue: Bool {
        if due.isEmpty { return true }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.isLenient = false
        return due.count == 10 && formatter.date(from: due) != nil
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    taskEditor
                    if isTask {
                        VStack(alignment: .leading, spacing: 12) {
                            TaskOwnerPicker(note: note, selection: $owner)
                            reviewReason
                        }
                        taskDueDate
                    } else if let answer = launchAnswer {
                        launchDateChoices(answer)
                    } else { reviewReason }
                    if editingTask { taskContext } else { sourceSection }
                    taskPrivacy
                    taskExclusion
                    if let error = store.audioError { Text(error).font(.footnote).foregroundStyle(appAccent) }
                }.padding(20)
            }.background(paper)
            .safeAreaInset(edge: .bottom) {
                if !editingTask && !editingText {
                    VStack(spacing: 10) {
                        if !store.transcriptReady {
                            WaitingText(text: "Waiting for the full conversation", active: store.running).font(.caption)
                        }
                        Button(action: saveChanges) {
                            Text(store.state.reviewed.contains(note.id) ? "Save changes" : "Save & mark reviewed")
                                .font(.headline).foregroundStyle(.white)
                                .frame(maxWidth: .infinity).padding(.vertical, 4)
                        }.modifier(OwnerApplyButtonStyle()).disabled(!canSave)
                    }.padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 12)
                }
            }
            .navigationTitle(pageTitle).navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    TaskDiscardButton(hasChanges: hasChanges) { dismiss() }
                }
                if editingTask {
                    ToolbarItem(placement: .confirmationAction) {
                        SheetDoneButton { saveChanges() }.disabled(!canSave)
                            .accessibilityLabel("Save and mark reviewed")
                    }
                } else {
                    ToolbarItem(placement: .topBarTrailing) {
                        Menu {
                            Button("Search transcript", systemImage: "magnifyingglass") {
                                transcriptStartID = nil; search = true
                            }.tint(ink)
                        } label: { Image(systemName: "ellipsis") }.tint(ink).accessibilityLabel("Review options")
                    }
                }
            }
            .interactiveDismissDisabled(hasChanges)
            .onAppear {
                guard !loaded else { return }
                loaded = true
                text = store.rawText(note); owner = store.ownerID(note); due = store.due(note)
                privateItem = store.isPrivate(note)
                original = NoteEdit(text: text, owner: owner, due: due, privateItem: privateItem)
                if store.state.reviewed.contains(note.id), let answer = launchAnswer {
                    selectedDateSourceID = answer.moments.last { store.launchDate(in: text) == $0.date }?.source.id
                }
            }
            .onChange(of: text) { _, value in
                if let selectedDateSourceID, let answer = launchAnswer,
                   let selected = answer.moments.first(where: { $0.source.id == selectedDateSourceID }),
                   store.launchDate(in: value) != selected.date { self.selectedDateSourceID = nil }
            }
            .sheet(isPresented: $search, onDismiss: store.stop) { TranscriptPage(initialSegmentID: transcriptStartID) }
        }.modifier(PocketKeyboardDismissControl()).tint(appAccent).presentationDragIndicator(.visible)
    }
    @ViewBuilder private var reviewReason: some View {
        if !store.state.reviewed.contains(note.id) {
            VStack(alignment: .leading, spacing: 6) {
                ForEach(store.flags(note)) { flag in
                    Text(flag.detail).font(.subheadline)
                }
            }.foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
    private func launchDateChoices(_ answer: PriorityDateAnswer) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Choose launch date").font(.headline)
            VStack(spacing: 0) {
                ForEach(Array(answer.moments.reversed()), id: \.source.id) { moment in
                    let selected = selectedDateSourceID == moment.source.id
                    Button {
                        if selected {
                            selectedDateSourceID = nil
                            if let initialDate = original.flatMap({ store.launchDatePhrase(in: $0.text) }) {
                                text = store.replacingLaunchDate(in: text, with: initialDate)
                            }
                        } else {
                            text = store.replacingLaunchDate(in: text, with: moment.date)
                            selectedDateSourceID = moment.source.id
                        }
                        store.haptic()
                    } label: {
                        HStack(spacing: 12) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(moment.date).font(.body.weight(.medium))
                                Text(moment.source.id == answer.latest?.source.id ? "Later in the conversation" : "Earlier mention").font(.footnote)
                            }.frame(maxWidth: .infinity, alignment: .leading)
                            OwnerSelectionMark(selected: selected)
                        }.foregroundStyle(selected ? reviewAccent : ink)
                            .padding(16).background(selected ? appAccent.opacity(0.08) : .clear, in: .rect(cornerRadius: 20))
                            .contentShape(Rectangle())
                    }.buttonStyle(.plain).padding(6).accessibilityValue(selected ? "Selected" : "Not selected")
                }
            }.background(.white, in: .rect(cornerRadius: 26))
            Text(hasFreezeUpdate
                 ? "This changes the launch date only. Code freeze also changed—check its linked moment before saving."
                 : "The date changed later in the conversation. Compare the exchange before saving.")
                .font(.subheadline).foregroundStyle(.secondary)
            ForEach(store.flags(note).filter { !$0.id.hasSuffix(":later") }) { flag in
                Text(flag.detail).font(.subheadline).foregroundStyle(.secondary)
            }
        }
    }
    private var sourceSection: some View {
        let sourceIDs = Set(note.sources.map(\.segmentId))
        let ids = sourceIDs.union(store.detectedFlags(note).flatMap(\.segmentIDs))
        let focus = selectedDateSourceID.flatMap { id in store.availableSegments.first { $0.id == id } } ?? store.focusEvidence(for: note)
        let remaining = store.clip(Array(ids)).filter { $0.id != focus?.id }
        return VStack(alignment: .leading, spacing: 12) {
            Text("The exchange")
                .font(.headline).accessibilityAddTraits(.isHeader)
            if let focus {
                ReviewEvidenceExcerpt(segment: focus)
                Button("View full transcript") { transcriptStartID = focus.id; search = true }
                    .font(.subheadline.weight(.medium)).frame(minHeight: 44, alignment: .leading)
                SourceContextStack(moments: remaining.map { ContextMoment(segment: $0) }, showsSearch: true, onSearch: { search = true }) { moment in
                    ReviewEvidenceExcerpt(segment: moment.segment)
                }
            } else {
                Text("No source linked. Search the transcript to check this note.")
                    .font(.subheadline).foregroundStyle(.secondary)
                searchTranscript
            }
        }
    }
    private var searchTranscript: some View {
        Button { search = true } label: {
            Label("Search transcript", systemImage: "magnifyingglass")
                .font(.subheadline.weight(.medium)).frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
        }.buttonStyle(.plain).foregroundStyle(appAccent)
    }
    private var taskEditor: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(isTask ? "Task title" : store.section(note)).font(.headline)
            TextField(isTask ? "Task" : "Note", text: $text, axis: .vertical)
                .focused($editingText)
                .font(.system(.title3, design: .serif, weight: .medium)).lineSpacing(2)
                .textFieldStyle(.plain).fixedSize(horizontal: false, vertical: true)
                .padding(18).frame(maxWidth: .infinity, alignment: .leading)
                .background(.white, in: .rect(cornerRadius: 22))
                .accessibilityLabel(isTask ? "Task title" : "Note text").accessibilityHint("Tap to edit the wording.")
        }
    }
    private var taskDueDate: some View {
        Button {
            dueSelection = dateFormatter.date(from: due) ?? .now
            showDuePicker = true
        } label: {
            HStack(spacing: 12) {
                Text(due.isEmpty ? "Add due date" : "Due date")
                    .font(.body.weight(.medium)).foregroundStyle(ink)
                Spacer(minLength: 8)
                if let date = dateFormatter.date(from: due) {
                    Text(date.formatted(date: .abbreviated, time: .omitted))
                        .foregroundStyle(.secondary)
                } else {
                    Image(systemName: "plus.circle.fill")
                        .font(.title3).foregroundStyle(.white, appAccent)
                }
            }.padding(18).contentShape(Rectangle())
        }.buttonStyle(.plain)
            .background(.white, in: .rect(cornerRadius: 22))
            .accessibilityHint("Choose a due date")
            .sheet(isPresented: $showDuePicker) { dueDatePicker }
    }
    private var dueDatePicker: some View {
        NavigationStack {
            Form {
                DatePicker("Due date", selection: $dueSelection, displayedComponents: .date)
                    .datePickerStyle(.graphical)
                    .listRowInsets(EdgeInsets(top: 4, leading: 8, bottom: 4, trailing: 8))
                if !due.isEmpty {
                    Button("Remove due date", role: .destructive) {
                        due = ""
                        showDuePicker = false
                    }
                }
            }
            .navigationTitle(due.isEmpty ? "Add due date" : "Due date")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    if #available(iOS 26.0, *) {
                        Button(role: .cancel) { showDuePicker = false }.tint(ink)
                    } else {
                        Button("Cancel", systemImage: "xmark") { showDuePicker = false }.tint(ink)
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    SheetDoneButton {
                        due = dateFormatter.string(from: dueSelection)
                        showDuePicker = false
                    }.accessibilityLabel("Set due date")
                }
            }
        }.tint(appAccent).presentationDetents([.height(520), .large])
    }
    private var taskContext: some View {
        let ids = Set(note.sources.map(\.segmentId)).union(store.flags(note).flatMap(\.segmentIDs))
        let moments = store.clip(Array(ids)).map { ContextMoment(segment: $0) }
        return SourceContextStack(moments: moments, showsSearch: true, onSearch: { search = true }) { moment in
            EvidenceCard(segment: moment.segment, recipient: recipient)
        }
    }
    private var taskPrivacy: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Visibility").font(.headline)
            VStack(spacing: 0) {
                privacyChoice(isPrivate: false, title: "Public", detail: "Available when you choose to share.", symbol: "person.2")
                privacyChoice(isPrivate: true, title: "Private", detail: "Kept out of replies and team updates.", symbol: "lock")
            }.padding(6).background(.white, in: .rect(cornerRadius: 26))
        }
    }
    private func privacyChoice(isPrivate: Bool, title: String, detail: String, symbol: String) -> some View {
        let selected = privateItem == isPrivate
        return Button { privateItem = isPrivate; store.haptic() } label: {
            HStack(spacing: 12) {
                Image(systemName: symbol).frame(width: 24)
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.body.weight(.medium))
                    Text(detail).font(.caption)
                }.frame(maxWidth: .infinity, alignment: .leading)
                OwnerSelectionMark(selected: selected).accessibilityHidden(true)
            }.foregroundStyle(selected ? reviewAccent : ink).padding(12)
                .background(selected ? appAccent.opacity(0.08) : .clear, in: .rect(cornerRadius: 20))
                .contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityValue(selected ? "Selected" : "Not selected")
    }
    private var taskExclusion: some View {
        Group {
            if store.state.excluded.contains(note.id) {
                Button { store.restore(note); dismiss() } label: {
                    Label("Restore this \(itemName)", systemImage: "arrow.uturn.backward")
                        .frame(maxWidth: .infinity, minHeight: 24, alignment: .leading)
                }
            } else {
                Button(role: .destructive) { store.exclude(note); dismiss() } label: {
                    Label("Exclude this \(itemName)", systemImage: "minus.circle")
                        .frame(maxWidth: .infinity, minHeight: 24, alignment: .leading)
                }.foregroundStyle(.red).tint(.red)
            }
        }.font(.body.weight(.medium)).padding(18)
            .background(.white, in: .rect(cornerRadius: 22))
    }

}

// MARK: - Transcript

struct TranscriptPage: View {
    var recipient: Person? = nil
    var initialSegmentID: String? = nil
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
            ScrollView { LazyVStack(spacing: 14) {
                if !store.transcriptReady {
                    WaitingText(text: store.running ? "More of the conversation is arriving…" : "Transcript paused · more to come", active: store.running)
                        .font(.subheadline).frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 4).padding(.vertical, 10)
                }
                ForEach(store.availableSegments.filter { query.isEmpty || $0.text.localizedCaseInsensitiveContains(query) }) { segment in
                    EvidenceCard(segment: segment, recipient: recipient)
                        .overlay { if segment.id == initialSegmentID { RoundedRectangle(cornerRadius: 26).strokeBorder(appAccent.opacity(0.5), lineWidth: 1.5).allowsHitTesting(false) } }
                        .id(segment.id)
                }
                if let error = store.audioError { Text(error).font(.footnote).foregroundStyle(appAccent) }
            }.padding(20) }.background(paper).searchable(text: $query, prompt: "Find a word or phrase").navigationTitle("Meeting Transcript").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { SheetDoneButton { dismiss() } } }
            .task(id: initialSegmentID) {
                guard let initialSegmentID, store.availableSegments.contains(where: { $0.id == initialSegmentID }) else { return }
                await Task.yield()
                proxy.scrollTo(initialSegmentID, anchor: .top)
            }
            }
        }.modifier(PocketKeyboardDismissControl()).tint(appAccent)
    }
}

// MARK: - Speakers

struct SpeakersPage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section {
                    if store.speakersAvailable {
                        ForEach(store.notes?.speakers ?? [], id: \.speaker) { speaker in
                            NavigationLink { SpeakerEditor(speaker: speaker) } label: {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(store.speakerName(speaker.speaker))
                                    Text(speaker.speaker + (store.state.speakerNames[speaker.speaker] == nil ? " · Suggested name" : " · Updated by you"))
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                        if (store.notes?.speakers ?? []).isEmpty { Text("No speaker suggestions were supplied. Owner names can still be edited on individual action items.") }
                    } else { Text("Speaker suggestions are still arriving.") }
                } footer: {
                    Text("Correct a name once to update it throughout this recording. The original transcript stays unchanged, and reply drafts are cleared when names change.")
                }
            }.scrollContentBackground(.hidden).background(paper)
                .navigationTitle("Speaker names").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { SheetDoneButton { dismiss() } } }
        }.tint(appAccent)
    }
}

// MARK: - Identify speaker

struct SpeakerEditor: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let speaker: Speaker
    @State private var name = ""
    @State private var personID = ""
    var body: some View {
        Form {
            Section("Display name") {
                TextField("Name", text: $name)
                    .onChange(of: name) { _, value in
                        if let person = store.package?.calendar?.event.attendees.first(where: { $0.id == personID }), value != person.name {
                            personID = ""
                        }
                    }
            }
            Section("Match a calendar attendee") {
                ForEach(store.package?.calendar?.event.attendees ?? []) { person in
                    Button {
                        name = person.name
                        personID = person.id
                    } label: {
                        HStack {
                            Text(person.name)
                            Spacer()
                            if personID == person.id { Image(systemName: "checkmark") }
                        }
                    }
                }
                Button("Keep as a separate speaker") { personID = "" }
            }
            Section("Source moments") {
                ForEach(store.clip((speaker.evidence ?? []).map(\.segmentId))) { segment in
                    EvidenceCard(segment: segment, allowsReply: false)
                }
            }
            Section {
                Button("Save throughout recording") {
                    store.setSpeaker(speaker.speaker, name: name, personID: personID.isEmpty ? nil : personID)
                    dismiss()
                }
                .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .modifier(PocketKeyboardDismissControl())
        .navigationTitle("Identify speaker")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            name = store.speakerName(speaker.speaker)
            personID = store.state.speakerPeople[speaker.speaker] ?? speaker.attendeeEmail ?? ""
        }
        .onDisappear { store.stop() }
    }
}

// MARK: - Replace across notes

struct ReplacePage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var old = ""
    @State private var new = ""
    private var matches: [Note] { old.isEmpty || !store.complete ? [] : store.allNotes.filter { store.rawText($0).contains(old) } }
    private var canReplace: Bool { !matches.isEmpty && !new.isEmpty && old != new && store.transcriptReady }
    private var replacementTitle: String { matches.count == 1 ? "Replace in 1 note" : "Replace in \(matches.count) notes" }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Find exact text", text: $old)
                    TextField("Replace with", text: $new)
                } header: {
                    Text("Correct text repeated across your notes. Affected notes will need review again, and reply drafts will be cleared. The original transcript stays unchanged.")
                        .font(.subheadline).foregroundStyle(.secondary).textCase(nil)
                        .padding(.bottom, 8)
                }
                Section(matches.count == 1 ? "1 affected note" : "\(matches.count) affected notes") {
                    if !store.complete { Text("Wait for the notes to finish, or choose Skip to end before replacing across notes.").foregroundStyle(.secondary) }
                    ForEach(matches) { Text(store.rawText($0)).font(.subheadline) }
                }
            }.scrollContentBackground(.hidden).background(paper)
                .safeAreaInset(edge: .bottom) {
                    Button {
                        let count = store.replaceAcrossNotes(old: old, new: new)
                        store.announce("Updated \(count) \(count == 1 ? "note" : "notes") · review before sharing")
                        dismiss()
                    } label: {
                        Text(replacementTitle).font(.headline)
                            .frame(maxWidth: .infinity).padding(.vertical, 4)
                    }
                    .modifier(OwnerApplyButtonStyle()).disabled(!canReplace)
                    .padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 12)
                }
                .navigationTitle("Replace across notes").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        if #available(iOS 26.0, *) {
                            Button(role: .close) { dismiss() }.tint(ink).accessibilityLabel("Close")
                        } else {
                            Button("Close", systemImage: "xmark") { dismiss() }.labelStyle(.iconOnly).tint(ink)
                        }
                    }
                }
        }.modifier(PocketKeyboardDismissControl()).tint(appAccent)
    }
}

// MARK: - Library

struct LibraryPage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var importing = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Bring your meeting into Pocket")
                            .font(.system(.title, design: .serif, weight: .medium))
                            .fixedSize(horizontal: false, vertical: true)
                        Text("Choose a folder with a prepared transcript and meeting notes in the supplied recording format.")
                            .font(.subheadline).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }.padding(.top, 8)

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Required files").font(.headline).accessibilityAddTraits(.isHeader)
                        VStack(alignment: .leading, spacing: 16) {
                            importFileRow("Transcript", filename: "transcript.json")
                            Divider()
                            importFileRow("Meeting notes", filename: "notes.json")
                        }.padding(20).frame(maxWidth: .infinity, alignment: .leading)
                            .background(.white, in: .rect(cornerRadius: 26))
                    }

                    DisclosureGroup {
                        VStack(alignment: .leading, spacing: 18) {
                            importFileRow("Calendar", filename: "calendar.json")
                            importFileRow("Arrival timing", filename: "stream.json")
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Recording audio").font(.subheadline.weight(.medium))
                                Text("Include the audio file named in the transcript to listen to source moments.")
                                    .font(.footnote).foregroundStyle(.secondary)
                            }
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(.top, 16)
                    } label: {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Optional files").font(.body.weight(.medium))
                            Text("Audio, calendar and arrival timing")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                    .padding(20).background(.white, in: .rect(cornerRadius: 26))

                    Text("Files are copied to this device. Pocket opens existing transcripts and notes; it doesn’t transcribe audio files.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, 4)

                    if let error = store.importError {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Couldn’t import this folder").font(.subheadline.weight(.semibold))
                            Text(error).font(.footnote)
                        }
                        .foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading)
                        .padding(18).background(Color.red.opacity(0.06), in: .rect(cornerRadius: 22))
                        .accessibilityElement(children: .combine)
                    }
                }.padding(20)
            }
            .background(paper).scrollIndicators(.hidden)
            .safeAreaInset(edge: .bottom) {
                Button {
                    store.importError = nil
                    importing = true
                } label: {
                    Label("Choose folder", systemImage: "folder")
                        .font(.headline).foregroundStyle(.white)
                        .frame(maxWidth: .infinity).padding(.vertical, 4)
                }
                .modifier(OwnerApplyButtonStyle()).accessibilityIdentifier("importFolder")
                .padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 12)
            }
            .navigationTitle("Import recording").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { SheetDoneButton { dismiss() } } }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.folder]) { result in
                switch result { case .success(let folder): store.importFolder(folder); if store.importError == nil { dismiss() }
                case .failure(let error): store.importError = error.localizedDescription }
            }
        }.foregroundStyle(ink).tint(appAccent)
    }

    private func importFileRow(_ title: String, filename: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.subheadline.weight(.medium))
            Text(filename).font(.footnote.monospaced()).foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }
}

// MARK: - Arrival preview

struct ArrivalPage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @State private var previewStartedAt = Date()
    private var displayedDate: Date {
        store.recordingDate?.addingTimeInterval(store.recordingDuration) ?? previewStartedAt
    }
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(hex: 0xDCE4DB), Color(hex: 0xA9B8AE), Color(hex: 0x62786C)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            GeometryReader { geometry in
                ScrollView {
                    VStack(spacing: 0) {
                        ZStack {
                            Image(systemName: "lock.fill")
                                .font(.system(size: 19, weight: .medium))
                                .accessibilityHidden(true)
                            HStack {
                                Spacer()
                                skipControl
                            }
                        }
                        .frame(minHeight: 72)
                        .padding(.horizontal, 20).padding(.top, 8)

                        VStack(spacing: 0) {
                            Text(displayedDate, format: .dateTime.weekday(.wide).month(.wide).day())
                                .font(.system(.title3, weight: .medium))
                                .multilineTextAlignment(.center)
                            Text(displayedDate, format: .dateTime.hour(.defaultDigits(amPM: .omitted)).minute())
                                .font(.system(size: 92, weight: .semibold, design: .rounded))
                                .tracking(-4).monospacedDigit()
                                .lineLimit(1).minimumScaleFactor(0.6)
                        }.padding(.horizontal, 24).padding(.top, 8)

                        Spacer(minLength: 44)
                        recordingNotification.padding(.horizontal, 20)
                        Color.clear.frame(height: 72)
                    }.frame(minHeight: geometry.size.height, alignment: .top)
                }.scrollIndicators(.hidden)
            }
        }
        .foregroundStyle(ink).tint(ink)
        .statusBarHidden()
        .interactiveDismissDisabled()
    }

    private var skipButton: some View {
        Button {
            store.haptic(); store.skip(); dismiss()
        } label: {
            VStack(spacing: 5) {
                Image(systemName: "forward.end.fill").font(.system(size: 18, weight: .semibold))
                Text("Skip to End").font(.caption2.weight(.semibold))
            }
            .frame(minWidth: 64, minHeight: 50)
            .padding(.horizontal, 5).padding(.vertical, 3)
        }
        .buttonBorderShape(.roundedRectangle(radius: 20))
        .accessibilityLabel("Skip to End")
        .accessibilityIdentifier("arrivalSkipToEnd")
    }

    @ViewBuilder private var skipControl: some View {
        if #available(iOS 26.0, *), !reduceTransparency, contrast != .increased {
            skipButton.buttonStyle(.glass)
        } else {
            skipButton.buttonStyle(.bordered)
        }
    }

    private var recordingNotification: some View {
        Button { store.haptic(); dismiss() } label: {
            VStack(alignment: .leading, spacing: 16) {
                HStack(alignment: .firstTextBaseline) {
                    Text("Pocket").font(.system(.title2, design: .serif, weight: .medium))
                    Spacer()
                    Text(store.stamp(store.recordingDuration))
                        .font(.caption.weight(.medium)).monospacedDigit().foregroundStyle(.secondary)
                }
                VStack(alignment: .leading, spacing: 5) {
                    Text(store.complete ? "Your notes are ready" : "Recording stopped").font(.headline)
                    Text(store.complete ? "Open the recording to review your notes." : "Open the recording to see your notes take shape.")
                        .font(.subheadline).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                HStack {
                    Text("Open recording").font(.subheadline.weight(.semibold))
                    Spacer()
                    Image(systemName: "chevron.right").font(.caption.weight(.semibold))
                }
            }
            .multilineTextAlignment(.leading)
            .padding(22)
            .background(.regularMaterial, in: .rect(cornerRadius: 30))
            .contentShape(.rect(cornerRadius: 30))
        }
        .buttonStyle(.plain)
        .accessibilityHint("Open this recording in Pocket.")
    }
}

// MARK: - Task owner

private struct TaskOwnerPicker: View {
    @Environment(MeetingStore.self) private var store
    let note: Note
    @Binding var selection: String
    private var candidates: [Person] {
        var people: [Person] = []
        let ids = [store.ownerReviewContext(for: note)?.suggestedPerson?.id, store.ownerID(note), selection].compactMap { $0 }
        for id in ids {
            if let person = store.people.first(where: { $0.id == id }), !people.contains(where: { $0.id == id }) { people.append(person) }
        }
        return people
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Owner").font(.headline).accessibilityAddTraits(.isHeader)
            VStack(spacing: 0) {
                ForEach(Array(candidates.enumerated()), id: \.element.id) { index, person in
                    Button { selection = selection == person.id ? "unassigned" : person.id; store.haptic() } label: {
                        HStack(spacing: 12) {
                            OwnerChoiceAvatar(person: person, selected: selection == person.id).accessibilityHidden(true)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(person.name).font(.body.weight(.medium))
                                Text(person.id == store.ownerReviewContext(for: note)?.suggestedPerson?.id ? "Suggested by the exchange" : person.id == store.ownerID(note) ? "Currently in the note" : "Your choice")
                                    .font(.footnote)
                            }.frame(maxWidth: .infinity, alignment: .leading)
                            OwnerSelectionMark(selected: selection == person.id).frame(width: 24).accessibilityHidden(true)
                        }.foregroundStyle(selection == person.id ? reviewAccent : ink)
                            .padding(.horizontal, 12).padding(.vertical, 14)
                            .background(selection == person.id ? appAccent.opacity(0.08) : .clear, in: .rect(cornerRadius: 20))
                            .padding(6).contentShape(Rectangle())
                    }.buttonStyle(.plain).accessibilityValue(selection == person.id ? "Selected" : "Not selected")
                    let nextID = index + 1 < candidates.count ? candidates[index + 1].id : "unassigned"
                    Divider().padding(.leading, 68).padding(.trailing, 18)
                        .opacity(selection == person.id || selection == nextID ? 0 : 1)
                }
                Menu {
                    ForEach(store.people) { person in Button(person.name) { selection = person.id; store.haptic() } }
                    Button("Leave unassigned") { selection = "unassigned" }
                } label: {
                    HStack {
                        Text(selection == "unassigned" ? "Unassigned" : "Choose someone else")
                        Spacer()
                        Image(systemName: "chevron.up.chevron.down").font(.caption.weight(.semibold))
                    }.font(.subheadline).foregroundStyle(.secondary).padding(.horizontal, 18).frame(minHeight: 54)
                }
            }.background(.white, in: .rect(cornerRadius: 26)).clipShape(.rect(cornerRadius: 26))
        }
    }
}

// MARK: - Discard changes

// Keep confirmation state on the toolbar button so the system anchors the
// discard menu to the control that opened it, including on first presentation.
struct TaskDiscardButton: View {
    var hasChanges: Bool
    var onDiscard: () -> Void
    @State private var showConfirmation = false

    private func close() {
        if hasChanges { showConfirmation = true } else { onDiscard() }
    }
    var body: some View {
        Group {
            if #available(iOS 26.0, *) {
                Button(role: .cancel, action: close)
            } else {
                Button("Close", systemImage: "xmark", action: close)
            }
        }
        .tint(ink)
        .accessibilityLabel("Close")
        .confirmationDialog("Are you sure you want to discard changes?", isPresented: $showConfirmation, titleVisibility: .visible) {
            Button("Discard Changes", role: .destructive, action: onDiscard)
            Button("Keep Editing", role: .cancel) {}
        }
    }
}
