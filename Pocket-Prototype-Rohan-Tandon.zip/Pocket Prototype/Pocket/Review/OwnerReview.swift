// The focused check for a task whose owner may be wrong.
import SwiftUI

// MARK: - Owner check

struct OwnerReviewContext {
    let offer: Segment?
    let response: Segment?
    let suggestedPerson: Person?
    let reason: String
    var playback: Segment? {
        guard var segment = offer else { return response }
        if let response, response.start >= segment.end, response.end - segment.start <= 30 { segment.end = response.end }
        return segment
    }
}

// MARK: - Confirm owner

@MainActor extension MeetingStore {
    func ownerReviewContext(for note: Note) -> OwnerReviewContext? {
        guard let flag = detectedFlags(note).first(where: { $0.id.hasSuffix(":owner") }) else { return nil }
        let originalIDs = Set(note.sources.map(\.segmentId))
        let offer = clip(Array(originalIDs)).last
        let response = clip(flag.segmentIDs).first { !originalIDs.contains($0.id) }
        let named = people.filter { person in
            guard !person.first.isEmpty, let response else { return false }
            return response.text.range(of: #"\b"# + NSRegularExpression.escapedPattern(for: person.first) + #"\b"#, options: [.regularExpression, .caseInsensitive]) != nil
        }
        let suggestion = named.count == 1 ? named.first : nil
        let reason: String
        if let suggestion, let response {
            reason = "The original note names \(note.owner?.name ?? owner(note)), but \(speakerName(response.speaker).split(separator: " ").first ?? "the next speaker") thanks \(suggestion.first)."
        } else {
            reason = "The owner in the note may not match the surrounding exchange. Choose who took the task."
        }
        return OwnerReviewContext(offer: offer, response: response, suggestedPerson: suggestion, reason: reason)
    }

    /// Confirm only this task's owner. Other flagged claims keep their own review requirement.
    @discardableResult func confirmOwner(noteID: String, personID: String, recordingKey: String, expectedRevision: Int) -> Bool {
        guard package?.key == recordingKey, revision == expectedRevision, transcriptReady,
              let note = allNotes.first(where: { $0.id == noteID }), available(noteID),
              !state.excluded.contains(noteID), ownerReviewContext(for: note) != nil,
              !rawText(note).trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              personID == "unassigned" || people.contains(where: { $0.id == personID }) else { return false }
        let previousOwner = ownerID(note)
        state.edits[noteID] = NoteEdit(text: rawText(note), owner: personID, due: due(note), privateItem: isPrivate(note))
        if state.checkedOwners == nil { state.checkedOwners = [:] }
        state.checkedOwners?[noteID] = personID
        if flags(note).isEmpty { state.reviewed.insert(noteID) } else { state.reviewed.remove(noteID) }
        changed(); haptic()
        let result = personID == "unassigned" ? "Task left unassigned" : previousOwner == personID ? "Owner confirmed: \(owner(note))" : "Owner updated to \(owner(note))"
        announce(result + (flags(note).isEmpty ? "" : " · more to review"))
        return true
    }
}

// MARK: - Owner review

struct OwnerReviewPage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let note: Note
    var recipient: Person? = nil
    @State private var selectedID: String?
    @State private var recordingKey = ""
    @State private var sourceRevision = 0
    @State private var search = false
    @State private var transcriptStartID: String?
    @State private var editing = false
    @State private var changedMessage: String?
    @State private var loaded = false
    private var initialSelection: String? {
        store.state.checkedOwners?[note.id] ?? (store.state.reviewed.contains(note.id) ? store.ownerID(note) : nil)
    }
    private var context: OwnerReviewContext? { store.ownerReviewContext(for: note) }
    private var selectedPerson: Person? { store.people.first { $0.id == selectedID } }
    private var candidates: [Person] {
        var result: [Person] = []
        if let person = context?.suggestedPerson { result.append(person) }
        if let current = store.people.first(where: { $0.id == store.ownerID(note) }), !result.contains(where: { $0.id == current.id }) { result.append(current) }
        if let original = store.people.first(where: { $0.name == note.owner?.name }), !result.contains(where: { $0.id == original.id }) { result.append(original) }
        if let selectedPerson, !result.contains(where: { $0.id == selectedPerson.id }) { result.append(selectedPerson) }
        return result
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    taskSummary
                    ownerChoices
                    if let context { exchange(context) }
                    if let message = changedMessage { Text(message).font(.footnote).foregroundStyle(reviewAccent) }
                    if let error = store.audioError { Text(error).font(.footnote).foregroundStyle(appAccent) }
                }.padding(.horizontal, 20).padding(.vertical, 12)
            }.background(paper)
            .navigationTitle("Check owner").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { TaskDiscardButton(hasChanges: selectedID != nil && selectedID != initialSelection) { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Edit task", systemImage: "square.and.pencil") { editing = true }.tint(ink)
                        Button("Search transcript", systemImage: "magnifyingglass") { transcriptStartID = nil; search = true }.tint(ink)
                        Section {
                            Button("Exclude this task", systemImage: "minus.circle", role: .destructive) { store.exclude(note); dismiss() }
                                .tint(.red)
                        }
                    } label: { Image(systemName: "ellipsis") }.accessibilityLabel("Task options")
                }
            }
            .safeAreaInset(edge: .bottom) {
                VStack(spacing: 10) {
                    if !store.transcriptReady {
                        WaitingText(text: "Waiting for the full conversation", active: store.running).font(.caption)
                    }
                    Button {
                        guard let selectedID else { return }
                        if store.confirmOwner(noteID: note.id, personID: selectedID, recordingKey: recordingKey, expectedRevision: sourceRevision) { dismiss() }
                        else { self.selectedID = initialSelection; sourceRevision = store.revision; changedMessage = "This task changed. Check it again before choosing an owner." }
                    } label: {
                        Text("Apply to this task").multilineTextAlignment(.center).fixedSize(horizontal: false, vertical: true)
                            .font(.headline).foregroundStyle(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 4)
                    }
                    .modifier(OwnerApplyButtonStyle())
                    .disabled(selectedID == nil || !store.transcriptReady)
                }.padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 12)
            }
            .onAppear {
                guard !loaded else { return }; loaded = true
                recordingKey = store.package?.key ?? ""; sourceRevision = store.revision
                selectedID = initialSelection
            }
            .interactiveDismissDisabled(selectedID != nil && selectedID != initialSelection)
            .onChange(of: store.revision) { _, _ in
                selectedID = initialSelection; sourceRevision = store.revision
            }
            .onChange(of: store.package?.key) { _, _ in dismiss() }
            .sheet(isPresented: $search, onDismiss: store.stop) { TranscriptPage(initialSegmentID: transcriptStartID) }
            .sheet(isPresented: $editing, onDismiss: store.stop) { NoteReviewPage(note: note, recipient: recipient, editingTask: true) }
        }.foregroundStyle(ink).tint(appAccent).presentationDragIndicator(.visible)
    }
    @ViewBuilder private var closeButton: some View {
        if #available(iOS 26.0, *) {
            Button(role: .close) { dismiss() }.tint(ink).accessibilityLabel("Close")
        } else {
            Button("Close", systemImage: "xmark", role: .cancel) { dismiss() }
                .labelStyle(.iconOnly).tint(ink).accessibilityLabel("Close")
        }
    }
    private var taskSummary: some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack(alignment: .leading, spacing: 6) {
                Text(store.text(note)).font(.system(.title3, design: .serif, weight: .medium)).lineSpacing(1)
                    .fixedSize(horizontal: false, vertical: true).accessibilityAddTraits(.isHeader)
                HStack(spacing: 12) {
                    if !store.due(note).isEmpty { Text("Due \(displayDate(store.due(note)))") }
                    if store.isPrivate(note) { Label("Private", systemImage: "lock") }
                }.font(.caption.weight(.medium)).foregroundStyle(.secondary)
            }
            if let context {
                Text(context.reason).font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
    private func exchange(_ context: OwnerReviewContext) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("The exchange").font(.headline).accessibilityAddTraits(.isHeader)
            VStack(alignment: .leading, spacing: 12) {
                if let playback = context.playback, store.package?.audioURL != nil {
                    SourceListenButton(segment: playback, compact: true)
                }
                if let offer = context.offer {
                    exchangeTurn(offer, speaker: "Check speaker", uncertain: true)
                }
                if let response = context.response {
                    if context.offer != nil { Divider() }
                    exchangeTurn(response, speaker: store.speakerName(response.speaker), uncertain: false)
                }
                if store.package?.audioURL == nil { Text("Audio isn’t included. You can read the exchange to check it.").font(.caption).foregroundStyle(.secondary) }
            }.padding(.horizontal, 18).padding(.top, 8).padding(.bottom, 18)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(.white, in: .rect(cornerRadius: 26))
            Button("View full transcript") {
                transcriptStartID = context.offer?.id ?? context.response?.id
                store.stop(); search = true
            }.font(.subheadline.weight(.medium)).foregroundStyle(reviewAccent)
                .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                .accessibilityHint("Opens the full conversation at this exchange.")
        }
    }
    private func exchangeTurn(_ segment: Segment, speaker: String, uncertain: Bool) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .firstTextBaseline, spacing: 12) {
                Text(speaker).foregroundStyle(uncertain ? reviewAccent : ink.opacity(0.65))
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
                Text(store.stamp(segment.start)).monospacedDigit().foregroundStyle(.secondary).fixedSize()
            }.font(.caption.weight(.medium))
            Text("“\(segment.text)”").font(.system(.callout, design: .serif)).lineSpacing(2)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
    private var ownerChoices: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Choose the owner").font(.headline).accessibilityAddTraits(.isHeader)
            VStack(spacing: 0) {
                ForEach(Array(candidates.enumerated()), id: \.element.id) { index, person in
                    Button { selectedID = selectedID == person.id ? nil : person.id; changedMessage = nil; store.haptic() } label: {
                        HStack(spacing: 12) {
                            OwnerChoiceAvatar(person: person, selected: selectedID == person.id)
                                .accessibilityHidden(true)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(person.name).font(.body.weight(.medium)).foregroundStyle(selectedID == person.id ? reviewAccent : ink)
                                Text(person.id == context?.suggestedPerson?.id ? "Suggested by the exchange" : person.id == store.ownerID(note) ? "Currently in the note" : "Your choice")
                                    .font(.footnote).foregroundStyle(selectedID == person.id ? reviewAccent : ink.opacity(0.65))
                            }.frame(maxWidth: .infinity, alignment: .leading)
                            OwnerSelectionMark(selected: selectedID == person.id)
                                .frame(width: 24).accessibilityHidden(true)
                        }.padding(.horizontal, 12).padding(.vertical, 14)
                            .background(selectedID == person.id ? appAccent.opacity(0.08) : .clear, in: .rect(cornerRadius: 20))
                            .padding(6)
                            .contentShape(Rectangle())
                    }.buttonStyle(.plain)
                        .accessibilityValue(selectedID == person.id ? "Selected" : "Not selected")
                        .accessibilityAddTraits(selectedID == person.id ? .isSelected : [])
                    let nextID = index + 1 < candidates.count ? candidates[index + 1].id : "unassigned"
                    Divider().padding(.leading, 68).padding(.trailing, 18)
                        .opacity(selectedID == person.id || selectedID == nextID ? 0 : 1)
                        .accessibilityHidden(true)
                }
                Menu {
                    ForEach(store.people.filter { person in !candidates.contains(where: { $0.id == person.id }) }) { person in
                        Button(person.name) { selectedID = person.id; changedMessage = nil; store.haptic() }
                    }
                    Button("Leave unassigned") { selectedID = "unassigned"; changedMessage = nil; store.haptic() }
                } label: {
                    HStack {
                        Text(selectedID == "unassigned" ? "Unassigned" : "Choose someone else")
                        Spacer()
                        Image(systemName: "chevron.up.chevron.down").font(.caption.weight(.semibold))
                    }.font(.subheadline).foregroundStyle(selectedID == "unassigned" ? reviewAccent : ink.opacity(0.65))
                        .padding(.horizontal, 12).frame(minHeight: 42)
                        .background(selectedID == "unassigned" ? appAccent.opacity(0.08) : .clear, in: .rect(cornerRadius: 20))
                        .padding(6)
                }
            }.background(.white, in: .rect(cornerRadius: 26))
                .clipShape(.rect(cornerRadius: 26))
        }
    }
}

// MARK: - Owner controls

struct OwnerChoiceAvatar: View {
    let person: Person
    let selected: Bool

    var body: some View {
        if selected {
            Avatar(person: person, size: 38)
        } else {
            Text(person.initials)
                .font(.system(size: 11, weight: .medium, design: .rounded))
                .foregroundStyle(ink.opacity(0.6))
                .frame(width: 38, height: 38)
                .background(appAccent.opacity(0.08), in: .circle)
        }
    }
}

struct OwnerApplyButtonStyle: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *), !reduceTransparency, contrast != .increased {
            content.buttonStyle(.glassProminent).buttonBorderShape(.capsule).controlSize(.large).tint(appAccent)
        } else {
            content.buttonStyle(.borderedProminent).buttonBorderShape(.capsule).controlSize(.large).tint(appAccent)
        }
    }
}

struct OwnerSelectionMark: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let selected: Bool
    var body: some View {
        ZStack {
            Circle().strokeBorder(ink.opacity(0.2), lineWidth: 1.5)
            Circle().fill(reviewAccent).opacity(selected ? 1 : 0)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: selected)
            OwnerCheckStroke().trim(from: 0, to: selected ? 1 : 0)
                .stroke(.white, style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                .animation(reduceMotion ? nil : .easeOut(duration: 0.24).delay(selected ? 0.08 : 0), value: selected)
        }.frame(width: 19, height: 19)
    }
}
private struct OwnerCheckStroke: Shape {
    func path(in rect: CGRect) -> Path {
        Path { path in
            path.move(to: CGPoint(x: rect.width * 0.27, y: rect.height * 0.51))
            path.addLine(to: CGPoint(x: rect.width * 0.44, y: rect.height * 0.68))
            path.addLine(to: CGPoint(x: rect.width * 0.74, y: rect.height * 0.32))
        }
    }
}
