// The launch-date answer, from the first mention through a checked reply.
import SwiftUI

// MARK: - Priority date

struct DatedMoment {
    let date: String
    let source: Segment
}

struct PriorityDateAnswer: Identifiable {
    let id: String
    let topicID: String
    let title: String
    let request: Segment
    let recipient: Person?
    let moments: [DatedMoment]
    var confirmation: Segment? = nil
    var first: DatedMoment? { moments.first }
    var latest: DatedMoment? { moments.last }
    var hasUpdate: Bool { first?.date != latest?.date }
}

// MARK: - Date extraction

/// Conservative, local extraction from arrived text. These are review candidates, not verified facts.
/// Unrecognized requests retain the ordinary overview and transcript workflow.
@MainActor extension MeetingStore {
    var priorityDateAnswer: PriorityDateAnswer? {
        let arrived = availableSegments
        let key = ([package?.key ?? "", String(revision), String(transcriptReady)] + arrived.map(\.id)).joined(separator: "|")
        if priorityCacheKey == key { return priorityCache }
        let result = makePriorityDateAnswer(from: arrived)
        priorityCacheKey = key; priorityCache = result
        return result
    }
    private func makePriorityDateAnswer(from arrived: [Segment]) -> PriorityDateAnswer? {
        struct Rule { let id: String; let title: String; let topic: String; let request: String }
        let rules = [
            Rule(id: "launch", title: "Launch date", topic: #"\b(?:launch(?:es)?|release|ship)\b"#, request: #"\b(?:launch|release|ship) date\b"#),
            Rule(id: "opening", title: "Opening date", topic: #"\b(?:opening|open)\b"#, request: #"\bopening date\b"#)
        ]
        let blocked = Set(allNotes.filter { isPrivate($0) || state.excluded.contains($0.id) }.flatMap { $0.sources.map(\.segmentId) })
        let publicSources = arrived.filter { !blocked.contains($0.id) && !containsPrivateLanguage($0.text) }.sorted { $0.start < $1.start }
        let intent = #"\b(?:wants?|needs?|asking|asked|one thing|priority|must decide)\b"#
        for request in publicSources {
            guard request.text.range(of: intent, options: [.regularExpression, .caseInsensitive]) != nil,
                  let rule = rules.first(where: { request.text.range(of: $0.request, options: [.regularExpression, .caseInsensitive]) != nil }) else { continue }
            let peopleNamed = (package?.calendar?.event.attendees ?? []).filter {
                !$0.first.isEmpty && request.text.range(of: #"\b"# + NSRegularExpression.escapedPattern(for: $0.first) + #"\b"#, options: [.regularExpression, .caseInsensitive]) != nil
            }
            var moments: [DatedMoment] = []
            for source in arrived.sorted(by: { $0.start < $1.start }) where source.start >= request.start {
                // Match a date in the same clause, after the subject. Don't promote hypothetical alternatives.
                for clause in source.text.components(separatedBy: CharacterSet(charactersIn: ".!?;")) {
                    guard clause.range(of: #"\b(?:what if|could|might|maybe|would|should we|can't|cannot|won't|not)\b"#, options: [.regularExpression, .caseInsensitive]) == nil,
                          let topic = clause.range(of: rule.topic, options: [.regularExpression, .caseInsensitive]),
                          let date = priorityDates(in: String(clause[topic.upperBound...])).first else { continue }
                    // A hidden later date must not make an older public date look current.
                    guard !blocked.contains(source.id), !containsPrivateLanguage(source.text) else { return nil }
                    if moments.last?.date != date { moments.append(DatedMoment(date: date, source: source)) }
                    break
                }
            }
            if transcriptReady && moments.isEmpty { continue }
            let confirmation = moments.last.flatMap { latest in
                publicSources.first { source in
                    source.start > latest.source.end && source.start - latest.source.end < 45 &&
                    priorityDates(in: source.text) == [latest.date] &&
                    source.text.range(of: #"\b(?:agreed|confirmed|settled|it is)\b"#, options: [.regularExpression, .caseInsensitive]) != nil
                }
            }
            let signature = ([package?.key ?? "", rule.id, request.id, confirmation?.id ?? ""] + moments.map { $0.source.id + ":" + $0.date }).joined(separator: "|")
            return PriorityDateAnswer(id: signature, topicID: rule.id, title: rule.title, request: request,
                                      recipient: peopleNamed.count == 1 ? peopleNamed.first : nil, moments: moments, confirmation: confirmation)
        }
        return nil
    }
    func priorityDates(in text: String) -> [String] {
        let pattern = #"\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2})(?:st|nd|rd|th)?\b"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else { return [] }
        let value = text as NSString
        return regex.matches(in: text, range: NSRange(location: 0, length: value.length)).compactMap { match in
            guard let day = Int(value.substring(with: match.range(at: 2))), (1...31).contains(day) else { return nil }
            return value.substring(with: match.range(at: 1)).capitalized + " \(day)"
        }
    }
    func checkedDateMoment(for answer: PriorityDateAnswer) -> DatedMoment? {
        guard transcriptReady, state.checkedPriorityID == answer.id, priorityDateAnswer?.id == answer.id else { return nil }
        if let sourceID = state.checkedPrioritySourceID { return answer.moments.first { $0.source.id == sourceID } }
        return answer.latest // Existing saved confirmations used the latest date.
    }
    func isChecked(_ answer: PriorityDateAnswer) -> Bool { checkedDateMoment(for: answer) != nil }
    func checkPriorityAnswer(_ answer: PriorityDateAnswer, sourceID: String? = nil) {
        guard transcriptReady, priorityDateAnswer?.id == answer.id else { return }
        let candidate = sourceID == nil ? answer.latest : answer.moments.first { $0.source.id == sourceID }
        guard let moment = candidate else { return }
        if state.checkedPrioritySourceID != moment.source.id { state.drafts = [:] }
        state.checkedPriorityID = answer.id; state.checkedPrioritySourceID = moment.source.id; save(); haptic()
    }
    func hasOutdatedNote(for answer: PriorityDateAnswer) -> Bool {
        guard let earlier = answer.first, answer.hasUpdate else { return false }
        return visibleNotes.contains { note in
            !isPrivate(note) && !state.reviewed.contains(note.id) &&
            note.sources.contains { $0.segmentId == earlier.source.id } && priorityDates(in: text(note)).contains(earlier.date)
        }
    }
    func priorityReplySeed(for answer: PriorityDateAnswer) -> ReplySeed? {
        guard let moment = checkedDateMoment(for: answer), let key = package?.key else { return nil }
        return ReplySeed(id: "priority:" + answer.id + ":" + moment.source.id, recordingKey: key,
                         text: "\(answer.title): \(moment.date).", sourceIDs: [moment.source.id, moment.source.id == answer.latest?.source.id ? answer.confirmation?.id : nil].compactMap { $0 }, priorityAnswerID: answer.id)
    }
}

// MARK: - Overview

struct PriorityDateOverview: View {
    @Environment(MeetingStore.self) private var store
    let answer: PriorityDateAnswer
    var recipient: Person? = nil
    @State private var reviewing = false
    @State private var reply: ReplySeed?
    private var checked: Bool { store.isChecked(answer) }
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 14) {
                eyebrow(answer.title.uppercased())
                VStack(alignment: .leading, spacing: 6) {
                    if store.transcriptReady {
                        if checked {
                            HStack {
                                Label("Checked by you", systemImage: "checkmark.circle.fill")
                                    .font(.subheadline.weight(.medium)).foregroundStyle(Color(hex: 0x3E6249))
                                Spacer(minLength: 8)
                                Button("Change date") { reviewing = true }
                                    .font(.subheadline.weight(.medium)).frame(minHeight: 44)
                            }
                        }
                    }
                    if store.transcriptReady, let latest = answer.latest {
                        Text((store.checkedDateMoment(for: answer) ?? latest).date).font(.system(.largeTitle, design: .serif)).tracking(-0.6)
                            .accessibilityIdentifier("priorityDate")
                        if answer.hasUpdate, let first = answer.first {
                            Text(store.checkedDateMoment(for: answer)?.source.id == first.source.id ? "Later mention: \(latest.date)" : "Earlier mention: \(first.date)").font(.subheadline).foregroundStyle(.secondary)
                        }
                    } else if let first = answer.first {
                        Text("Earlier mention: \(first.date)").font(.system(.title3, design: .serif))
                    } else {
                        Text("Finding the date discussed.").font(.system(.title2, design: .serif))
                    }
                }.fixedSize(horizontal: false, vertical: true)
                if !store.transcriptReady {
                    VStack(alignment: .leading, spacing: 5) {
                        WaitingText(text: "Still checking", active: store.running).font(.subheadline.weight(.medium))
                        Text("Waiting for the full conversation to check for updates.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                }
            }.padding(22).frame(maxWidth: .infinity, alignment: .leading)
            if store.transcriptReady, let latest = answer.latest {
                Button {
                    if checked { reply = store.priorityReplySeed(for: answer) } else { reviewing = true }
                } label: {
                    HStack(spacing: 10) {
                        if checked {
                            Image(systemName: "text.bubble.fill").font(.body.weight(.medium))
                        } else if #available(iOS 27.0, *) {
                            Image(systemName: "square.grid.month").font(.body.weight(.medium))
                        } else {
                            Image(systemName: "calendar").font(.body.weight(.medium))
                        }
                        Text(checked ? "Draft reply" : "Review date").font(.subheadline.weight(.semibold))
                        Spacer(minLength: 8)
                        if !checked { Text(store.stamp(latest.source.start)).font(.caption).monospacedDigit() }
                        Image(systemName: "chevron.right").font(.caption.weight(.semibold))
                    }.foregroundStyle(reviewAccent).padding(.horizontal, 16).frame(minHeight: 50)
                        .background(appAccent.opacity(0.08), in: .rect(cornerRadius: 20))
                }.buttonStyle(.plain).padding(9)
            }
        }
        .background {
            RoundedRectangle(cornerRadius: 29, style: .continuous).fill(.white)
                .overlay {
                    if !store.complete { ProcessingBorder(running: store.running) }
                }
        }
        .sheet(isPresented: $reviewing, onDismiss: store.stop) { PriorityDateReview(answerID: answer.id, recipient: recipient) }
        .sheet(item: $reply, onDismiss: store.stop) { ReplyDraftPage(seed: $0, recipient: recipient) }
    }
}

// MARK: - Date review

struct PriorityDateReview: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let answerID: String
    var recipient: Person? = nil
    @State private var reply: ReplySeed?
    @State private var selectedID: String?
    @State private var search = false
    @State private var transcriptStartID: String?
    @State private var loaded = false
    private var answer: PriorityDateAnswer? { store.priorityDateAnswer.flatMap { $0.id == answerID ? $0 : nil } }
    private var hasSelectionChanges: Bool {
        guard let selectedID, let answer else { return false }
        return store.checkedDateMoment(for: answer)?.source.id != selectedID
    }
    private func contextMoments(for answer: PriorityDateAnswer) -> [ContextMoment] {
        var moments: [ContextMoment] = []
        let focusedID = selectedID ?? answer.latest?.source.id
        for moment in answer.moments where moment.source.id != focusedID {
            moments.append(ContextMoment(segment: moment.source, title: moment.source.id == answer.latest?.source.id ? "Later mention" : "Earlier mention"))
        }
        if !moments.contains(where: { $0.id == answer.request.id }) { moments.append(ContextMoment(segment: answer.request, title: "Why this comes first")) }
        return moments
    }
    var body: some View {
        NavigationStack {
            Group {
                if let answer, let latest = answer.latest {
                    let focused = answer.moments.first { $0.source.id == selectedID } ?? latest
                    ScrollView {
                        VStack(alignment: .leading, spacing: 24) {
                            dateChoice(answer, latest: latest)
                            VStack(alignment: .leading, spacing: 12) {
                                Text("The exchange").font(.headline).accessibilityAddTraits(.isHeader)
                                VStack(alignment: .leading, spacing: 0) {
                                    PrioritySourceExcerpt(segment: focused.source, confirmation: focused.source.id == latest.source.id ? answer.confirmation : nil)
                                        .padding(.bottom, 4)
                                    Button("View full transcript") {
                                        store.stop()
                                        transcriptStartID = focused.source.id
                                        search = true
                                    }.buttonStyle(.plain).font(.subheadline.weight(.medium))
                                        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                                        .padding(.horizontal, 20)
                                        .accessibilityHint("Opens the meeting transcript at this exchange.")
                                    SourceContextStack(moments: contextMoments(for: answer)) { moment in
                                        PrioritySourceExcerpt(segment: moment.segment, heading: moment.title)
                                    }
                                }
                            }
                            if let error = store.audioError { Text(error).font(.footnote).foregroundStyle(appAccent) }
                        }.padding(.horizontal, 20).padding(.vertical, 12)
                    }
                } else {
                    ContentUnavailableView("This answer has changed", systemImage: "arrow.clockwise", description: Text("Return to Top priority to review the current source."))
                }
            }.background(paper)
            .navigationTitle("Check date").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    TaskDiscardButton(hasChanges: hasSelectionChanges) { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Search transcript", systemImage: "magnifyingglass") {
                            transcriptStartID = nil; search = true
                        }.tint(ink)
                    } label: { Image(systemName: "ellipsis") }.accessibilityLabel("Date options")
                }
            }
            .safeAreaInset(edge: .bottom) {
                if let answer {
                    VStack(spacing: 10) {
                        if !store.transcriptReady {
                            WaitingText(text: "Waiting for the full conversation", active: store.running).font(.caption)
                        }
                        Button {
                            guard let selectedID else { return }
                            store.checkPriorityAnswer(answer, sourceID: selectedID)
                            reply = store.priorityReplySeed(for: answer)
                        } label: {
                            Text(store.isChecked(answer) && !hasSelectionChanges ? "Draft reply" : "Use this date")
                                .font(.headline).foregroundStyle(.white)
                                .frame(maxWidth: .infinity).padding(.vertical, 4)
                        }
                        .modifier(OwnerApplyButtonStyle())
                        .disabled(selectedID == nil || !store.transcriptReady)
                        .accessibilityHint("Confirm only this date, then review your reply.")
                    }.padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 12)
                }
            }
            .onAppear { guard !loaded else { return }; loaded = true; if let answer { selectedID = store.checkedDateMoment(for: answer)?.source.id } }
            .onChange(of: store.revision) { _, _ in selectedID = nil }
            .onChange(of: store.package?.key) { _, _ in dismiss() }
            .interactiveDismissDisabled(hasSelectionChanges)
            .sheet(isPresented: $search, onDismiss: store.stop) { TranscriptPage(recipient: recipient, initialSegmentID: transcriptStartID) }
            .sheet(item: $reply, onDismiss: store.stop) { ReplyDraftPage(seed: $0, recipient: recipient) }
        }.foregroundStyle(ink).tint(appAccent).presentationDragIndicator(.visible)
    }
    private func dateChoice(_ answer: PriorityDateAnswer, latest: DatedMoment) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Choose the date").font(.headline).accessibilityAddTraits(.isHeader)
            VStack(spacing: 0) {
                ForEach(Array(answer.moments.reversed()), id: \.source.id) { moment in
                    let selected = selectedID == moment.source.id
                    Button {
                        selectedID = selected ? nil : moment.source.id
                        store.haptic()
                    } label: {
                        HStack(spacing: 14) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(moment.date).font(.system(.title2, design: .serif, weight: .medium))
                                Text(moment.source.id == latest.source.id ? "Later in the conversation" : "Earlier mention")
                                    .font(.subheadline)
                            }.frame(maxWidth: .infinity, alignment: .leading)
                            OwnerSelectionMark(selected: selected).accessibilityHidden(true)
                        }.foregroundStyle(selected ? reviewAccent : ink)
                            .padding(16).frame(maxWidth: .infinity, alignment: .leading)
                            .background(selected ? appAccent.opacity(0.08) : .clear, in: .rect(cornerRadius: 20))
                            .contentShape(Rectangle())
                    }.buttonStyle(.plain).padding(6)
                        .accessibilityValue(selected ? "Selected" : "Not selected")
                }
            }.background(.white, in: .rect(cornerRadius: 26))
            Text(answer.hasUpdate
                 ? "The date changed later in the conversation. Compare the moments, then choose which date to use."
                 : "Check the exchange before using this date.")
                .font(.subheadline).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

}

// MARK: - Source excerpt

private struct PrioritySourceExcerpt: View {
    @Environment(MeetingStore.self) private var store
    let segment: Segment
    var confirmation: Segment? = nil
    var heading: String? = nil
    private var playback: Segment {
        var clip = segment
        if let confirmation { clip.end = confirmation.end }
        return clip
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let heading {
                Text(heading).font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                    .accessibilityAddTraits(.isHeader)
            }
            if store.package?.audioURL != nil {
                SourceListenButton(segment: playback, compact: true)
            }
            HStack(alignment: .firstTextBaseline) {
                Text(store.speakerName(segment.speaker)).font(.subheadline.weight(.semibold))
                Spacer()
                Text(store.stamp(segment.start)).font(.caption).monospacedDigit().foregroundStyle(.secondary)
            }
            Text("“\(segment.text)”").font(.system(.title3, design: .serif)).lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
            if let confirmation {
                Divider().overlay(ink.opacity(0.015))
                VStack(alignment: .leading, spacing: 8) {
                    if confirmation.speaker != segment.speaker {
                        Text(store.speakerName(confirmation.speaker)).font(.subheadline.weight(.semibold))
                    }
                    Text(store.stamp(confirmation.start)).font(.caption).monospacedDigit().foregroundStyle(.secondary)
                        .accessibilityLabel("At \(Int(confirmation.start) / 60) minutes \(Int(confirmation.start) % 60) seconds")
                    Text("“\(confirmation.text)”").font(.system(.body, design: .serif)).lineSpacing(3)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }.padding(.horizontal, 20).padding(.top, heading == nil ? 12 : 20).padding(.bottom, 20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.white, in: .rect(cornerRadius: 26))
    }
}

// MARK: - Launch date in a note

@MainActor extension MeetingStore {
    // Only offer a launch substitution for a note linked to the same launch
    // discussion. Never replace every date in a multi-claim summary.
    func launchDateAnswer(for note: Note) -> PriorityDateAnswer? {
        guard transcriptReady, let answer = priorityDateAnswer, answer.topicID == "launch",
              let original = launchDate(in: note.text), answer.moments.contains(where: { $0.date == original }),
              !Set(note.sources.map(\.segmentId)).isDisjoint(with: answer.moments.map { $0.source.id }) else { return nil }
        return answer
    }
    private func launchDateMatch(in text: String) -> Range<String.Index>? {
        let pattern = #"\b(?:launch|release|ship)\b[^.;!?]*?((?:(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),?\s+)?(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:st|nd|rd|th)?)\b"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) else { return nil }
        return Range(match.range(at: 1), in: text)
    }
    func launchDate(in text: String) -> String? {
        guard let range = launchDateMatch(in: text) else { return nil }
        return priorityDates(in: String(text[range])).first
    }
    func launchDatePhrase(in text: String) -> String? {
        launchDateMatch(in: text).map { String(text[$0]) }
    }
    func replacingLaunchDate(in text: String, with date: String) -> String {
        guard let range = launchDateMatch(in: text) else { return text }
        return text.replacingCharacters(in: range, with: date)
    }
}
