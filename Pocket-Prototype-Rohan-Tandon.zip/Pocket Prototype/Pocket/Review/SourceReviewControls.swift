// Shared source excerpts, playback, and the context stack.
import SwiftUI
import Combine

// MARK: - Excerpt

/// Attribution reads as one unit, separate from the playback action and quoted content.
struct SourceExcerptHeader: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    let segment: Segment
    var playback: Segment? = nil
    var showsDuration = false
    var showsPlayback = true
    var body: some View {
        Group {
            if dynamicTypeSize.isAccessibilitySize {
                VStack(alignment: .leading, spacing: 12) {
                    attribution
                    listen
                }
            } else {
                HStack(alignment: .center, spacing: 16) {
                    attribution.frame(maxWidth: .infinity, alignment: .leading)
                    listen
                }
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private var attribution: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(store.speakerName(segment.speaker))
                .font(.subheadline.weight(.semibold)).foregroundStyle(ink)
                .fixedSize(horizontal: false, vertical: true)
            Text(store.stamp(segment.start))
                .font(.caption).monospacedDigit().foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(store.speakerName(segment.speaker)), at \(Int(segment.start) / 60) minutes \(Int(segment.start) % 60) seconds in the recording")
    }
    @ViewBuilder private var listen: some View {
        if showsPlayback, store.package?.audioURL != nil {
            SourceListenButton(segment: playback ?? segment, showsDuration: showsDuration).fixedSize()
        }
    }
}

/// Matching footer actions use the same sizing, typography, and native glass style.
struct SourceActionButton: View {
    let title: String
    let symbol: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Label(title, systemImage: symbol)
                .font(.subheadline.weight(.medium))
                .frame(maxWidth: .infinity, minHeight: 28)
        }
        .modifier(SourceListenStyle())
        .frame(maxWidth: .infinity, minHeight: 44)
        .contentShape(Rectangle())
    }
}

// MARK: - Listen

struct SourceListenButton: View {
    @Environment(MeetingStore.self) private var store
    let segment: Segment
    var showsDuration = false
    var compact = false
    private var isPlaying: Bool { store.playingID == segment.id }
    private var duration: Int { Int(ceil(segment.end - segment.start)) }
    var body: some View {
        Button { store.haptic(); store.play(segment) } label: {
            Label(isPlaying ? "Pause" : showsDuration ? "Play \(duration)s" : "Listen",
                  systemImage: isPlaying ? "pause.fill" : "play.fill")
                .font(.caption.weight(.semibold))
                .frame(minWidth: 52, minHeight: compact ? 18 : 28)
        }
        .modifier(SourceListenStyle())
        .frame(minHeight: compact ? 44 : nil)
        .contentShape(Rectangle())
        .disabled(store.package?.audioURL == nil)
        .accessibilityHint(isPlaying ? "Pause this source moment." : "Play \(duration) seconds of the original recording.")
    }
}

private struct SourceListenStyle: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *), !reduceTransparency, contrast != .increased {
            content.buttonStyle(.glass).buttonBorderShape(.capsule).controlSize(.regular).tint(ink)
        } else {
            content.buttonStyle(.bordered).buttonBorderShape(.capsule).controlSize(.regular).tint(ink)
        }
    }
}

// MARK: - More context

struct ContextMoment: Identifiable {
    let segment: Segment
    var title: String? = nil
    var id: String { segment.id }
}

struct SourceContextStack<MomentContent: View>: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let moments: [ContextMoment]
    var showsSearch = false
    var onSearch: () -> Void = {}
    @ViewBuilder let momentContent: (ContextMoment) -> MomentContent
    @State private var isExpanded = false
    @State private var measuredLeadHeight: CGFloat = 76
    private var leadHeight: CGFloat { max(76, measuredLeadHeight) }
    private var peekDepth: CGFloat { CGFloat(min(moments.count, 2)) * 10 }
    private var summary: String {
        moments.isEmpty ? "Search the conversation" : "\(moments.count) linked \(moments.count == 1 ? "moment" : "moments")"
    }
    var body: some View {
        VStack(spacing: 12) {
            VStack(spacing: isExpanded ? 12 : -leadHeight) {
                Button {
                    store.haptic()
                    withAnimation(reduceMotion ? nil : .spring(response: 0.42, dampingFraction: 0.88)) {
                        isExpanded.toggle()
                    }
                } label: {
                    lead
                        .frame(height: leadHeight)
                        .background(.white, in: .rect(cornerRadius: 26))
                        .contentShape(.rect(cornerRadius: 26))
                }
                .buttonStyle(TopicGlassButtonStyle())
                .compositingGroup()
                .shadow(color: ink.opacity(isExpanded ? 0 : 0.045), radius: 6, y: 3)
                .zIndex(Double(moments.count + 1))
                .accessibilityLabel("More context")
                .accessibilityValue("\(isExpanded ? "Expanded" : "Collapsed"), \(summary)")
                .accessibilityHint(isExpanded ? "Collapse the linked moments." : "Unfold the linked moments below.")

                ForEach(Array(moments.enumerated()), id: \.element.id) { index, moment in
                    ZStack(alignment: .topLeading) {
                        Color.clear
                        momentContent(moment)
                            .fixedSize(horizontal: false, vertical: true)
                            .compositingGroup()
                            .opacity(isExpanded ? 1 : 0)
                    }
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                    .frame(minHeight: isExpanded ? 0 : leadHeight,
                           maxHeight: isExpanded ? nil : leadHeight, alignment: .top)
                    .clipped()
                    .background(.white, in: .rect(cornerRadius: 26))
                    .shadow(color: ink.opacity(isExpanded ? 0 : 0.055), radius: 5, y: 3)
                    .padding(.horizontal, isExpanded ? 0 : CGFloat(min(index + 1, 2)) * 6)
                    .offset(y: isExpanded ? 0 : CGFloat(min(index + 1, 2)) * 10)
                    .opacity(isExpanded || index < 2 ? 1 : 0)
                    .zIndex(Double(moments.count - index))
                    .allowsHitTesting(isExpanded)
                    .accessibilityHidden(!isExpanded)
                }
            }
            .frame(maxWidth: .infinity, alignment: .top)
            .frame(height: isExpanded ? nil : leadHeight + peekDepth, alignment: .top)
            // Measure a natural-height twin, so text wrapping cannot cause a layout feedback loop.
            .background(alignment: .top) {
                lead.fixedSize(horizontal: false, vertical: true).hidden()
                    .allowsHitTesting(false).accessibilityHidden(true)
                    .onGeometryChange(for: CGFloat.self) { max(76, ceil($0.size.height)) } action: { height in
                        if measuredLeadHeight != height { measuredLeadHeight = height }
                    }
            }
            if isExpanded && showsSearch {
                Button(action: onSearch) {
                    Label("Search transcript", systemImage: "magnifyingglass")
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                        .padding(.horizontal, 4)
                }.buttonStyle(.plain).foregroundStyle(appAccent)
            }
        }
    }
    private var lead: some View {
        HStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text("More context").font(.subheadline.weight(.semibold)).foregroundStyle(ink)
                Text(summary).font(.caption).foregroundStyle(.secondary)
            }.fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            Image(systemName: "chevron.down").font(.subheadline.weight(.semibold))
                .rotationEffect(.degrees(isExpanded ? 180 : 0))
                .foregroundStyle(.secondary).accessibilityHidden(true)
        }.padding(20).frame(maxWidth: .infinity, minHeight: 76, alignment: .leading)
    }
}

/// Shared reading treatment for a note review, without nesting a second reply flow.
struct ReviewEvidenceExcerpt: View {
    @Environment(MeetingStore.self) private var store
    let segment: Segment
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if store.package?.audioURL != nil { SourceListenButton(segment: segment, compact: true) }
            HStack(alignment: .firstTextBaseline) {
                Text(store.speakerName(segment.speaker)).font(.subheadline.weight(.medium))
                Spacer()
                Text(store.stamp(segment.start)).font(.caption).monospacedDigit()
            }.foregroundStyle(.secondary)
            Text("“\(segment.text)”").font(.system(.body, design: .serif)).lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
            let uncertain = (segment.words ?? []).filter { ($0.confidence ?? 1) < 0.6 || !($0.alternatives ?? []).isEmpty }
            if !uncertain.isEmpty {
                Text("Check wording: " + uncertain.map { ([$0.text] + ($0.alternatives ?? []).map(\.text)).joined(separator: " / ") }.joined(separator: "; "))
                    .font(.footnote).foregroundStyle(reviewAccent)
            }
        }.padding(.horizontal, 18).padding(.top, 8).padding(.bottom, 18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.white, in: .rect(cornerRadius: 26))
    }
}

// MARK: - Keyboard

// Floating keyboard-dismiss control
struct PocketKeyboardDismissControl: ViewModifier {
    @State private var isKeyboardVisible = false
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast

    func body(content: Content) -> some View {
        content
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if isKeyboardVisible {
                    HStack {
                        Spacer()
                        dismissButton
                    }
                    .padding(.horizontal, 20).padding(.top, 4).padding(.bottom, 8)
                }
            }
            .onDisappear { isKeyboardVisible = false }
            .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in
                isKeyboardVisible = true
            }
            .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)) { _ in
                isKeyboardVisible = false
            }
    }
    private var button: some View {
        Button("Dismiss Keyboard", systemImage: "keyboard.chevron.compact.down") {
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        }
        .labelStyle(.iconOnly).font(.system(.title3, weight: .medium))
        .buttonBorderShape(.circle).controlSize(.large).tint(ink)
    }
    @ViewBuilder private var dismissButton: some View {
        if #available(iOS 26.0, *), !reduceTransparency, contrast != .increased {
            button.buttonStyle(.glass)
        } else {
            button.buttonStyle(.bordered)
        }
    }
}
