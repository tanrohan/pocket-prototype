import SwiftUI

// MARK: - Waiting

/// A slow highlight moves over the glyphs; the underlying words never disappear.
/// The animation is local to the text and does not change its layout or accessibility label.
struct WaitingText: View {
    let text: String
    var active = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.layoutDirection) private var layoutDirection

    var body: some View {
        Text(text)
            .foregroundStyle(ink.opacity(0.6))
            .fixedSize(horizontal: false, vertical: true)
            .overlay {
                if active && !reduceMotion && contrast != .increased && scenePhase == .active {
                    GeometryReader { geometry in
                        KeyframeAnimator(initialValue: -0.5, repeating: true) { phase in
                            LinearGradient(stops: [
                                .init(color: .clear, location: 0),
                                .init(color: processingBlue.opacity(0.7), location: 0.35),
                                .init(color: processingViolet.opacity(0.85), location: 0.5),
                                .init(color: processingRose.opacity(0.65), location: 0.65),
                                .init(color: .clear, location: 1)
                            ], startPoint: .leading, endPoint: .trailing)
                            .frame(width: max(70, geometry.size.width * 0.48), height: geometry.size.height)
                            .position(x: geometry.size.width * (layoutDirection == .rightToLeft ? 1 - phase : phase),
                                      y: geometry.size.height / 2)
                        } keyframes: { _ in
                            LinearKeyframe(1.5, duration: 4.8)
                        }
                    }
                    .mask { Text(text).fixedSize(horizontal: false, vertical: true) }
                    .allowsHitTesting(false).accessibilityHidden(true)
                }
            }
    }
}
