import SwiftUI

// Color belongs to processing, independently of the app's charcoal controls.
let processingBlue = Color(hex: 0x538FD8)
let processingViolet = Color(hex: 0x8B6BD1)
let processingRose = Color(hex: 0xCE77AC)

// MARK: - Processing

/// A single immediate-mode surface replaces the reference's stacked blur masks.
/// Radial falloff gives the beam its inward softness without offscreen blur passes.
struct ProcessingBorder: View {
    let running: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.scenePhase) private var scenePhase
    private var animating: Bool { running && !reduceMotion && scenePhase == .active }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !animating)) { timeline in
            Canvas(rendersAsynchronously: true) { context, size in
                guard size.width > 2, size.height > 2 else { return }
                let bounds = CGRect(origin: .zero, size: size)
                let shape = RoundedRectangle(cornerRadius: 29, style: .continuous)
                let fill = shape.path(in: bounds)
                let border = shape.path(in: bounds.insetBy(dx: 0.75, dy: 0.75))
                let colors = [processingBlue, processingViolet, processingRose]
                context.stroke(border, with: .color(appAccent.opacity(0.09)), lineWidth: 1)
                guard animating else { return }
                // Time is local to the renderer: animation never writes to the meeting store.
                let phase = timeline.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 4) / 4
                let radius = min(100, max(60, size.width * 0.25))
                // Three neighboring colors form one soft band, drawn in the same Canvas.
                // No blur layers, masks, or extra animation timelines are needed.
                for (index, color) in colors.enumerated() {
                    let location = (phase + Double(index) * 0.045).truncatingRemainder(dividingBy: 1)
                    let position = border.trimmedPath(from: location, to: min(location + 0.0001, 1)).boundingRect
                    let center = CGPoint(x: position.midX, y: position.midY)
                    if !reduceTransparency {
                        context.fill(fill, with: .radialGradient(
                            Gradient(stops: [
                                .init(color: color.opacity(0.18), location: 0),
                                .init(color: color.opacity(0.09), location: 0.35),
                                .init(color: color.opacity(0.02), location: 0.7),
                                .init(color: .clear, location: 1)
                            ]),
                            center: center, startRadius: 0, endRadius: radius
                        ))
                    }
                    context.stroke(border, with: .radialGradient(
                        Gradient(stops: [
                            .init(color: color.opacity(0.8), location: 0),
                            .init(color: color.opacity(0.35), location: 0.45),
                            .init(color: .clear, location: 1)
                        ]),
                        center: center, startRadius: 0, endRadius: radius
                    ), lineWidth: 1.5)
                }
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
