// The kit files, the people in them, and the review saved on this device.
import Foundation
import SwiftUI
import CryptoKit

// MARK: - Recording

struct Recording: Codable {
    var id: String?
    var audioFile: String?
    var startedAt: String?
    var durationSec: Double?
}

struct TranscriptFile: Codable {
    var recording: Recording?
    var segments: [Segment]
}

struct Alternative: Codable {
    var text: String
    var confidence: Double?
}

struct Word: Codable {
    var text: String
    var confidence: Double?
    var alternatives: [Alternative]?
}

struct Segment: Codable, Identifiable {
    var id: String
    var speaker: String
    var start: Double
    var end: Double
    var text: String
    var confidence: Double?
    var overlap: Bool?
    var words: [Word]?
}

// MARK: - Notes

struct Source: Codable {
    var segmentId: String
    var start: Double
    var end: Double
    var quote: String
}

struct Owner: Codable {
    var speaker: String?
    var name: String?
}

struct Note: Codable, Identifiable {
    var id: String
    var text: String
    var sources: [Source]
    var owner: Owner?
    var due: String?
    var confidence: Double?
    var sensitivity: String?
}

struct SpeakerEvidence: Codable {
    var segmentId: String
    var start: Double?
}

struct Speaker: Codable {
    var speaker: String
    var suggestedName: String
    var attendeeEmail: String?
    var confidence: Double?
    var evidence: [SpeakerEvidence]?
}

struct NotesFile: Codable {
    var recordingId: String?
    var title: String
    var summary: [Note]
    var decisions: [Note]
    var actionItems: [Note]
    var speakers: [Speaker]?
    var all: [Note] { summary + decisions + actionItems }
}

// MARK: - Stream and calendar

struct StreamFile: Codable {
    var events: [StreamEvent]
}

struct StreamEvent: Codable {
    var t: Double
    var type: String
    var id: String?
    var segmentIds: [String]?
    var section: String?
    var text: String?
}

struct CalendarFile: Codable {
    var event: MeetingEvent
}

struct MeetingEvent: Codable {
    var title: String?
    var start: String?
    var organizer: Organizer?
    var attendees: [Person]
}

struct Organizer: Codable {
    var name: String?
    var email: String?
}

struct Person: Codable, Identifiable, Hashable {
    var id: String { email }
    var name: String
    var email: String
    var title: String?
    var response: String?
    var first: String { String(name.split(separator: " ").first ?? "") }
    var initials: String { name.split(separator: " ").prefix(2).compactMap(\.first).map(String.init).joined() }
    var tint: Color {
        let colors: [UInt32] = [0x7154A1, 0x28766B, 0xA64B67, 0x386DAB, 0x9A6A26]
        let value = email.utf8.reduce(0) { ($0 + Int($1)) % colors.count }
        return Color(hex: colors[value])
    }
}

// MARK: - Saved review

struct NoteEdit: Codable {
    var text: String
    var owner: String?
    var due: String
    var privateItem: Bool
}

struct SavedDraft: Codable {
    var text: String
    var sourceIDs: [String]
}

struct ReviewState: Codable {
    var edits: [String: NoteEdit] = [:]
    var reviewed: Set<String> = []
    var excluded: Set<String> = []
    var speakerNames: [String: String] = [:]
    var speakerPeople: [String: String] = [:]
    var drafts: [String: SavedDraft] = [:]
    var checkedPriorityID: String? = nil
    var checkedPrioritySourceID: String? = nil
    var checkedOwners: [String: String]? = nil
}

struct ReviewFlag: Identifiable {
    var id: String
    var title: String
    var detail: String
    var segmentIDs: [String]
}

struct LibraryItem: Identifiable {
    var id: String
    var title: String
    var folder: URL
}

struct SearchHit: Identifiable {
    var id: String
    var note: Note?
    var segment: Segment?
    var score: Int
}

struct PackageError: LocalizedError {
    var message: String
    var errorDescription: String? { message }
}

// MARK: - Package loading

struct MeetingPackage {
    var notes: NotesFile
    var transcript: TranscriptFile
    var stream: StreamFile?
    var calendar: CalendarFile?
    var audioURL: URL?
    var folder: URL
    var key: String
    var warnings: [String]
    var duration: Double { transcript.recording?.durationSec ?? transcript.segments.map(\.end).max() ?? 0 }
    static func load(folder: URL, prefix: String = "") throws -> MeetingPackage {
        let fm = FileManager.default
        func data(_ name: String, required: Bool) throws -> Data? {
            let url = folder.appendingPathComponent(prefix + name + ".json")
            guard fm.fileExists(atPath: url.path) else {
                if required { throw PackageError(message: "Missing \(name).json. Choose the folder containing transcript.json and notes.json.") }
                return nil
            }
            let values = try url.resourceValues(forKeys: [.fileSizeKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { throw PackageError(message: "Use original files, not symbolic links, in the recording folder.") }
            let size = values.fileSize ?? 0
            guard size < 30_000_000 else { throw PackageError(message: "\(name).json is too large. This prototype supports JSON files up to 30 MB each.") }
            return try Data(contentsOf: url)
        }
        let decoder = JSONDecoder()
        let noteData = try data("notes", required: true)!, transcriptData = try data("transcript", required: true)!
        func decode<T: Decodable>(_ type: T.Type, _ value: Data, _ name: String) throws -> T {
            do { return try decoder.decode(type, from: value) }
            catch { throw PackageError(message: "Couldn’t read \(name).json in the Pocket kit format: \(error.localizedDescription)") }
        }
        let notes = try decode(NotesFile.self, noteData, "notes")
        let transcript = try decode(TranscriptFile.self, transcriptData, "transcript")
        let streamData = try data("stream", required: false), calendarData = try data("calendar", required: false)
        let stream = try streamData.map { try decode(StreamFile.self, $0, "stream") }
        let calendar = try calendarData.map { try decode(CalendarFile.self, $0, "calendar") }
        var fingerprint = Data(); fingerprint.append(noteData); fingerprint.append(transcriptData)
        if let streamData { fingerprint.append(streamData) }; if let calendarData { fingerprint.append(calendarData) }
        let key = SHA256.hash(data: fingerprint).map { String(format: "%02x", $0) }.joined()
        var warnings: [String] = []
        if let a = notes.recordingId, let b = transcript.recording?.id, a != b { throw PackageError(message: "The notes and transcript belong to different recordings.") }
        func unique(_ ids: [String], _ label: String) throws {
            guard ids.allSatisfy({ !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }), Set(ids).count == ids.count else { throw PackageError(message: "\(label) must have unique, nonempty IDs.") }
        }
        try unique(notes.all.map(\.id), "Notes"); try unique(transcript.segments.map(\.id), "Transcript segments")
        try unique(notes.speakers?.map(\.speaker) ?? [], "Speakers")
        try unique(calendar?.event.attendees.map(\.email) ?? [], "Calendar attendees")
        let segmentIDs = Set(transcript.segments.map(\.id)), noteIDs = Set(notes.all.map(\.id))
        if let duration = transcript.recording?.durationSec, !duration.isFinite || duration < 0 { throw PackageError(message: "The recording duration is invalid.") }
        for segment in transcript.segments {
            guard segment.start.isFinite, segment.end.isFinite, segment.start >= 0, segment.end >= segment.start else { throw PackageError(message: "Invalid timestamps in segment \(segment.id).") }
            if let duration = transcript.recording?.durationSec, segment.end > duration + 1 { throw PackageError(message: "Segment \(segment.id) extends past the recording duration.") }
        }
        let confidences = notes.all.compactMap(\.confidence) + transcript.segments.compactMap(\.confidence) + (notes.speakers ?? []).compactMap(\.confidence) + transcript.segments.flatMap { ($0.words ?? []).compactMap(\.confidence) }
        guard confidences.allSatisfy({ $0.isFinite && (0...1).contains($0) }) else { throw PackageError(message: "Confidence values must be between 0 and 1.") }
        for note in notes.all {
            for source in note.sources {
                guard segmentIDs.contains(source.segmentId), source.start >= 0, source.end >= source.start, source.end.isFinite else { throw PackageError(message: "Note \(note.id) contains a missing source or invalid timestamps.") }
            }
        }
        if let stream {
            var previous = -1.0
            for event in stream.events {
                guard event.t.isFinite, event.t >= 0, event.t >= previous else { throw PackageError(message: "stream.json must contain nonnegative events in time order.") }
                previous = event.t
                guard (event.segmentIds ?? []).allSatisfy({ segmentIDs.contains($0) }) else { throw PackageError(message: "The arrival stream references a missing transcript segment.") }
                if event.type.hasPrefix("notes.item."), let id = event.id, !noteIDs.contains(id) { throw PackageError(message: "The arrival stream references a missing note.") }
            }
            let completed = Set(stream.events.filter { $0.type == "notes.item.completed" }.compactMap(\.id))
            if !noteIDs.isSubset(of: completed) { warnings.append("Some notes have no completed arrival event. They appear when you choose Skip to end.") }
        } else { warnings.append("No arrival stream supplied. All file content is available immediately.") }
        if calendar == nil { warnings.append("No calendar supplied. People are derived from speaker and owner information.") }
        let audioName = transcript.recording?.audioFile ?? "meeting.m4a"
        guard URL(fileURLWithPath: audioName).lastPathComponent == audioName, !audioName.contains("\\"), audioName != ".", audioName != ".." else { throw PackageError(message: "The recording audio filename must refer to a file inside the selected folder.") }
        let audio = folder.appendingPathComponent(prefix + audioName)
        let audioExists = fm.fileExists(atPath: audio.path)
        if audioExists, try audio.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink == true { throw PackageError(message: "The audio file must be inside this folder, not a symbolic link.") }
        if !audioExists { warnings.append("Audio isn’t included. Source text remains available; playback is disabled.") }
        if notes.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { warnings.append("No recording title supplied.") }
        return MeetingPackage(notes: notes, transcript: transcript, stream: stream, calendar: calendar, audioURL: audioExists ? audio : nil, folder: folder, key: key, warnings: warnings)
    }
}

// MARK: - Color

extension Color {
    init(hex: UInt32) {
        self.init(
            red: Double((hex >> 16) & 255) / 255,
            green: Double((hex >> 8) & 255) / 255,
            blue: Double(hex & 255) / 255
        )
    }
}
