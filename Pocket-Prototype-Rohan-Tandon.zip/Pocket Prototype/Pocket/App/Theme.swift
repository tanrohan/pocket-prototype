import SwiftUI

// Shared palette. Screens use these instead of one-off colors.
let ink = Color(hex: 0x252525)
let paper = Color(hex: 0xF3F4F6)
let appAccent = Color(hex: 0x1F1F1F)
let sage = Color(hex: 0xE3EBD9)
let reviewAccent = Color(hex: 0x474747)
