// App entry point.
import SwiftUI

@main struct PocketApp: App {
    @State private var store = MeetingStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(store)
                .tint(appAccent)
                .preferredColorScheme(.light)
        }
    }
}
