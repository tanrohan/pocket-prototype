import SwiftUI

// MARK: - Topic glass

struct TopicGlassSurface: ViewModifier {
    let symbol: String
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast

    private var colors: [Color] {
        switch symbol {
        case "calendar", "doc.text.image": [Color(hex: 0xDE815E), Color(hex: 0xF5C887)]
        case "snowflake", "video": [Color(hex: 0x72A9CD), Color(hex: 0xB4DCD5)]
        case "tag", "fork.knife": [Color(hex: 0xD6AC59), Color(hex: 0xF2D5A0)]
        case "lock.shield", "arrow.up.forward": [Color(hex: 0x83A982), Color(hex: 0xCFDB9E)]
        default: [Color(hex: 0xAF9BC7), Color(hex: 0xDFC4C9)]
        }
    }

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 24, style: .continuous)
        content.background {
            Group {
                if reduceTransparency || contrast == .increased {
                    shape.fill(.white).overlay { shape.fill(colors[0].opacity(0.06)) }
                } else if #available(iOS 26.0, *) {
                    bloom
                        .clipShape(shape)
                        .glassEffect(.regular.interactive(), in: shape)
                        .background { shape.fill(.white.opacity(0.35)) }
                } else {
                    shape.fill(.thinMaterial)
                        .overlay { bloom.clipShape(shape) }
                        .overlay { shape.strokeBorder(.white.opacity(0.65), lineWidth: 1) }
                }
            }.accessibilityHidden(true)
        }
        .contentShape(shape)
    }

    private var bloom: some View {
        EllipticalGradient(stops: [
            .init(color: colors[0], location: 0),
            .init(color: colors[0].opacity(0.95), location: 0.24),
            .init(color: colors[1].opacity(0.85), location: 0.58),
            .init(color: colors[1].opacity(0.35), location: 1)
        ], center: .center, startRadiusFraction: 0, endRadiusFraction: 0.58)
        .mask {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(.white).padding(18).blur(radius: 18)
        }
        .opacity(0.24)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct TopicGlassButtonStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.975 : 1)
            .opacity(configuration.isPressed ? 0.92 : 1)
            .animation(reduceMotion ? nil : .spring(response: 0.28, dampingFraction: 0.8), value: configuration.isPressed)
    }
}
