import SwiftUI

// MARK: - Person drawer

/// Scroll-free content used inside the expanded person header on the meeting page.
struct PersonReplyContent: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @ScaledMetric(relativeTo: .headline) private var topicTitleHeight: CGFloat = 44
    let person: Person
    @State private var topic: MeetingTopic?
    @State private var search = false
    @State private var review: Note?
    @State private var draft: ReplySeed?
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Reply to \(person.first)").font(.system(.title2, design: .serif))
                    .accessibilityAddTraits(.isHeader)
                Text("Choose a topic from this meeting.").font(.subheadline).foregroundStyle(.secondary)
            }
            if let saved = store.state.drafts[person.id], let key = store.package?.key {
                Button {
                    store.haptic()
                    draft = ReplySeed(id: "saved:" + person.id, recordingKey: key, text: saved.text, sourceIDs: saved.sourceIDs, fullDraft: true)
                } label: { drawerAction("Continue your draft", symbol: "square.and.pencil") }
                    .buttonStyle(TopicGlassButtonStyle())
            }
            let topics = store.meetingTopics
            if topics.isEmpty {
                if store.complete {
                    Text("No public topics found. Search the conversation or review the notes below.")
                        .font(.subheadline).foregroundStyle(.secondary).card()
                } else {
                    WaitingText(text: "Topics will appear as the transcript arrives.", active: store.running)
                        .font(.subheadline).frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 4).padding(.vertical, 14)
                }
            }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: dynamicTypeSize.isAccessibilitySize ? 1 : 2), alignment: .leading, spacing: 12) {
                ForEach(topics) { item in
                    Button { store.haptic(); topic = item } label: {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Image(systemName: item.symbol).font(.title3).foregroundStyle(appAccent)
                                    .frame(width: 24, height: 24)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                            }
                            Text(item.title).font(.headline).foregroundStyle(ink)
                                .multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity, minHeight: topicTitleHeight, alignment: .topLeading)
                        }.padding(18).frame(maxWidth: .infinity, minHeight: 120, alignment: .topLeading)
                            .modifier(TopicGlassSurface(symbol: item.symbol))
                    }.buttonStyle(TopicGlassButtonStyle())
                        .accessibilityLabel(item.title)
                        .accessibilityValue(item.noteIDs.isEmpty ? "From the conversation" : "\(item.noteIDs.count) \(item.noteIDs.count == 1 ? "note" : "notes")")
                        .accessibilityHint("Review this topic and draft a reply to \(person.first).")
                }
            }
            Button { store.haptic(); search = true } label: { drawerAction("Find something else", symbol: "magnifyingglass") }
                .buttonStyle(TopicGlassButtonStyle())
            let tasks = store.actions(for: person)
            if !tasks.isEmpty {
                Text("\(person.first)’s next steps").font(.headline)
                ForEach(tasks) { item in Button { review = item } label: { NoteRow(note: item) }.buttonStyle(.plain) }
            }
        }
        .tint(appAccent)
        .sheet(item: $topic, onDismiss: store.stop) { topic in
            if store.transcriptReady, let answer = store.priorityDateAnswer, answer.topicID == topic.id {
                PriorityDateReview(answerID: answer.id, recipient: person)
            } else {
                TopicPage(topicID: topic.id, recipient: person)
            }
        }
        .sheet(item: $review, onDismiss: store.stop) { ReviewPage(note: $0, recipient: person) }
        .sheet(item: $draft, onDismiss: store.stop) { ReplyDraftPage(seed: $0, recipient: person) }
        .sheet(isPresented: $search, onDismiss: store.stop) { TranscriptPage(recipient: person) }
    }
    private func drawerAction(_ title: String, symbol: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: symbol).font(.body.weight(.medium)).foregroundStyle(appAccent)
                .frame(width: 24).accessibilityHidden(true)
            Text(title).font(.subheadline.weight(.medium)).foregroundStyle(ink)
                .multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 8)
            Image(systemName: "chevron.right").font(.caption.weight(.semibold))
                .foregroundStyle(.secondary).accessibilityHidden(true)
        }.padding(18).frame(maxWidth: .infinity, minHeight: 60, alignment: .leading)
            .modifier(TopicGlassSurface(symbol: symbol))
    }
}

// MARK: - Topic

struct TopicPage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let topicID: String
    let recipient: Person
    @State private var review: Note?
    @State private var draft: ReplySeed?
    private var topic: MeetingTopic? { store.meetingTopics.first { $0.id == topicID } }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    if let topic {
                        HStack { Avatar(person: recipient, size: 30); Text("For \(recipient.first)").font(.subheadline).foregroundStyle(.secondary) }
                        if let answer = store.priorityDateAnswer, answer.topicID == topic.id {
                            PriorityDateOverview(answer: answer, recipient: recipient)
                        } else {
                        let notes = store.topicNotes(topic)
                        if let first = notes.first {
                            VStack(alignment: .leading, spacing: 0) {
                                VStack(alignment: .leading, spacing: 12) {
                                    eyebrow(store.section(first).uppercased())
                                    Text(store.text(first)).font(.system(.title2, design: .serif)).lineSpacing(3)
                                }.padding(22).frame(maxWidth: .infinity, alignment: .leading)
                                ReviewHintCard(note: first) { review = first }.padding(9)
                            }.background(.white, in: .rect(cornerRadius: 29))
                            if let seed = store.replySeed(for: first) {
                                Button { draft = seed } label: { Text("Draft reply from reviewed note").primaryPill() }
                            }
                        }
                        if let source = store.topicEvidence(topic) {
                            Text("From the conversation").font(.headline)
                            EvidenceCard(segment: source, recipient: recipient)
                        }
                        if notes.count > 1 {
                            DisclosureGroup("More on this topic (\(notes.count - 1))") {
                                ForEach(Array(notes.dropFirst())) { item in Button { review = item } label: { NoteRow(note: item) }.buttonStyle(.plain).padding(.top, 12) }
                            }.font(.subheadline)
                        }
                        let otherSources = store.clip(topic.segmentIDs).filter { $0.id != store.topicEvidence(topic)?.id }
                        if !otherSources.isEmpty {
                            DisclosureGroup("Other moments") { ForEach(otherSources) { EvidenceCard(segment: $0, recipient: recipient).padding(.top, 12) } }.font(.subheadline)
                        }
                        Text("Read the excerpt to check it. Listening is optional.").font(.caption).foregroundStyle(.secondary)
                        }
                    } else { ContentUnavailableView("Topic unavailable", systemImage: "text.bubble", description: Text("Its notes may have been made private or excluded.")) }
                }.padding(22)
            }.background(paper).navigationTitle(topic?.title ?? "Topic").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { SheetDoneButton { dismiss() } } }
                .sheet(item: $review, onDismiss: store.stop) { ReviewPage(note: $0, recipient: recipient) }
                .sheet(item: $draft, onDismiss: store.stop) { ReplyDraftPage(seed: $0, recipient: recipient) }
        }.tint(appAccent).presentationDragIndicator(.visible)
    }
}

// MARK: - Reply

struct ReplyDraftPage: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let seed: ReplySeed
    @State private var person: Person?
    @State private var text = ""
    @State private var checked = false
    @State private var copied = false
    @State private var changed = false
    @State private var invalidated = false
    @FocusState private var editingMessage: Bool
    init(seed: ReplySeed, recipient: Person? = nil) {
        self.seed = seed
        _person = State(initialValue: recipient)
    }
    private var pickingRecipient: Bool { person == nil }
    private var dateAlreadyConfirmed: Bool { seed.priorityAnswerID != nil && store.canUseReply(seed) }
    private var outgoing: String? { invalidated ? nil : store.confirmedReply(text, seed: seed, confirmed: checked || dateAlreadyConfirmed) }
    // Match the spotlight's existing missed-meeting priority, without hardcoded names.
    private var recipients: [Person] {
        store.otherPeople.filter { $0.response == "declined" } + store.otherPeople.filter { $0.response != "declined" }
    }
    var body: some View {
        NavigationStack {
            Group {
                if !store.canUseReply(seed) || invalidated {
                    ContentUnavailableView("This material is no longer available", systemImage: "lock", description: Text("It may have been made private, excluded, or changed. Return to the meeting to choose another source."))
                } else if pickingRecipient {
                    recipientPicker
                } else if let person {
                    messageReview(person)
                }
            }
            .background(paper)
            .navigationTitle(pickingRecipient ? "Draft reply" : "Review reply")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        if #available(iOS 26.0, *) {
                            Button(role: .close) { dismiss() }.tint(ink).accessibilityLabel("Close")
                        } else {
                            Button("Close", systemImage: "xmark") { dismiss() }.labelStyle(.iconOnly).tint(ink)
                        }
                    }
            }
            .safeAreaInset(edge: .bottom) {
                if !pickingRecipient && !editingMessage && store.canUseReply(seed) && !invalidated { replyActions }
            }
            .onAppear { if let person, text.isEmpty { prepare(person) } }
            .onChange(of: text) { _, value in
                checked = false; copied = false
                if let person, !value.isEmpty, store.canUseReply(seed), !invalidated {
                    store.saveDraft(value, for: person, sources: seed.sourceIDs)
                }
            }
            .onChange(of: store.revision) { _, _ in checked = false; text = ""; changed = true; invalidated = seed.fullDraft }
            .onChange(of: store.package?.key) { _, _ in dismiss() }
        }.modifier(PocketKeyboardDismissControl())
            .tint(appAccent).foregroundStyle(ink).presentationDragIndicator(.visible)
    }
    private var recipientPicker: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Who’s this for?").font(.system(.title2, design: .serif)).accessibilityAddTraits(.isHeader)
                    Text("Choose someone from this meeting.").font(.subheadline).foregroundStyle(.secondary)
                }
                if recipients.isEmpty {
                    ContentUnavailableView("No recipients", systemImage: "person.crop.circle", description: Text("No people are available in this recording’s files."))
                } else {
                    VStack(spacing: 0) {
                        ForEach(recipients) { contact in
                            Button {
                                editingMessage = false
                                if person?.id != contact.id { prepare(contact) }
                                person = contact
                                store.haptic()
                            } label: {
                                HStack(spacing: 12) {
                                    Avatar(person: contact, size: 42).accessibilityHidden(true)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(contact.name).font(.body.weight(.medium)).foregroundStyle(ink)
                                        Text((contact.title ?? "Participant") + (contact.response == "declined" ? " · Didn’t attend" : ""))
                                            .font(.caption).foregroundStyle(.secondary)
                                    }.multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                                    Spacer(minLength: 8)
                                    Image(systemName: person?.id == contact.id ? "checkmark" : "chevron.right")
                                        .font(.caption.weight(.semibold)).foregroundStyle(.secondary).accessibilityHidden(true)
                                }.padding(18).frame(maxWidth: .infinity, minHeight: 78, alignment: .leading)
                                    .contentShape(Rectangle())
                            }.buttonStyle(ReplyRecipientButtonStyle())
                                .accessibilityHint("Review a reply for \(contact.first).")
                            if contact.id != recipients.last?.id {
                                Divider().padding(.leading, 72).padding(.trailing, 18)
                            }
                        }
                    }.background(.white, in: .rect(cornerRadius: 29)).clipShape(.rect(cornerRadius: 29))
                }
            }.padding(20)
        }.scrollIndicators(.hidden)
    }
    private func messageReview(_ person: Person) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                if changed { Text("The recording changed. Check a fresh draft before sharing.").font(.footnote).foregroundStyle(appAccent) }
                Menu {
                    Picker("Recipient", selection: Binding(
                        get: { self.person?.id ?? "" },
                        set: { id in
                            guard let contact = recipients.first(where: { $0.id == id }), self.person?.id != id else { return }
                            editingMessage = false
                            prepare(contact)
                            self.person = contact
                            store.haptic()
                        }
                    )) {
                        ForEach(recipients) { contact in
                            Text(contact.name).tag(contact.id)
                        }
                    }.pickerStyle(.inline)
                } label: {
                    HStack(spacing: 12) {
                        Avatar(person: person, size: 44).accessibilityHidden(true)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("To \(person.name)").font(.body.weight(.medium)).foregroundStyle(ink)
                            if let title = person.title {
                                Text(title).font(.subheadline).foregroundStyle(.secondary)
                            }
                        }
                        Spacer(minLength: 8)
                        Image(systemName: "chevron.up.chevron.down")
                            .font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                    }.padding(16).contentShape(Rectangle())
                }.buttonStyle(.plain)
                    .background(.white, in: .rect(cornerRadius: 26))
                    .accessibilityLabel("Reply to \(person.name)")
                    .accessibilityHint("Choose a recipient without leaving your reply")
                VStack(alignment: .leading, spacing: 12) {
                    Text("Message").font(.headline).accessibilityAddTraits(.isHeader)
                    VStack(alignment: .leading, spacing: 0) {
                        TextField("Write your reply", text: $text, axis: .vertical)
                            .font(.body).lineSpacing(5).lineLimit(3...20).textFieldStyle(.plain)
                            .focused($editingMessage).padding(20)
                            .accessibilityLabel("Reply draft")
                            .accessibilityHint("Tap to edit the message.")
                        if !dateAlreadyConfirmed {
                        Button {
                            editingMessage = false; checked.toggle(); store.haptic()
                        } label: {
                            HStack(spacing: 12) {
                                OwnerSelectionMark(selected: checked).accessibilityHidden(true)
                                Text(checked ? "Ready to share" : "I’ve checked this reply")
                                    .font(.subheadline.weight(.medium))
                                Spacer(minLength: 0)
                            }.foregroundStyle(checked ? reviewAccent : ink.opacity(0.7))
                                .padding(16).frame(minHeight: 50)
                                .background(checked ? appAccent.opacity(0.08) : paper.opacity(0.7), in: .rect(cornerRadius: 20))
                                .contentShape(Rectangle())
                        }.buttonStyle(.plain).padding(6)
                            .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                            .accessibilityValue(checked ? "Checked" : "Not checked")
                        }
                    }.background(.white, in: .rect(cornerRadius: 26))
                    Text("Only this message is shared. Transcript and recording stay here.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    Button("Rebuild from source") { prepare(person) }.font(.subheadline)
                }
                SourceContextStack(moments: store.clip(seed.sourceIDs).map { ContextMoment(segment: $0) }) { moment in
                    VStack(alignment: .leading, spacing: 14) {
                        SourceExcerptHeader(segment: moment.segment)
                        Text("“\(moment.segment.text)”")
                            .font(.system(.body, design: .serif)).lineSpacing(3)
                            .fixedSize(horizontal: false, vertical: true)
                    }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
                        .background(.white, in: .rect(cornerRadius: 26))
                }
            }.padding(.horizontal, 20).padding(.vertical, 12)
        }.scrollDismissesKeyboard(.interactively).scrollIndicators(.hidden)
    }
    private var replyActions: some View {
        VStack(spacing: 10) {
            if !store.transcriptReady {
                WaitingText(text: "Waiting for the full conversation", active: store.running).font(.caption)
            }
            HStack(spacing: 12) {
                Button {
                    if let outgoing { UIPasteboard.general.string = outgoing; copied = true; store.haptic() }
                } label: {
                    Text(copied ? "Copied" : "Copy reply")
                        .font(.headline).foregroundStyle(.white)
                        .frame(maxWidth: .infinity).padding(.vertical, 4)
                }.modifier(OwnerApplyButtonStyle())
                ShareLink(item: outgoing ?? "") {
                    Image(systemName: "square.and.arrow.up")
                        .font(.title2.weight(.medium)).frame(width: 28, height: 28)
                }.modifier(ReplyShareButtonStyle()).accessibilityLabel("Share reply")
            }.disabled(outgoing == nil)
        }
        .padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 12)
    }
    private func prepare(_ person: Person) {
        text = store.replyText(for: person, seed: seed); checked = false; copied = false; changed = false
        if !text.isEmpty { store.saveDraft(text, for: person, sources: seed.sourceIDs) }
    }
}

// MARK: - Reply controls

private struct ReplyRecipientButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.background(ink.opacity(configuration.isPressed ? 0.04 : 0))
    }
}

private struct ReplyShareButtonStyle: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *), !reduceTransparency, contrast != .increased {
            content.buttonStyle(.glass).buttonBorderShape(.circle).controlSize(.large).tint(ink)
        } else {
            content.buttonStyle(.bordered).buttonBorderShape(.circle).controlSize(.large).tint(ink)
        }
    }
}
