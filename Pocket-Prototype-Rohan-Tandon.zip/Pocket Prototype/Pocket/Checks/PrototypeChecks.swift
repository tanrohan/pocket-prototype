#if DEBUG
// Debug checks for both recordings. Launch with -self-test.
import Foundation

// MARK: - Checks

extension MeetingStore {
    func runChecks() {
        var results: [[String: Any]] = []
        func check(_ label: String, _ value: Bool) { results.append(["check": label, "passed": value]) }
        let root = URL.temporaryDirectory.appending(path: "pocket-check-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: root) }
        do {
            try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
            let bundle = Bundle.main.resourceURL!
            let original = try MeetingPackage.load(folder: bundle)
            let second = try MeetingPackage.load(folder: bundle, prefix: "sample_")
            let selectedFolder = UserDefaults.standard.string(forKey: "pocket.activeFolder")
            let selectedSample = UserDefaults.standard.object(forKey: "pocket.activeSample") as? Bool
            let switchModel = MeetingStore(loadDefault: false, persist: false)
            try switchModel.loadBundled(sample: true, ready: true)
            check("Selecting Studio opens its completed recording", switchModel.package?.key == second.key && switchModel.complete && !switchModel.running)
            try switchModel.loadBundled(sample: false, ready: true)
            check("Switching back to Atlas does not replay arrival", switchModel.package?.key == original.key && switchModel.complete && switchModel.transcriptReady && !switchModel.running && switchModel.visibleNotes.count == original.notes.all.count)
            let settledTime = switchModel.elapsed
            switchModel.tick()
            check("A selected recording stays settled on later clock ticks", switchModel.elapsed == settledTime && switchModel.visibleNotes.count == original.notes.all.count)
            switchModel.restart()
            check("Replay still unfolds arrival after selecting a completed recording", switchModel.elapsed == 0 && switchModel.running && !switchModel.complete && switchModel.visibleNotes.isEmpty)
            try switchModel.loadBundled()
            check("The initial case-study experience still starts with arrival", switchModel.package?.key == original.key && switchModel.elapsed == 0 && switchModel.running && !switchModel.complete)
            check("Preview recording switches preserve the saved active recording", UserDefaults.standard.string(forKey: "pocket.activeFolder") == selectedFolder && (UserDefaults.standard.object(forKey: "pocket.activeSample") as? Bool) == selectedSample)
            let model = MeetingStore(loadDefault: false, persist: false, libraryRoot: root.appending(path: "library"))
            try model.apply(original)
            check("Original kit loads without fixture-specific IDs in the loader", model.allNotes.count == 26 && model.segments.count == 300)
            var spotlight = PeopleSpotlightState()
            spotlight.reconcile(model.otherPeople)
            let initialPerson = spotlight.focused(in: model.otherPeople)!
            check("Spotlight prefers a missed-meeting recipient from the calendar", initialPerson.response == "declined")
            spotlight.open(initialPerson, among: model.otherPeople)
            let expandedID = spotlight.focusedID
            var appended = model.otherPeople
            appended.append(Person(name: "New speaker", email: "later-speaker@example.test", title: nil, response: nil))
            spotlight.reconcile(appended)
            check("New speakers do not steal an expanded spotlight", spotlight.isExpanded && spotlight.focusedID == expandedID)
            spotlight.isExpanded = false
            spotlight.reconcile(appended)
            check("Collapsing preserves the selected recipient", spotlight.focusedID == expandedID)
            spotlight.open(initialPerson, among: appended)
            spotlight.reconcile([])
            check("Empty recording clears spotlight and expanded content", spotlight.focusedID == nil && !spotlight.isExpanded)
            spotlight.reconcile(second.calendar?.event.attendees ?? [])
            check("Different recording does not keep the previous recipient", spotlight.focusedID != expandedID && !spotlight.isExpanded)
            spotlight.focusedID = appended.first?.id
            spotlight.move(-1, among: appended)
            check("Carousel cannot step before its first person", spotlight.focusedID == appended.first?.id)
            spotlight.focusedID = appended.last?.id
            spotlight.move(1, among: appended)
            check("Carousel cannot step past its last person", spotlight.focusedID == appended.last?.id)
            model.elapsed = 5

            // MARK: Arrival timing
            check("No premature transcript or notes", model.availableSegments.isEmpty && model.visibleNotes.isEmpty)
            check("Topics do not leak unarrived recording content", model.meetingTopics.isEmpty)
            check("Priority request is not known at five seconds", model.priorityDateAnswer == nil)
            model.elapsed = 27.19
            check("Priority waits for its transcript batch", model.priorityDateAnswer == nil)
            model.elapsed = 30
            check("Partial transcript follows actual batch timing", model.availableSegments.count == 71 && !model.transcriptReady)
            let earlySource = model.availableSegments.first!
            if let earlySeed = model.replySeed(for: earlySource) {
                check("Source reply cannot be shared before full transcript", model.confirmedReply("Draft", seed: earlySeed, confirmed: true) == nil)
            }
            let earlyAnswer = model.priorityDateAnswer!
            check("Early priority comes from the request and early date", earlyAnswer.recipient?.first == "Rachel" && earlyAnswer.latest?.date == "October 27" && !earlyAnswer.hasUpdate)
            model.checkPriorityAnswer(earlyAnswer)
            check("An early date cannot be checked or drafted as an answer", !model.isChecked(earlyAnswer) && model.priorityReplySeed(for: earlyAnswer) == nil)
            let earlyDateSeed = model.replySeed(for: earlyAnswer.latest!.source)!
            model.elapsed = 42.79
            check("Ending does not leak before its batch", model.priorityDateAnswer?.latest?.date == "October 27" && !model.transcriptReady)
            model.elapsed = 42.8
            let updatedAnswer = model.priorityDateAnswer!
            check("Final batch exposes the later date before generated notes", model.transcriptReady && updatedAnswer.latest?.date == "November 10" && updatedAnswer.latest?.source.id == "seg_274" && model.visibleNotes.isEmpty)
            check("The date review includes the nearby explicit agreement", updatedAnswer.confirmation?.id == "seg_278")
            check("An earlier source draft is invalid after a date update", !model.canUseReply(earlyDateSeed) && model.confirmedReply("October 27", seed: earlyDateSeed, confirmed: true) == nil)
            check("An update remains a proposal until checked", !model.isChecked(updatedAnswer) && model.priorityReplySeed(for: updatedAnswer) == nil && !model.hasOutdatedNote(for: updatedAnswer))
            model.checkPriorityAnswer(updatedAnswer)
            let checkedAnswerSeed = model.priorityReplySeed(for: updatedAnswer)!
            check("Date check does not approve whole notes or require audio", model.isChecked(updatedAnswer) && model.state.reviewed.isEmpty && model.shareableNotes.isEmpty && model.playingID == nil)
            check("Priority reply uses only the current date with a linked source", checkedAnswerSeed.text == "Launch date: November 10." && checkedAnswerSeed.sourceIDs == ["seg_274", "seg_278"] && model.confirmedReply(checkedAnswerSeed.text, seed: checkedAnswerSeed, confirmed: true) != nil)
            let earlierMoment = updatedAnswer.first!
            model.checkPriorityAnswer(updatedAnswer, sourceID: earlierMoment.source.id)
            let earlierChoiceSeed = model.priorityReplySeed(for: updatedAnswer)!
            check("Explicit earlier date choice drives reply and its evidence", earlierChoiceSeed.text == "Launch date: October 27." && earlierChoiceSeed.sourceIDs == [earlierMoment.source.id] && model.canUseReply(earlierChoiceSeed))
            check("Changing date selection invalidates the previous date draft", !model.canUseReply(checkedAnswerSeed))
            let restoredChoice = try JSONDecoder().decode(ReviewState.self, from: JSONEncoder().encode(model.state))
            check("Selected date survives saved review encoding", restoredChoice.checkedPrioritySourceID == earlierMoment.source.id)
            model.checkPriorityAnswer(updatedAnswer)
            check("Choosing the later date again invalidates the earlier draft", model.canUseReply(checkedAnswerSeed) && !model.canUseReply(earlierChoiceSeed))
            model.elapsed = 43.5
            check("Full transcript precedes generated notes", model.transcriptReady && model.visibleNotes.isEmpty)
            let dateSource = model.segments.first { $0.id == "seg_274" }!
            let dateSeed = model.replySeed(for: dateSource)!
            let rachel = model.people.first { $0.first == "Rachel" }!

            // MARK: Topics and replies
            check("Topics available before generated summary", model.meetingTopics.contains { $0.id == "launch" } && model.visibleNotes.isEmpty)
            check("Topic suggestions only reference arrived content", model.meetingTopics.allSatisfy { Set($0.segmentIDs).isSubset(of: Set(model.availableSegments.map(\.id))) })
            check("Source draft carries exact excerpt and selected recipient", model.replyText(for: rachel, seed: dateSeed).contains(dateSource.text) && model.replyText(for: rachel, seed: dateSeed).contains("Hi Rachel"))
            check("Excerpt replies identify the speaker directly", model.replyText(for: rachel, seed: dateSeed) == "Hi Rachel,\n\nMaya Chen: “\(dateSource.text)”")
            check("Source reply requires explicit draft confirmation", model.confirmedReply("Draft", seed: dateSeed, confirmed: false) == nil)
            check("Reading and confirming is sufficient without playback", model.confirmedReply("Read and checked", seed: dateSeed, confirmed: true) == "Read and checked" && model.playingID == nil)
            model.elapsed = 56.9
            check("Partial note streams before completion", model.partialNote != nil && model.visibleNotes.isEmpty)
            check("Unfinished overview stays hidden", model.overviewNote == nil)
            model.elapsed = 56.91
            check("First note completion follows supplied stream", model.visibleNotes.count == 1)
            check("Stale summary cannot overwrite a checked priority date", model.priorityDateAnswer?.id == updatedAnswer.id && model.isChecked(updatedAnswer) && model.hasOutdatedNote(for: updatedAnswer) && model.overviewNote?.text.contains("October 27") == true)
            model.changed()
            check("Review changes revoke a date confirmation and its draft", !model.isChecked(updatedAnswer) && !model.canUseReply(checkedAnswerSeed))
            model.skip()
            let anchored = model.overviewNote?.id
            check("Later notes do not replace the overview", anchored == original.notes.summary.first?.id)
            if let overview = model.overviewNote {
                model.review(overview, text: overview.text, owner: nil, due: "", privateItem: false)
                check("Reviewing overview keeps its position", model.overviewNote?.id == anchored)
                model.resetReview()
            }

            // MARK: Review and privacy
            check("Nothing is shareable without human review", model.shareableNotes.isEmpty)
            let privateNote = original.notes.summary.first { $0.text.lowercased().contains("medical procedure") }!
            check("Privacy language overrides misleading model sensitivity", privateNote.sensitivity == "none" && model.isPrivate(privateNote))
            check("Later-date comparison is derived from content", model.flags(original.notes.summary[0]).contains { $0.id.hasSuffix(":later") })
            check("Overview source prioritizes later conflicting date", model.focusEvidence(for: original.notes.summary[0])?.id == "seg_274")
            let summaryDateNote = original.notes.summary[0]
            let summaryDateText = model.replacingLaunchDate(in: summaryDateNote.text, with: "November 10")
            check("Date choices are available from both summary and launch decision", model.launchDateAnswer(for: summaryDateNote) != nil && model.launchDateAnswer(for: original.notes.decisions[0]) != nil)
            check("Launch choice never substitutes the code-freeze date", summaryDateText.contains("launch Atlas on November 10") && summaryDateText.contains("code freeze on October 20") && model.launchDateAnswer(for: original.notes.decisions[1]) == nil)
            check("Date substitution preserves unrelated edits", model.replacingLaunchDate(in: summaryDateNote.text + " Keep the rollout gradual.", with: "November 10").hasSuffix(" Keep the rollout gradual."))
            check("A date can be restored without losing the original weekday", model.replacingLaunchDate(in: summaryDateText, with: model.launchDatePhrase(in: summaryDateNote.text)!) == summaryDateNote.text)
            check("Code-freeze ordinal update is surfaced without inventing a month", model.flags(original.notes.decisions[1]).contains { $0.id.hasSuffix(":later") && $0.segmentIDs.contains("seg_280") })
            check("Summary context includes the separate code-freeze change", model.flags(summaryDateNote).contains { $0.segmentIDs.contains("seg_280") })
            let dateAuditAnswer = model.priorityDateAnswer!
            model.checkPriorityAnswer(dateAuditAnswer, sourceID: dateAuditAnswer.first!.source.id)
            check("Reopened date review can recover the earlier confirmed selection", model.checkedDateMoment(for: dateAuditAnswer)?.date == "October 27")
            model.checkPriorityAnswer(dateAuditAnswer, sourceID: "missing-source")
            check("Unknown date source cannot change a confirmed choice", model.checkedDateMoment(for: dateAuditAnswer)?.date == "October 27")
            model.checkPriorityAnswer(dateAuditAnswer, sourceID: dateAuditAnswer.latest!.source.id)
            check("Previously confirmed date can be changed again", model.checkedDateMoment(for: dateAuditAnswer)?.date == "November 10")

            if let launch = model.meetingTopics.first(where: { $0.id == "launch" }) {
                check("Topic opens with a decision rather than search-results list", model.topicNotes(launch).first?.id == "dec_1")
            }
            let privateSource = model.clip(privateNote.sources.map(\.segmentId)).first!
            check("Private excerpt cannot create a draft", model.replySeed(for: privateSource) == nil)
            let firstDecision = original.notes.decisions[0]
            model.review(firstDecision, text: "Launch on November 10.", owner: nil, due: "", privateItem: false)
            check("Reviewed edits drive outgoing message", model.shareText([firstDecision.id]).contains("November 10"))
            let reviewedSeed = model.replySeed(for: firstDecision)!
            model.review(firstDecision, text: "Launch on November 17.", owner: nil, due: "", privateItem: false)
            check("A changed reviewed note invalidates its earlier draft seed", !model.canUseReply(reviewedSeed))
            check("Original transcript is never rewritten", model.segments.contains { $0.text.contains("October 27th") })
            let replayAnswer = model.priorityDateAnswer!
            model.checkPriorityAnswer(replayAnswer)
            let replaySeed = model.priorityReplySeed(for: replayAnswer)!
            model.saveDraft("Hi Rachel, launch date: November 10.", for: rachel, sources: replaySeed.sourceIDs)
            model.state.excluded.insert(original.notes.summary.last!.id)
            model.state.speakerNames["S2"] = "Corrected speaker"
            model.state.speakerPeople["S2"] = rachel.id
            model.state.checkedOwners = [original.notes.actionItems[0].id: rachel.id]
            let replayRevision = model.revision
            model.restart()

            // MARK: Replay and reset
            check("Replay rewinds arrival and clears the date check and saved replies", model.elapsed == 0 && model.running && !model.revealAll && model.state.checkedPriorityID == nil && model.state.drafts.isEmpty && model.revision > replayRevision)
            model.skip()
            check("Completing a replay does not restore Checked by you", !model.isChecked(replayAnswer) && !model.canUseReply(replaySeed))
            check("Replay restores original notes and clears review work", model.text(firstDecision) == firstDecision.text && model.state.reviewed.isEmpty && model.state.edits.isEmpty && model.state.excluded.isEmpty && model.state.speakerNames.isEmpty && model.state.speakerPeople.isEmpty && (model.state.checkedOwners ?? [:]).isEmpty && model.state.checkedPrioritySourceID == nil)
            check("Replay keeps the recording and its original source files", model.package?.key == original.key && model.segments.count == original.transcript.segments.count && model.allNotes.count == original.notes.all.count)
            model.checkPriorityAnswer(model.priorityDateAnswer!)
            model.saveDraft("A checked draft", for: rachel, sources: replaySeed.sourceIDs)
            model.resetReview()
            check("Reset review clears date confirmation as well as note edits and drafts", model.state.checkedPriorityID == nil && model.state.reviewed.isEmpty && model.state.edits.isEmpty && model.state.drafts.isEmpty)
            try model.apply(second, ready: true)

            // MARK: Second recording
            check("No priority is invented for a recording without an explicit request", model.priorityDateAnswer == nil && model.state.checkedPriorityID == nil)
            check("Second recording replaces title, duration and people", model.title == "Studio opening review" && model.recordingDuration == 50 && model.people.contains { $0.name == "Jules Bell" } && !model.people.contains { $0.name == "Rachel Kim" })
            check("Draft cannot cross recording boundaries", !model.canUseReply(dateSeed))
            check("Second recording has its own topic labels", model.meetingTopics.contains { $0.title == "Opening date" } && model.meetingTopics.contains { $0.title == "Invitations" } && !model.meetingTopics.contains { $0.id == "launch" })
            check("Different recording cannot inherit review state", model.state.reviewed.isEmpty && model.state.edits.isEmpty)
            check("Second recording uses its own 18-second timeline", model.duration == 18)
            model.restart(); model.elapsed = 3
            check("Second recording gates its own segment IDs", model.availableSegments.count == 2 && model.visibleNotes.isEmpty)
            model.elapsed = 10.4
            check("Second recording renders note deltas", model.partialNote?.contains("studio") == true)
            model.skip()
            check("Skip during partial arrival reveals all files and ends processing", model.complete && !model.running && model.elapsed == model.duration && model.availableSegments.count == model.segments.count && model.allNotes.allSatisfy { model.available($0.id) })
            check("Skip is safe to repeat", { model.skip(); return model.complete && model.revealAll && !model.running }())
            check("Second recording detects tentative assignment", model.flags(second.notes.actionItems[1]).contains { $0.id.hasSuffix(":tentative") })
            check("Second recording detects private text", model.isPrivate(second.notes.summary[1]))
            check("Missing audio has explicit fallback", second.audioURL == nil && second.warnings.contains { $0.contains("Audio") })
            check("Search uses arbitrary topic words", model.search("invitation artwork").contains { $0.note?.id == "todo-art" })
            check("Unmatched question produces no fabricated answer", model.search("underwater volcano").isEmpty)
            let task = second.notes.actionItems[0], owen = model.people.first { $0.first == "Owen" }!
            check("Compose rejects unreviewed material", model.compose(for: owen, from: [task]).isEmpty)
            model.review(task, text: task.text, owner: owen.id, due: "2027-04-08", privateItem: false)
            let reply = model.compose(for: owen, from: [task])
            check("Generic reply uses current recipient and source", reply.contains("Hi Owen") && reply.contains(task.text) && !reply.contains("Atlas"))
            model.saveDraft(reply, for: owen, sources: task.sources.map(\.segmentId))
            let count = model.replaceAcrossNotes(old: "invitation artwork", new: "invitation design")
            check("Bulk replacement returns changed notes to review", count > 0 && !model.state.reviewed.contains(task.id) && model.state.drafts.isEmpty)
            model.setSpeaker("voice-green", name: "Owen New", personID: nil)
            check("Speaker correction is generic", model.speakerName("voice-green") == "Owen New")
            model.review(second.notes.summary[1], text: second.notes.summary[1].text, owner: nil, due: "", privateItem: true)
            check("Reviewed private note still excluded", !model.shareableNotes.contains { $0.id == second.notes.summary[1].id })
            model.exclude(task)
            check("Excluded task leaves person assignments", !model.actions.contains { $0.id == task.id })
            model.restore(task)
            check("Restoring task requires review again", model.actions.contains { $0.id == task.id } && !model.state.reviewed.contains(task.id))
            let candidate = root.appending(path: "candidate")
            try FileManager.default.createDirectory(at: candidate, withIntermediateDirectories: true)
            for name in ["notes", "transcript", "calendar", "stream"] { try FileManager.default.copyItem(at: bundle.appendingPathComponent("sample_" + name + ".json"), to: candidate.appendingPathComponent(name + ".json")) }
            model.importFolder(candidate)

            // MARK: Import
            check("Folder import copies and opens validated recording", model.importError == nil && model.library.count == 1 && model.package?.folder != candidate)
            let activeKey = model.package?.key
            var bad = second.notes; bad.recordingId = "different-recording"
            try JSONEncoder().encode(bad).write(to: candidate.appendingPathComponent("notes.json"))
            model.importFolder(candidate)
            check("Invalid import preserves active recording", model.importError != nil && model.package?.key == activeKey)
            func rejects(_ name: String, _ body: () throws -> Void) {
                do { try body(); check(name, false) } catch { check(name, true) }
            }
            try JSONEncoder().encode(second.notes).write(to: candidate.appendingPathComponent("notes.json"))
            var brokenTranscript = second.transcript
            brokenTranscript.segments[1].id = brokenTranscript.segments[0].id
            try JSONEncoder().encode(brokenTranscript).write(to: candidate.appendingPathComponent("transcript.json"))
            rejects("Duplicate IDs rejected") { _ = try MeetingPackage.load(folder: candidate) }
            brokenTranscript = second.transcript; brokenTranscript.recording?.audioFile = "../secret.m4a"
            try JSONEncoder().encode(brokenTranscript).write(to: candidate.appendingPathComponent("transcript.json"))
            rejects("Audio path traversal rejected") { _ = try MeetingPackage.load(folder: candidate) }
            try JSONEncoder().encode(second.transcript).write(to: candidate.appendingPathComponent("transcript.json"))
            var badStream = second.stream!; badStream.events[1].t = -1
            try JSONEncoder().encode(badStream).write(to: candidate.appendingPathComponent("stream.json"))
            rejects("Invalid stream ordering rejected") { _ = try MeetingPackage.load(folder: candidate) }
            try FileManager.default.removeItem(at: candidate.appendingPathComponent("stream.json"))
            try FileManager.default.removeItem(at: candidate.appendingPathComponent("calendar.json"))
            let minimal = try MeetingPackage.load(folder: candidate)
            try model.apply(minimal)
            check("Minimal notes/transcript package works", model.transcriptReady && model.visibleNotes.count == second.notes.all.count && model.people.contains { $0.name == "Owen Park" })
            var renamed = original
            renamed.key = "different-priority-recording"
            renamed.transcript.segments = renamed.transcript.segments.map { segment in
                var value = segment
                value.text = value.text.replacingOccurrences(of: "Rachel", with: "Dana").replacingOccurrences(of: "October 27th", with: "April 3rd").replacingOccurrences(of: "November 10th", with: "May 12th")
                value.id = "other-" + segment.id
                return value
            }
            renamed.notes.summary = []; renamed.notes.decisions = []; renamed.notes.actionItems = []
            renamed.calendar?.event.attendees = [Person(name: "Dana Rivers", email: "dana@example.test", title: nil, response: "declined")]
            try model.apply(renamed, ready: true)
            check("Priority extraction works with different names, dates, and segment IDs", model.priorityDateAnswer?.recipient?.first == "Dana" && model.priorityDateAnswer?.first?.date == "April 3" && model.priorityDateAnswer?.latest?.date == "May 12")
            var hiddenEnding = original
            hiddenEnding.key = "hidden-date-source"
            let ending = hiddenEnding.transcript.segments.first { $0.id == "seg_274" }!
            hiddenEnding.notes.summary.append(Note(id: "private-date", text: ending.text,
                sources: [Source(segmentId: ending.id, start: ending.start, end: ending.end, quote: ending.text)], sensitivity: "private"))
            try model.apply(hiddenEnding, ready: true)
            check("Hiding a later date cannot promote its superseded earlier date", model.priorityDateAnswer == nil)
            var hypothetical = renamed
            hypothetical.key = "hypothetical-date"
            hypothetical.transcript.segments.append(Segment(id: "unagreed", speaker: "S1", start: 1700, end: 1705, text: "What if we move launch to June 21?"))
            try model.apply(hypothetical, ready: true)
            check("A hypothetical date is not promoted over a stated update", model.priorityDateAnswer?.latest?.date == "May 12")
            let encoded = try JSONEncoder().encode(model.state)
            var legacy = try JSONSerialization.jsonObject(with: encoded) as! [String: Any]
            legacy.removeValue(forKey: "checkedPriorityID")
            let legacyData = try JSONSerialization.data(withJSONObject: legacy)
            check("Existing saved reviews decode without the new date field", (try JSONDecoder().decode(ReviewState.self, from: legacyData)).checkedPriorityID == nil)
            check("Review state round-trips", (try JSONDecoder().decode(ReviewState.self, from: encoded)).reviewed == model.state.reviewed)
            let ownerModel = MeetingStore(loadDefault: false, persist: false, libraryRoot: root.appending(path: "owner-library"))
            try ownerModel.apply(original, ready: true)
            let checklist = original.notes.actionItems.first { $0.id == "act_1" }!
            let arjun = ownerModel.people.first { $0.first == "Arjun" }!
            let tom = ownerModel.people.first { $0.first == "Tom" }!
            let ownerContext = ownerModel.ownerReviewContext(for: checklist)!
            if let disputedSource = ownerModel.clip(checklist.sources.map(\.segmentId)).first, let disputedSeed = ownerModel.replySeed(for: disputedSource) {
                check("Disputed speaker attribution stays qualified in replies", ownerModel.replyText(for: rachel, seed: disputedSeed).contains("Tom Alvarez (speaker needs checking):"))
            }
            check("Owner suggestion comes from the adjacent exchange", ownerContext.suggestedPerson?.id == arjun.id && ownerContext.offer?.id == "seg_106" && ownerContext.response?.id == "seg_107")
            check("Owner playback covers the offer and response", ownerContext.playback?.start == 636.19 && ownerContext.playback?.end == 643.72)
            let initialOwnerRevision = ownerModel.revision
            check("Opening owner review makes no correction", ownerModel.ownerID(checklist) == tom.id && ownerModel.state.edits.isEmpty && ownerModel.state.reviewed.isEmpty)

            // MARK: Owner confirmation
            check("Owner confirmation rejects a different recording", !ownerModel.confirmOwner(noteID: checklist.id, personID: arjun.id, recordingKey: second.key, expectedRevision: initialOwnerRevision))
            check("Owner confirmation rejects stale review and unknown people", !ownerModel.confirmOwner(noteID: checklist.id, personID: arjun.id, recordingKey: original.key, expectedRevision: initialOwnerRevision - 1) && !ownerModel.confirmOwner(noteID: checklist.id, personID: "unknown", recordingKey: original.key, expectedRevision: initialOwnerRevision))
            ownerModel.saveDraft("Old owner", for: rachel, sources: checklist.sources.map(\.segmentId))
            let otherTomOwners = Dictionary(uniqueKeysWithValues: ownerModel.actions.filter { $0.id != checklist.id && ownerModel.ownerID($0) == tom.id }.map { ($0.id, ownerModel.ownerID($0)) })
            check("Explicit owner confirmation succeeds", ownerModel.confirmOwner(noteID: checklist.id, personID: arjun.id, recordingKey: original.key, expectedRevision: ownerModel.revision))
            check("Owner correction resolves this task and its warning", ownerModel.ownerID(checklist) == arjun.id && ownerModel.flags(checklist).isEmpty && ownerModel.state.reviewed.contains(checklist.id))
            check("Owner correction preserves task text, deadline and privacy", ownerModel.rawText(checklist) == checklist.text && ownerModel.due(checklist) == checklist.due && !ownerModel.isPrivate(checklist))
            check("Task-local correction leaves Tom and his other tasks intact", ownerModel.speakerName("S3") == "Tom Alvarez" && otherTomOwners.allSatisfy { id, owner in ownerModel.allNotes.first(where: { $0.id == id }).map { ownerModel.ownerID($0) == owner } == true } && ownerModel.segments.first(where: { $0.id == "seg_106" })?.speaker == "S3")
            check("Team update uses corrected owner and stale drafts are cleared", ownerModel.shareText([checklist.id]).contains("Arjun Mehta:") && ownerModel.state.drafts.isEmpty)
            let ownerData = try JSONEncoder().encode(ownerModel.state)
            check("Owner confirmation survives saved-state round-trip", (try JSONDecoder().decode(ReviewState.self, from: ownerData)).checkedOwners?[checklist.id] == arjun.id)
            var oldOwnerState = try JSONSerialization.jsonObject(with: ownerData) as! [String: Any]
            oldOwnerState.removeValue(forKey: "checkedOwners")
            check("Older reviews load without owner-confirmation state", (try JSONDecoder().decode(ReviewState.self, from: JSONSerialization.data(withJSONObject: oldOwnerState))).checkedOwners == nil)
            check("Confirmed owner retains its review context", ownerModel.ownerReviewContext(for: checklist) != nil)
            ownerModel.confirmOwner(noteID: checklist.id, personID: tom.id, recordingKey: original.key, expectedRevision: ownerModel.revision)
            check("A reviewed owner can be changed back", ownerModel.ownerID(checklist) == tom.id && ownerModel.state.checkedOwners?[checklist.id] == tom.id)
            ownerModel.exclude(checklist); ownerModel.restore(checklist)
            check("Restoring an excluded task requires checking its owner again", ownerModel.state.checkedOwners?[checklist.id] == nil && !ownerModel.state.reviewed.contains(checklist.id) && ownerModel.flags(checklist).contains { $0.id.hasSuffix(":owner") })
            ownerModel.resetReview()
            check("Keeping the original owner is an explicit supported choice", ownerModel.confirmOwner(noteID: checklist.id, personID: tom.id, recordingKey: original.key, expectedRevision: ownerModel.revision) && ownerModel.ownerID(checklist) == tom.id && ownerModel.flags(checklist).isEmpty)
            ownerModel.resetReview()
            check("Leaving a task unassigned is an explicit supported choice", ownerModel.confirmOwner(noteID: checklist.id, personID: "unassigned", recordingKey: original.key, expectedRevision: ownerModel.revision) && ownerModel.ownerID(checklist) == "unassigned")
            ownerModel.resetReview(); ownerModel.revealAll = false; ownerModel.elapsed = 30
            check("Incomplete recording cannot confirm an owner", !ownerModel.confirmOwner(noteID: checklist.id, personID: arjun.id, recordingKey: original.key, expectedRevision: ownerModel.revision) && ownerModel.state.edits.isEmpty)
            var uncertainOwner = original
            uncertainOwner.key = "owner-plus-wording"
            let checklistIndex = uncertainOwner.notes.actionItems.firstIndex { $0.id == checklist.id }!
            uncertainOwner.notes.actionItems[checklistIndex].confidence = 0.4
            try ownerModel.apply(uncertainOwner, ready: true)
            let uncertainTask = uncertainOwner.notes.actionItems[checklistIndex]
            ownerModel.confirmOwner(noteID: uncertainTask.id, personID: arjun.id, recordingKey: uncertainOwner.key, expectedRevision: ownerModel.revision)
            check("Owner-only confirmation leaves wording review unresolved", ownerModel.flags(uncertainTask).contains { $0.id.hasSuffix(":confidence") } && !ownerModel.flags(uncertainTask).contains { $0.id.hasSuffix(":owner") } && !ownerModel.state.reviewed.contains(uncertainTask.id) && ownerModel.shareText([uncertainTask.id]).isEmpty)
            uncertainOwner.key = "private-owner-task"
            uncertainOwner.notes.actionItems[checklistIndex].sensitivity = "private"
            try ownerModel.apply(uncertainOwner, ready: true)
            let privateTask = uncertainOwner.notes.actionItems[checklistIndex]
            ownerModel.confirmOwner(noteID: privateTask.id, personID: arjun.id, recordingKey: uncertainOwner.key, expectedRevision: ownerModel.revision)
            check("Owner confirmation preserves privacy and cannot share the task", ownerModel.isPrivate(privateTask) && ownerModel.shareText([privateTask.id]).isEmpty)
            var renamedOwner = original
            renamedOwner.key = "different-owner-recording"
            renamedOwner.transcript.segments = renamedOwner.transcript.segments.map { segment in
                var value = segment; value.id = "new-" + value.id
                value.text = value.text.replacingOccurrences(of: "Arjun", with: "Nora")
                return value
            }
            renamedOwner.notes.actionItems = [checklist]
            renamedOwner.notes.actionItems[0].id = "different-task"
            renamedOwner.notes.actionItems[0].sources = checklist.sources.map { source in var value = source; value.segmentId = "new-" + source.segmentId; return value }
            renamedOwner.notes.summary = []; renamedOwner.notes.decisions = []
            renamedOwner.calendar?.event.attendees.removeAll { $0.id == arjun.id }
            renamedOwner.calendar?.event.attendees.append(Person(name: "Nora Lee", email: "nora@example.test", title: nil, response: nil))
            try ownerModel.apply(renamedOwner, ready: true)
            check("Owner suggestions work with other people and source IDs", ownerModel.ownerReviewContext(for: renamedOwner.notes.actionItems[0])?.suggestedPerson?.name == "Nora Lee")
        } catch { results.append(["check": "Unexpected error: \(error)", "passed": false]) }
        let destination = URL.documentsDirectory.appending(path: "prototype-checks.json")
        if let data = try? JSONSerialization.data(withJSONObject: results, options: [.prettyPrinted, .sortedKeys]) { try? data.write(to: destination) }
    }
}
#endif
