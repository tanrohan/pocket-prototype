// The people carousel and the reply drawer that opens from it.
import SwiftUI

// MARK: - Selection

struct PeopleSpotlightState {
    var focusedID: String?
    var isExpanded = false

    func focused(in people: [Person]) -> Person? { people.first { $0.id == focusedID } }
    mutating func reconcile(_ people: [Person]) {
        guard focused(in: people) == nil else { return }
        focusedID = people.first(where: { $0.response == "declined" })?.id ?? people.first?.id
        isExpanded = false
    }
    mutating func open(_ person: Person, among people: [Person]) {
        guard people.contains(where: { $0.id == person.id }) else { return }
        focusedID = person.id; isExpanded = true
    }
    mutating func move(_ offset: Int, among people: [Person]) {
        guard let index = people.firstIndex(where: { $0.id == focusedID }), people.indices.contains(index + offset) else { return }
        focusedID = people[index + offset].id
    }
}

// MARK: - Carousel

/// Keep the original avatar anchored while its reply content unfolds below.
/// Motion inspired by the supplied TelegramHeader sample (Balaji Venkatesh, 2026).
struct PeopleSpotlight: View {
    @Environment(MeetingStore.self) private var store
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    @Binding var selection: PeopleSpotlightState
    let people: [Person]
    let pageScroll: SpotlightPageScroll
    @State private var expansion: CGFloat = 0
    @State private var contentHeight: CGFloat = 0
    @State private var crossedThreshold = false
    @State private var isPulling = false
    @ScaledMetric(relativeTo: .body) private var diameter: CGFloat = 68
    @ScaledMetric(relativeTo: .caption) private var itemWidth: CGFloat = 100
    @ScaledMetric(relativeTo: .caption) private var railHeight: CGFloat = 128
    @ScaledMetric(relativeTo: .body) private var headerHeight: CGFloat = 172
    private var motion: Animation? { reduceMotion ? nil : .spring(response: 0.42, dampingFraction: 0.82) }
    private var person: Person? { selection.focused(in: people) }
    private var progress: CGFloat { min(max(expansion, 0), 1) }
    private var focusedBinding: Binding<String?> {
        Binding(get: { selection.focusedID }, set: { value in
            guard !selection.isExpanded && !isPulling else { return }
            if let value, people.contains(where: { $0.id == value }) { selection.focusedID = value }
        })
    }

    var body: some View {
        VStack(spacing: 10) {
            HStack {
                Text("People").font(.headline).foregroundStyle(ink).accessibilityAddTraits(.isHeader)
                Spacer()
            }
            if let person {
                VStack(spacing: 0) {
                    GeometryReader { geometry in
                        ZStack(alignment: .top) {
                            carousel(width: geometry.size.width)
                            headerDetails(person)
                                .allowsHitTesting(false)
                                .accessibilityHidden(!selection.isExpanded)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                        .contentShape(Rectangle())
                        .gesture(SpotlightPullGesture(pageScroll: pageScroll, enabled: selection.isExpanded, opening: false, changed: updatePull, ended: finishPull))
                    }.frame(height: railHeight + (headerHeight - railHeight) * progress)

                    PersonReplyContent(person: person)
                        .id(person.id)
                        .padding(.top, 12)
                        .padding(.bottom, 8)
                        .fixedSize(horizontal: false, vertical: true)
                        .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { contentHeight = $0 }
                        .opacity(max(0, (progress - 0.25) / 0.75))
                        .frame(height: contentHeight * progress, alignment: .top)
                        .clipShape(SpotlightContentReveal())
                        .allowsHitTesting(selection.isExpanded)
                        .accessibilityHidden(!selection.isExpanded)
                }
                .backgroundPreferenceValue(SpotlightPortraitAnchor.self) { anchor in
                    GeometryReader { geometry in
                        if let anchor, progress > 0, !reduceTransparency, contrast != .increased {
                            PersonSpotlightWash(color: person.tint, origin: geometry[anchor])
                                .opacity(progress)
                        }
                    }.allowsHitTesting(false).accessibilityHidden(true)
                }
            } else {
                Label("People will appear with your recording", systemImage: "person.2")
                    .font(.subheadline).foregroundStyle(.secondary).padding(20).frame(maxWidth: .infinity)
            }
        }
        .onChange(of: selection.focusedID) { old, new in
            if old != nil, new != nil, old != new { store.haptic() }
        }
        .onChange(of: selection.isExpanded) { _, expanded in
            withAnimation(motion) { expansion = expanded ? 1 : 0 }
        }
        .onAppear { expansion = selection.isExpanded ? 1 : 0 }
    }

    private func carousel(width: CGFloat) -> some View {
        let softenEdges = !reduceTransparency && contrast != .increased
        let clearRadius = itemWidth * 0.55
        return ScrollViewReader { rail in
            ScrollView(.horizontal) {
                LazyHStack(alignment: .top, spacing: 4) {
                    ForEach(people) { contact in
                        avatarItem(contact, choose: { choose(contact, rail: rail) })
                            .frame(width: itemWidth)
                            .opacity(contact.id == selection.focusedID ? 1 : 1 - progress)
                            .allowsHitTesting(!selection.isExpanded || contact.id == selection.focusedID)
                            .accessibilityHidden(selection.isExpanded && contact.id != selection.focusedID)
                            .visualEffect { content, geometry in
                                let distance = abs(geometry.frame(in: .named("peopleSpotlightCarousel")).midX - width / 2)
                                let amount = min(max((distance - clearRadius) / max(1, width / 2 - clearRadius), 0), 1)
                                return content
                                    .blur(radius: softenEdges ? amount * 4 : 0)
                                    .opacity(softenEdges ? 1 - amount * 0.3 : 1)
                            }
                            .id(contact.id)
                    }
                }.scrollTargetLayout()
            }
            .contentMargins(.horizontal, max(0, (width - itemWidth) / 2), for: .scrollContent)
            .scrollIndicators(.hidden)
            .scrollDisabled(selection.isExpanded)
            .spotlightAlignment()
            .scrollPosition(id: focusedBinding, anchor: .center)
            .scrollClipDisabled()
            .coordinateSpace(name: "peopleSpotlightCarousel")
            .onChange(of: selection.isExpanded) { _, expanded in
                if expanded { center(selection.focusedID, using: rail) }
            }
            .task {
                await Task.yield()
                center(selection.focusedID, using: rail)
            }
        }.frame(height: railHeight)
    }

    private func avatarItem(_ contact: Person, choose: @escaping () -> Void) -> some View {
        let centered = selection.focusedID == contact.id
        return Button(action: choose) {
        VStack(spacing: 8) {
            Text(contact.initials)
                .font(.system(size: diameter * 0.32, weight: .medium, design: .rounded))
                .foregroundStyle(.white)
                .frame(width: diameter, height: diameter)
                .background {
                    Circle().fill(contact.tint.gradient)
                }
                .anchorPreference(key: SpotlightPortraitAnchor.self, value: .bounds) { anchor in
                    centered ? anchor : nil
                }
                .scaleEffect(centered ? 1 : 0.82)
            if centered {
                namePill(contact).frame(height: 44)
            } else {
                Text(contact.first).font(.caption).foregroundStyle(.secondary)
                    .lineLimit(1).frame(height: 44)
            }
        }.frame(maxWidth: .infinity).padding(.top, 8).contentShape(Rectangle())
        }.buttonStyle(.plain)
            .accessibilityElement(children: .ignore)
            .accessibilityAddTraits(.isButton)
            .accessibilityLabel(contact.name)
            .accessibilityValue(centered ? (selection.isExpanded ? "Reply topics open" : "In the spotlight") : "")
            .accessibilityHint(centered ? (selection.isExpanded ? "Pull up or tap to close reply topics." : "Pull down or tap to unfold reply topics.") : "Tap to bring into the spotlight.")
            .accessibilityAddTraits(centered ? .isSelected : [])
            .gesture(SpotlightPullGesture(pageScroll: pageScroll, enabled: centered && !selection.isExpanded, opening: true, changed: updatePull, ended: finishPull))
    }

    @ViewBuilder private func namePill(_ contact: Person) -> some View {
        let label = HStack(spacing: 5) {
            Text(contact.first).font(.caption.weight(.semibold)).lineLimit(1)
            Image(systemName: "chevron.compact.right")
                .font(.system(.caption2, design: .rounded, weight: .heavy))
                .foregroundStyle(.tertiary)
                .rotationEffect(.degrees(90 * progress))
                .offset(y: 1)
                .accessibilityHidden(true)
        }.foregroundStyle(ink).padding(.horizontal, 12).padding(.vertical, 10)
        if #available(iOS 26.0, *), !reduceTransparency, contrast != .increased {
            label.glassEffect(.regular.interactive(), in: .capsule)
        } else {
            label.background(.white, in: Capsule())
                .overlay { Capsule().strokeBorder(ink.opacity(0.12), lineWidth: 0.5) }
        }
    }

    // The avatar and first name remain in the carousel at their original size
    // and position throughout the gesture. Only supporting details are revealed.
    private func headerDetails(_ person: Person) -> some View {
        VStack(spacing: 0) {
            Color.clear.frame(height: railHeight + 12)
            Text((person.title ?? "Participant") + (person.response == "declined" ? " · Didn’t attend" : ""))
                .font(.caption).foregroundStyle(ink.opacity(0.65))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)
                .opacity(max(0, (progress - 0.4) / 0.6))
        }
        .frame(maxWidth: .infinity)
    }

    private func center(_ id: String?, using rail: ScrollViewProxy) {
        guard let id else { return }
        var transaction = Transaction(); transaction.disablesAnimations = true
        withTransaction(transaction) { rail.scrollTo(id, anchor: .center) }
    }
    private func choose(_ contact: Person, rail: ScrollViewProxy) {
        if selection.focusedID == contact.id {
            center(contact.id, using: rail)
            store.haptic(); settle(open: !selection.isExpanded)
        } else {
            withAnimation(motion) {
                selection.focusedID = contact.id
                rail.scrollTo(contact.id, anchor: .center)
            }
        }
    }
    private func updatePull(_ distance: CGFloat) {
        isPulling = true
        let value = (selection.isExpanded ? CGFloat(1) : 0) + distance / 160
        // Finger tracking is deliberately unanimated; only release uses a spring.
        var transaction = Transaction(); transaction.disablesAnimations = true
        withTransaction(transaction) { expansion = min(max(value, 0), 1) }
        let crossed = selection.isExpanded ? expansion < 0.65 : expansion > 0.35
        if crossed && !crossedThreshold { store.haptic() }
        crossedThreshold = crossed
    }
    private func finishPull(_ distance: CGFloat) {
        let open = selection.isExpanded ? distance > -56 : distance > 56
        settle(open: open)
    }
    private func settle(open: Bool) {
        store.stop()
        crossedThreshold = false
        isPulling = false
        selection.isExpanded = open
        withAnimation(motion) { expansion = open ? 1 : 0 }
    }
}

// MARK: - Drawer wash

/// A single feathered wash fans out from the portrait, with no enclosing panel.
/// It reaches transparency before the final card, so there is no visible bottom edge.
private struct PersonSpotlightWash: View {
    let color: Color
    let origin: CGRect

    var body: some View {
        Canvas { context, size in
            let top = origin.midY
            let height = max(1, size.height - top - 40)
            let bottom = top + height
            let halfWidth = max(origin.width / 2, size.width / 2 - 20)
            var beam = Path()
            beam.move(to: CGPoint(x: origin.midX - origin.width * 0.3, y: top))
            beam.addLine(to: CGPoint(x: size.width / 2 - halfWidth, y: bottom))
            beam.addLine(to: CGPoint(x: size.width / 2 + halfWidth, y: bottom))
            beam.addLine(to: CGPoint(x: origin.midX + origin.width * 0.3, y: top))
            beam.closeSubpath()
            context.addFilter(.blur(radius: 18))
            context.fill(beam, with: .linearGradient(
                Gradient(stops: [
                    .init(color: color.opacity(0.26), location: 0),
                    .init(color: color.opacity(0.16), location: 0.15),
                    .init(color: color.opacity(0.08), location: 0.4),
                    .init(color: color.opacity(0.025), location: 0.68),
                    .init(color: .clear, location: 0.9),
                    .init(color: .clear, location: 1)
                ]),
                startPoint: CGPoint(x: origin.midX, y: top),
                endPoint: CGPoint(x: size.width / 2, y: bottom)
            ))
        }
    }
}

/// Reveal vertically without cropping the glass rims and shadows at either side.
private struct SpotlightContentReveal: Shape {
    func path(in rect: CGRect) -> Path {
        Path(CGRect(x: rect.minX - 32, y: rect.minY, width: rect.width + 64, height: rect.height))
    }
}

private extension View {
    @ViewBuilder
    func spotlightAlignment() -> some View {
        if #available(iOS 26.0, *) {
            scrollTargetBehavior(.viewAligned(limitBehavior: .alwaysByOne, anchor: .center))
        } else {
            scrollTargetBehavior(.viewAligned(limitBehavior: .alwaysByOne))
        }
    }
}

private struct SpotlightPortraitAnchor: PreferenceKey {
    static var defaultValue: Anchor<CGRect>? { nil }
    static func reduce(value: inout Anchor<CGRect>?, nextValue: () -> Anchor<CGRect>?) {
        if let next = nextValue() { value = next }
    }
}

// MARK: - Pull gesture

/// Fail horizontal pans immediately so the native carousel keeps its scrolling physics.
private struct SpotlightPullGesture: UIGestureRecognizerRepresentable {
    let pageScroll: SpotlightPageScroll
    let enabled: Bool
    let opening: Bool
    let changed: (CGFloat) -> Void
    let ended: (CGFloat) -> Void

    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> SpotlightPanRecognizer {
        let pan = SpotlightPanRecognizer()
        pan.pageScroll = pageScroll
        context.coordinator.opening = opening
        pan.delegate = context.coordinator
        pan.maximumNumberOfTouches = 1
        pan.isEnabled = enabled
        return pan
    }
    func updateUIGestureRecognizer(_ recognizer: SpotlightPanRecognizer, context: Context) {
        recognizer.isEnabled = enabled
        context.coordinator.opening = opening
    }
    func handleUIGestureRecognizerAction(_ recognizer: SpotlightPanRecognizer, context: Context) {
        let distance = recognizer.pullDistance
        switch recognizer.state {
        case .began: recognizer.holdPage(); changed(distance)
        case .changed: changed(distance)
        case .ended: ended(distance); recognizer.releasePage()
        case .cancelled, .failed: ended(0); recognizer.releasePage()
        default: break
        }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var opening = true
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? SpotlightPanRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            let verticalPull = (opening ? velocity.y > 0 : velocity.y < 0) && abs(velocity.y) > abs(velocity.x) * 1.35
            return verticalPull
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool { true }
    }
}

private final class SpotlightPanRecognizer: UIPanGestureRecognizer {
    var pageScroll: SpotlightPageScroll?
    private var origin: CGPoint = .zero
    private var pages: [(view: UIScrollView, offset: CGPoint, enabled: Bool)] = []
    private var holdingPage = false
    private(set) var pullDistance: CGFloat = 0
    // Stop the containing scroll views synchronously, before they can add momentum
    // to the card's vertical drag. Restore their offsets and pan state on release.
    func holdPage() {
        guard !holdingPage else { return }
        holdingPage = true
        for page in pages {
            page.view.panGestureRecognizer.isEnabled = false
            page.view.setContentOffset(page.offset, animated: false)
        }
    }
    func releasePage() {
        guard holdingPage else { return }
        holdingPage = false
        for page in pages {
            page.view.setContentOffset(page.offset, animated: false)
            page.view.panGestureRecognizer.isEnabled = page.enabled
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        origin = touches.first?.location(in: view?.window) ?? .zero
        pages = []
        if let scroll = pageScroll?.view {
            pages.append((scroll, scroll.contentOffset, scroll.panGestureRecognizer.isEnabled))
        }
        // Leave the horizontal carousel's recognizer enabled: disabling it
        // cancels the avatar's own drag before it can finish.
        pullDistance = 0
        super.touchesBegan(touches, with: event)
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        if let touch = touches.first { pullDistance = touch.location(in: view?.window).y - origin.y }
        super.touchesMoved(touches, with: event)
    }
    override func reset() {
        releasePage()
        super.reset()
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        if let touch = touches.first { pullDistance = touch.location(in: view?.window).y - origin.y }
        super.touchesEnded(touches, with: event)
    }
}

/// Resolve the real page scroll view explicitly. SwiftUI may host a gesture above
/// its ScrollView, so walking only the recognizer's superviews can miss the page.
@MainActor final class SpotlightPageScroll {
    weak var view: UIScrollView?
}

// MARK: - Page scroll

struct SpotlightPageScrollReader: UIViewRepresentable {
    let pageScroll: SpotlightPageScroll
    func makeUIView(context: Context) -> Probe { Probe(pageScroll: pageScroll) }
    func updateUIView(_ uiView: Probe, context: Context) { uiView.resolve() }
    final class Probe: UIView {
        let pageScroll: SpotlightPageScroll
        init(pageScroll: SpotlightPageScroll) {
            self.pageScroll = pageScroll
            super.init(frame: .zero)
            isUserInteractionEnabled = false
            isAccessibilityElement = false
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
        override func didMoveToWindow() { super.didMoveToWindow(); resolve() }
        override func layoutSubviews() { super.layoutSubviews(); resolve() }
        func resolve() {
            var ancestor = superview
            while let current = ancestor {
                if let scroll = current as? UIScrollView { pageScroll.view = scroll; return }
                ancestor = current.superview
            }
        }
    }
}
