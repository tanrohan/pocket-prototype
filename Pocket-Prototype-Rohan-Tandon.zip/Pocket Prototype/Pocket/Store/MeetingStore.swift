import SwiftUI
import AVFoundation

// Recording timeline, review state, and what is allowed to leave the device.
@Observable @MainActor final class MeetingStore {
    var package: MeetingPackage?
    var state = ReviewState()
    var elapsed = 0.0
    var running = true
    var revealAll = false
    var loadError: String?
    var importError: String?
    var toast: String?
    var audioError: String?
    var playingID: String?
    var library: [LibraryItem] = []
    var revision = 0
    private var flagCache: [String: [ReviewFlag]] = [:]
    @ObservationIgnored var priorityCacheKey: String?
    @ObservationIgnored var priorityCache: PriorityDateAnswer?
    private var player: AVAudioPlayer?
    private var stopTask: Task<Void, Never>?
    private var persistence = true
    private var recordingsRoot = URL.documentsDirectory.appending(path: "Recordings", directoryHint: .isDirectory)

    // MARK: Arrival

    var notes: NotesFile? { package?.notes }
    var segments: [Segment] { package?.transcript.segments ?? [] }
    var events: [StreamEvent] { package?.stream?.events ?? [] }
    var allNotes: [Note] { notes?.all ?? [] }
    var duration: Double { events.last?.t ?? 0 }
    var complete: Bool { revealAll || elapsed >= duration }
    var hasTimeline: Bool { package?.stream != nil && !events.isEmpty }
    var transcriptReady: Bool { revealAll || !hasTimeline || Set(availableSegments.map(\.id)).count == segments.count }
    var title: String {
        if hasTimeline && !revealAll && !events.contains(where: { $0.type == "notes.title" && $0.t <= elapsed }) {
            return package?.calendar?.event.title ?? "Your recording"
        }
        let title = notes?.title.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return title.isEmpty ? "Untitled recording" : title
    }
    var recordingDate: Date? {
        let value = package?.transcript.recording?.startedAt ?? package?.calendar?.event.start
        return value.flatMap { ISO8601DateFormatter().date(from: $0) }
    }
    var recordingDuration: Double { package?.duration ?? 0 }
    var stage: String {
        guard !complete else { return "Ready for your review" }
        let major = events.last { $0.t <= elapsed && ["recording.stopped", "transfer.started", "upload.started", "transcription.started", "transcription.completed", "notes.started", "notes.completed"].contains($0.type) }?.type
        switch major {
        case "transfer.started", "recording.stopped": return "Saving your recording"
        case "upload.started": return "Preparing your recording"
        case "transcription.started": return "Listening back"
        default: return "Putting your notes together"
        }
    }
    var availableSegments: [Segment] {
        if revealAll || !hasTimeline { return segments }
        let ids = Set(events.filter { $0.t <= elapsed }.flatMap { $0.segmentIds ?? [] })
        return segments.filter { ids.contains($0.id) }
    }
    func available(_ id: String) -> Bool {
        revealAll || !hasTimeline || events.contains { $0.id == id && $0.type == "notes.item.completed" && $0.t <= elapsed }
    }
    var partialNote: String? {
        guard !revealAll, hasTimeline else { return nil }
        let arrived = events.filter { $0.t <= elapsed }
        guard let active = arrived.last(where: { $0.type == "notes.item.started" && !available($0.id ?? "") }), let id = active.id else { return nil }
        let text = arrived.filter { $0.type == "notes.item.delta" && $0.id == id }.compactMap(\.text).joined()
        return text.isEmpty ? nil : text
    }
    var visibleNotes: [Note] { allNotes.filter { available($0.id) && !state.excluded.contains($0.id) } }
    var actions: [Note] { (notes?.actionItems ?? []).filter { available($0.id) && !state.excluded.contains($0.id) } }
    // Anchor the overview to file order, never to changing review flags or arrival counts.
    // The same completed note remains visible as later notes and corrections arrive.
    var overviewNote: Note? {
        let ordered = (notes?.summary ?? []) + (notes?.decisions ?? []) + (notes?.actionItems ?? [])
        guard let first = ordered.first(where: { !state.excluded.contains($0.id) }), available(first.id) else { return nil }
        return first
    }
    var reviewNotes: [Note] { visibleNotes.filter { !state.reviewed.contains($0.id) && !flags($0).isEmpty } }
    var shareableNotes: [Note] { visibleNotes.filter { state.reviewed.contains($0.id) && !isPrivate($0) } }
    var unresolvedSpeakers: [Speaker] { (notes?.speakers ?? []).filter { state.speakerNames[$0.speaker] == nil && ($0.attendeeEmail == nil || ($0.confidence ?? 1) < 0.8) } }
    var speakersAvailable: Bool { revealAll || !hasTimeline || events.contains { $0.type == "speakers.suggested" && $0.t <= elapsed } || (complete && !events.contains { $0.type == "speakers.suggested" }) }
    var people: [Person] {
        var result = package?.calendar?.event.attendees ?? []
        guard speakersAvailable else { return result }
        for speaker in notes?.speakers ?? [] {
            let id = state.speakerPeople[speaker.speaker] ?? speaker.attendeeEmail ?? "speaker:\(speaker.speaker)"
            if !result.contains(where: { $0.id == id }) { result.append(Person(name: speakerName(speaker.speaker), email: id, title: "Recorded speaker", response: nil)) }
        }
        for note in visibleNotes where note.owner != nil {
            let id = ownerID(note)
            if !result.contains(where: { $0.id == id }) && id != "unassigned" { result.append(Person(name: owner(note), email: id, title: "Named in the notes", response: nil)) }
        }
        return result
    }
    var organizerID: String? { package?.calendar?.event.organizer?.email }
    var otherPeople: [Person] { people.filter { $0.id != organizerID } }
    init(loadDefault: Bool = true, persist: Bool = true, libraryRoot: URL? = nil) {
        persistence = persist
        if let libraryRoot { recordingsRoot = libraryRoot }
        guard loadDefault else { return }
        do {
            if let saved = UserDefaults.standard.string(forKey: "pocket.activeFolder"), saved.hasPrefix(URL.documentsDirectory.appending(path: "Recordings").path), FileManager.default.fileExists(atPath: saved) {
                try apply(MeetingPackage.load(folder: URL(fileURLWithPath: saved)), ready: true)
            } else { try loadBundled(sample: UserDefaults.standard.bool(forKey: "pocket.activeSample")) }
            refreshLibrary()
            if ProcessInfo.processInfo.arguments.contains("-demo-ready") { skip() }
            #if DEBUG
            if ProcessInfo.processInfo.arguments.contains("-self-test") { runChecks() }
            let args = ProcessInfo.processInfo.arguments
            // Reproducible visual previews without replacing the person's saved review.
            if args.contains("-preview-fresh") { persistence = false; state = ReviewState(); revision += 1 }
            if let index = args.firstIndex(of: "-preview-time"), args.indices.contains(index + 1), let time = Double(args[index + 1]) {
                elapsed = max(0, min(time, duration)); revealAll = false; running = false
            }
            #endif
        } catch { loadError = error.localizedDescription; running = false }
    }

    // MARK: Library

    func loadBundled(sample: Bool = false, ready: Bool? = nil) throws {
        guard let folder = Bundle.main.resourceURL else { throw PackageError(message: "The bundled recording couldn’t be found.") }
        try apply(MeetingPackage.load(folder: folder, prefix: sample ? "sample_" : ""), ready: ready ?? sample)
        if persistence {
            UserDefaults.standard.removeObject(forKey: "pocket.activeFolder")
            UserDefaults.standard.set(sample, forKey: "pocket.activeSample")
        }
    }
    func apply(_ value: MeetingPackage, ready: Bool = false) throws {
        stop(); package = value; loadError = nil; importError = nil; audioError = nil
        state = ReviewState()
        if persistence, let data = UserDefaults.standard.data(forKey: "pocket.review.\(value.key)"), let saved = try? JSONDecoder().decode(ReviewState.self, from: data) { state = saved }
        flagCache = Dictionary(uniqueKeysWithValues: value.notes.all.map { ($0.id, makeFlags($0, package: value)) })
        elapsed = ready ? duration : 0; revealAll = ready || !hasTimeline; running = !ready && hasTimeline; revision += 1
    }
    func importFolder(_ source: URL) {
        let granted = source.startAccessingSecurityScopedResource()
        defer { if granted { source.stopAccessingSecurityScopedResource() } }
        do {
            let candidate = try MeetingPackage.load(folder: source)
            let root = recordingsRoot
            try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
            let dest = root.appending(path: candidate.key, directoryHint: .isDirectory)
            if !FileManager.default.fileExists(atPath: dest.path) {
                let staging = root.appending(path: ".import-\(UUID().uuidString)", directoryHint: .isDirectory)
                try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
                defer { try? FileManager.default.removeItem(at: staging) }
                for name in ["transcript.json", "notes.json", "calendar.json", "stream.json"] {
                    let file = source.appendingPathComponent(name)
                    if FileManager.default.fileExists(atPath: file.path) { try FileManager.default.copyItem(at: file, to: staging.appendingPathComponent(name)) }
                }
                if let audio = candidate.audioURL {
                    let size = try audio.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                    guard size <= 500_000_000 else { throw PackageError(message: "The recording exceeds the 500 MB import limit.") }
                    try FileManager.default.copyItem(at: audio, to: staging.appendingPathComponent(audio.lastPathComponent))
                }
                _ = try MeetingPackage.load(folder: staging)
                try FileManager.default.moveItem(at: staging, to: dest)
            }
            let imported = try MeetingPackage.load(folder: dest)
            try apply(imported, ready: true); if persistence { UserDefaults.standard.set(dest.path, forKey: "pocket.activeFolder") }; refreshLibrary(); announce("Recording imported")
        } catch { importError = error.localizedDescription }
    }
    func refreshLibrary() {
        let root = recordingsRoot
        library = ((try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)) ?? []).compactMap { folder in
            guard let data = try? Data(contentsOf: folder.appendingPathComponent("notes.json")), let notes = try? JSONDecoder().decode(NotesFile.self, from: data) else { return nil }
            return LibraryItem(id: folder.lastPathComponent, title: notes.title, folder: folder)
        }.sorted { $0.title < $1.title }
    }
    func open(_ item: LibraryItem) {
        do { try apply(MeetingPackage.load(folder: item.folder), ready: true); UserDefaults.standard.set(item.folder.path, forKey: "pocket.activeFolder") }
        catch { importError = error.localizedDescription }
    }
    func tick() {
        if running && !complete { elapsed = min(duration, elapsed + 0.1) }
    }
    func skip() {
        elapsed = duration
        revealAll = true
        running = false
    }
    func restart() {
        stop(); elapsed = 0; revealAll = !hasTimeline; running = hasTimeline
        // One fresh-start control for the prototype: rewind arrival and all review work.
        // Imported source files are untouched.
        state = ReviewState()
        audioError = nil; toast = nil
        revision += 1; save()
    }
    func save() {
        guard persistence, let key = package?.key else { return }
        do { UserDefaults.standard.set(try JSONEncoder().encode(state), forKey: "pocket.review.\(key)") }
        catch { announce("Your changes couldn’t be saved.") }
    }
    func changed() {
        state.checkedPriorityID = nil
        state.checkedPrioritySourceID = nil
        state.drafts = [:]
        revision += 1
        save()
    }
    func resetReview() {
        state = ReviewState()
        save()
        revision += 1
    }

    // MARK: Note text

    func rawText(_ note: Note) -> String { state.edits[note.id]?.text ?? note.text }
    func text(_ note: Note) -> String {
        var text = rawText(note)
        for speaker in notes?.speakers ?? [] {
            if let name = state.speakerNames[speaker.speaker], name != speaker.suggestedName {
                let pattern = "(?<![\\p{L}\\p{N}])" + NSRegularExpression.escapedPattern(for: speaker.suggestedName) + "(?![\\p{L}\\p{N}])"
                if let regex = try? NSRegularExpression(pattern: pattern) { text = regex.stringByReplacingMatches(in: text, range: NSRange(text.startIndex..., in: text), withTemplate: NSRegularExpression.escapedTemplate(for: name)) }
            }
        }
        return text
    }
    func speakerName(_ id: String) -> String { state.speakerNames[id] ?? notes?.speakers?.first { $0.speaker == id }?.suggestedName ?? id }
    func ownerID(_ note: Note) -> String {
        if let owner = state.edits[note.id]?.owner { return owner }
        if let speakerID = note.owner?.speaker {
            let speaker = notes?.speakers?.first { $0.speaker == speakerID }
            return state.speakerPeople[speakerID] ?? speaker?.attendeeEmail ?? "speaker:\(speakerID)"
        }
        if let name = note.owner?.name { return package?.calendar?.event.attendees.first { $0.name == name }?.email ?? "name:\(name)" }
        return "unassigned"
    }
    func owner(_ note: Note) -> String {
        let id = ownerID(note)
        if id == "unassigned" { return "Unassigned" }
        if let person = package?.calendar?.event.attendees.first(where: { $0.id == id }) { return person.name }
        if id.hasPrefix("speaker:") { return speakerName(String(id.dropFirst(8))) }
        if id.hasPrefix("name:") { return String(id.dropFirst(5)) }
        return note.owner?.name ?? id
    }
    func due(_ note: Note) -> String { state.edits[note.id]?.due ?? note.due ?? "" }
    func actions(for person: Person) -> [Note] { actions.filter { ownerID($0) == person.id } }
    func isPrivate(_ note: Note) -> Bool {
        if let edit = state.edits[note.id] { return edit.privateItem }
        if let sensitivity = note.sensitivity, sensitivity != "none" { return true }
        return containsPrivateLanguage(([note.text] + note.sources.map(\.quote)).joined(separator: " "))
    }
    func containsPrivateLanguage(_ text: String) -> Bool {
        let value = text.lowercased()
        return ["between us", "keep this private", "keep that private", "medical procedure", "confidential", "off the record", "don't share", "do not share", "personal matter"].contains { value.contains($0) }
    }
    func detectedFlags(_ note: Note) -> [ReviewFlag] {
        let arrived = Set(availableSegments.map(\.id))
        return (flagCache[note.id] ?? []).filter { $0.segmentIDs.allSatisfy { arrived.contains($0) } }
    }
    func flags(_ note: Note) -> [ReviewFlag] {
        detectedFlags(note).filter { flag in
            !(flag.id.hasSuffix(":owner") && state.checkedOwners?[note.id] == ownerID(note))
        }
    }

    // MARK: Review

    func review(_ note: Note, text: String, owner: String?, due: String, privateItem: Bool) {
        state.checkedOwners?[note.id] = nil
        state.edits[note.id] = NoteEdit(text: text, owner: owner, due: due, privateItem: privateItem)
        state.reviewed.insert(note.id)
        state.excluded.remove(note.id)
        changed()
        haptic()
    }
    func exclude(_ note: Note) {
        state.checkedOwners?[note.id] = nil
        state.excluded.insert(note.id)
        state.reviewed.remove(note.id)
        changed()
    }
    func restore(_ note: Note) {
        state.checkedOwners?[note.id] = nil
        state.excluded.remove(note.id)
        state.reviewed.remove(note.id)
        changed()
    }
    func setSpeaker(_ id: String, name: String, personID: String?) {
        state.speakerNames[id] = name.trimmingCharacters(in: .whitespacesAndNewlines)
        state.speakerPeople[id] = personID ?? "speaker:\(id)"
        for note in allNotes where note.owner?.speaker == id { state.reviewed.remove(note.id); state.checkedOwners?[note.id] = nil }
        changed(); announce("Speaker updated throughout this recording")
    }
    func replaceAcrossNotes(old: String, new: String) -> Int {
        guard !old.isEmpty, old != new else { return 0 }
        var count = 0
        for note in allNotes where rawText(note).contains(old) {
            state.checkedOwners?[note.id] = nil
            state.edits[note.id] = NoteEdit(text: rawText(note).replacingOccurrences(of: old, with: new), owner: state.edits[note.id]?.owner, due: due(note), privateItem: isPrivate(note))
            state.reviewed.remove(note.id); count += 1
        }
        if count > 0 { changed() }; return count
    }

    // MARK: Playback and sharing

    func clip(_ ids: [String]) -> [Segment] {
        availableSegments.filter { ids.contains($0.id) }.sorted { $0.start < $1.start }
    }
    func play(_ segment: Segment) {
        if playingID == segment.id { stop(); return }; stop(); audioError = nil
        guard let url = package?.audioURL else { audioError = "This recording has no audio file. You can read the source text."; return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
            player = try AVAudioPlayer(contentsOf: url)
            guard segment.start < (player?.duration ?? 0) else { throw PackageError(message: "This excerpt starts after the audio file ends.") }
            player?.currentTime = max(0, segment.start - 0.2)
            guard player?.play() == true else { throw PackageError(message: "Audio playback couldn’t start.") }
            playingID = segment.id
            let length = min(segment.end + 0.2, player?.duration ?? segment.end) - max(0, segment.start - 0.2)
            stopTask = Task { try? await Task.sleep(for: .seconds(max(0.1, length))); if !Task.isCancelled { stop() } }
        } catch { audioError = error.localizedDescription }
    }
    func stop() {
        stopTask?.cancel()
        player?.stop()
        playingID = nil
    }
    func stamp(_ seconds: Double) -> String { String(format: "%d:%02d", Int(seconds)/60, Int(seconds)%60) }
    func saveDraft(_ text: String, for person: Person, sources: [String]) {
        state.drafts[person.id] = SavedDraft(text: text, sourceIDs: sources)
        save()
    }
    func compose(for person: Person, from selected: [Note]) -> String {
        let checked = selected.filter { available($0.id) && state.reviewed.contains($0.id) && !state.excluded.contains($0.id) && !isPrivate($0) }
        guard !checked.isEmpty else { return "" }
        return "Hi \(person.first),\n\nFrom \(title):\n\n" + checked.map { "• " + text($0) }.joined(separator: "\n")
    }
    func shareText(_ selected: Set<String>) -> String {
        let included = shareableNotes.filter { selected.contains($0.id) }
        guard !included.isEmpty else { return "" }
        return title + "\n\n" + included.map { note in
            let assignment = note.owner != nil ? "\(owner(note)): " : ""
            let date = due(note).isEmpty ? "" : " (Due \(due(note)))"
            return "• " + assignment + text(note) + date
        }.joined(separator: "\n")
    }
    func section(_ note: Note) -> String {
        if notes?.actionItems.contains(where: { $0.id == note.id }) == true { return "Next step" }
        if notes?.decisions.contains(where: { $0.id == note.id }) == true { return "Decision" }
        return "Summary"
    }
    func search(_ query: String) -> [SearchHit] {
        let queryWords = Self.tokens(query); guard !queryWords.isEmpty else { return [] }
        var hits: [SearchHit] = []
        for note in visibleNotes {
            let score = queryWords.intersection(Self.tokens(text(note))).count
            if score > 0 { hits.append(SearchHit(id: "note:" + note.id, note: note, segment: nil, score: score * 3)) }
        }
        for segment in availableSegments {
            let score = queryWords.intersection(Self.tokens(segment.text)).count
            if score > 0 { hits.append(SearchHit(id: "segment:" + segment.id, note: nil, segment: segment, score: score * 2)) }
        }
        return Array(hits.sorted { $0.score == $1.score ? $0.id < $1.id : $0.score > $1.score }.prefix(20))
    }
    static func tokens(_ text: String) -> Set<String> {
        let stop: Set<String> = ["what", "when", "where", "which", "who", "how", "did", "does", "was", "were", "the", "and", "for", "that", "this", "with", "from", "about", "have", "has", "our", "your", "you", "can", "could", "would", "will", "let", "its", "are", "any", "some", "then", "they", "their", "into", "just", "them"]
        return Set(text.lowercased().components(separatedBy: CharacterSet.alphanumerics.inverted).filter { $0.count > 2 && !stop.contains($0) }.map { $0.hasSuffix("s") && $0.count > 4 ? String($0.dropLast()) : $0 })
    }

    // MARK: Review clues

    private func makeFlags(_ note: Note, package: MeetingPackage) -> [ReviewFlag] {
        let sources = package.transcript.segments.filter { note.sources.map(\.segmentId).contains($0.id) }
        var flags: [ReviewFlag] = []
        func add(_ id: String, _ title: String, _ detail: String, _ ids: [String]? = nil) { flags.append(ReviewFlag(id: note.id + ":" + id, title: title, detail: detail, segmentIDs: ids ?? sources.map(\.id))) }
        if note.sources.isEmpty { add("source", "No linked source", "No transcript moment was linked to this note. Search the conversation before relying on it.") }
        if (note.confidence ?? 1) < 0.8 { add("confidence", "Check wording", "This note was generated with low confidence. Check it against the source.") }
        if sources.contains(where: { ($0.words ?? []).contains { ($0.confidence ?? 1) < 0.6 || !($0.alternatives ?? []).isEmpty } }) {
            add("words", "Some words were unclear", "The speech recognizer supplied uncertain words or alternatives. Read the alternatives or listen before correcting a name, amount, or date.")
        }
        if containsPrivateLanguage(([note.text] + sources.map(\.text)).joined(separator: " ")) || (note.sensitivity != nil && note.sensitivity != "none") { add("privacy", "This may be private", "Personal or confidential language appears in the note or its source. It is excluded from sharing by default.") }
        if note.owner != nil && sources.contains(where: { segment in ["probably", "at some point", "maybe", "might", "we could"].contains { segment.text.lowercased().contains($0) } }) { add("tentative", "Was this a commitment?", "The source contains tentative language. Confirm whether an owner and deadline were actually agreed.") }
        if note.owner != nil, let last = sources.last, let index = package.transcript.segments.firstIndex(where: { $0.id == last.id }), index + 1 < package.transcript.segments.count {
            let next = package.transcript.segments[index + 1]
            if next.text.lowercased().contains("thank you"), let person = package.calendar?.event.attendees.first(where: { next.text.localizedCaseInsensitiveContains($0.first) }), note.owner?.name != person.name { add("owner", "Check owner", "The next speaker addresses \(person.name), while the note names \(note.owner?.name ?? "another owner"). This is a clue to review, not a confirmed reassignment.", sources.map(\.id) + [next.id]) }
        }
        let datePattern = "(?i)\\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\\s+\\d{1,2}(?:st|nd|rd|th)?\\b"
        func dates(_ text: String) -> Set<String> {
            guard let regex = try? NSRegularExpression(pattern: datePattern) else { return [] }
            return Set(regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap { Range($0.range, in: text).map { String(text[$0]).lowercased().replacingOccurrences(of: "(?:st|nd|rd|th)$", with: "", options: .regularExpression) } })
        }
        let originalDates = dates(note.text)
        if !originalDates.isEmpty {
            let latestSource = sources.map(\.end).max() ?? 0
            let topic = Self.tokens(note.text).subtracting(["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"])
            let later = package.transcript.segments.filter { $0.start > latestSource && !dates($0.text).isEmpty && dates($0.text).isDisjoint(with: originalDates) && !topic.intersection(Self.tokens($0.text)).isEmpty }
            let freezeUpdates = note.text.localizedCaseInsensitiveContains("code freeze") ? package.transcript.segments.filter {
                $0.start > latestSource && $0.text.range(of: #"\bcode freeze\b.*\b\d{1,2}(?:st|nd|rd|th)\b"#, options: [.regularExpression, .caseInsensitive]) != nil
            } : []
            let updates = later + freezeUpdates
            if !updates.isEmpty { add("later", "Check date", "A later moment changes the dates discussed. Compare the exchange with this note before saving.", sources.map(\.id) + updates.map(\.id)) }
        }
        return flags
    }
    func announce(_ text: String) {
        toast = text
        Task {
            try? await Task.sleep(for: .seconds(2.5))
            if toast == text { toast = nil }
        }
    }
    func haptic() { UIImpactFeedbackGenerator(style: .soft).impactOccurred() }
}
