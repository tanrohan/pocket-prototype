// Topics and reply drafts derived from the notes and transcript.
import Foundation

// MARK: - Topics

struct MeetingTopic: Identifiable {
    let id: String
    let title: String
    let symbol: String
    let noteIDs: [String]
    let segmentIDs: [String]
}

// MARK: - Reply drafts

struct ReplySeed: Identifiable {
    let id: String
    let recordingKey: String
    let text: String
    let sourceIDs: [String]
    var noteID: String? = nil
    var fullDraft = false
    var priorityAnswerID: String? = nil
}

// MARK: - Topic grouping

@MainActor extension MeetingStore {
    func focusEvidence(for note: Note) -> Segment? {
        if let answer = launchDateAnswer(for: note), let latest = answer.latest { return latest.source }
        let original = Set(note.sources.map(\.segmentId))
        let evidence = clip(Array(original.union(flags(note).flatMap(\.segmentIDs))))
        return evidence.last { !original.contains($0.id) } ?? evidence.first
    }

    // Lightweight, local topic grouping. Labels describe matching content, not inferred recipient interests.
    var meetingTopics: [MeetingTopic] {
        struct Rule {
            let id: String
            let title: String
            let symbol: String
            let terms: [String]
            var dated = false
            func matches(_ value: String) -> Bool {
                let value = value.lowercased()
                let matched = terms.contains { value.contains($0) }
                guard dated else { return matched }
                let dates = [
                    "date", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
                    "january", "february", "march", "april", "may ", "june", "july", "august", "september",
                    "october", "november", "december", "week", "tomorrow"
                ]
                return matched && dates.contains { value.contains($0) }
            }
        }
        let rules = [
            Rule(id: "launch", title: "Launch date", symbol: "calendar", terms: ["launch", "release", "ship"], dated: true),
            Rule(id: "opening", title: "Opening date", symbol: "calendar", terms: ["opening", "open the", "will open"], dated: true),
            Rule(id: "freeze", title: "Code freeze", symbol: "snowflake", terms: ["code freeze", "freeze code"]),
            Rule(id: "pricing", title: "Pricing", symbol: "tag", terms: ["pricing", "price", "per seat", "trial"]),
            Rule(id: "security", title: "Security", symbol: "lock.shield", terms: ["pen test", "security", "sharing permission", "sharing issue"]),
            Rule(id: "rollout", title: "Rollout", symbol: "arrow.up.forward", terms: ["rollout", "migration", "migrate", "snapshot"]),
            Rule(id: "design", title: "Design", symbol: "pencil.and.outline", terms: ["onboarding", "icons", "empty state", "dark mode", "keyboard navigation", "design"]),
            Rule(id: "marketing", title: "Launch materials", symbol: "doc.text.image", terms: ["blog", "press", "launch email", "customer stor", "launch video", "screenshots", "website hero"]),
            Rule(id: "webinar", title: "Webinar", symbol: "video", terms: ["webinar"]),
            Rule(id: "engineering", title: "Engineering", symbol: "wrench.and.screwdriver", terms: ["bug", "offline", "sync engine", "blocker"]),
            Rule(id: "invitations", title: "Invitations", symbol: "envelope", terms: ["invitation", "invite"]),
            Rule(id: "catering", title: "Catering", symbol: "fork.knife", terms: ["catering", "caterer", "menu"])
        ]
        let publicNotes = visibleNotes.filter { !isPrivate($0) }
        let blocked = Set(allNotes.filter { isPrivate($0) || state.excluded.contains($0.id) }.flatMap { $0.sources.map(\.segmentId) })
        let publicSegments = availableSegments.filter { !blocked.contains($0.id) && !containsPrivateLanguage($0.text) }
        var result: [MeetingTopic] = []
        var grouped: Set<String> = []
        for rule in rules {
            let matching = publicNotes.filter { rule.matches(text($0)) }
            let excerpts = publicSegments.filter { rule.matches($0.text) }
            guard !matching.isEmpty || !excerpts.isEmpty else { continue }
            grouped.formUnion(matching.map(\.id))
            result.append(MeetingTopic(id: rule.id, title: rule.title, symbol: rule.symbol, noteIDs: matching.map(\.id), segmentIDs: excerpts.map(\.id)))
        }
        // Unrecognized topics still have useful, data-derived entry points for arbitrary imported recordings.
        for note in publicNotes where !grouped.contains(note.id) {
            let words = text(note).split(separator: " ")
            let title = words.prefix(5).joined(separator: " ").trimmingCharacters(in: .punctuationCharacters)
            result.append(MeetingTopic(id: "note:" + note.id, title: title, symbol: "text.bubble", noteIDs: [note.id], segmentIDs: note.sources.map(\.segmentId)))
        }
        return result
    }
    func topicNotes(_ topic: MeetingTopic) -> [Note] {
        let candidates = visibleNotes.filter { topic.noteIDs.contains($0.id) && !isPrivate($0) }
        return candidates.sorted { a, b in
            let aDecision = notes?.decisions.contains { $0.id == a.id } == true
            let bDecision = notes?.decisions.contains { $0.id == b.id } == true
            if aDecision != bDecision { return aDecision }
            return (allNotes.firstIndex { $0.id == a.id } ?? 0) < (allNotes.firstIndex { $0.id == b.id } ?? 0)
        }
    }
    func topicEvidence(_ topic: MeetingTopic) -> Segment? {
        if let first = topicNotes(topic).first, let evidence = focusEvidence(for: first) { return evidence }
        return clip(topic.segmentIDs).last
    }
    func canDraftSource(_ segment: Segment) -> Bool {
        guard availableSegments.contains(where: { $0.id == segment.id }), !containsPrivateLanguage(segment.text) else { return false }
        return !allNotes.contains { note in note.sources.contains { $0.segmentId == segment.id } && (isPrivate(note) || state.excluded.contains(note.id)) }
    }
    func replySeed(for segment: Segment) -> ReplySeed? {
        guard canDraftSource(segment), let key = package?.key else { return nil }
        return ReplySeed(id: "source:" + segment.id, recordingKey: key, text: "“\(segment.text)”", sourceIDs: [segment.id])
    }
    func replySeed(for note: Note) -> ReplySeed? {
        guard shareableNotes.contains(where: { $0.id == note.id }), let key = package?.key else { return nil }
        return ReplySeed(id: "note:" + note.id, recordingKey: key, text: text(note), sourceIDs: note.sources.map(\.segmentId), noteID: note.id)
    }
    func canUseReply(_ seed: ReplySeed) -> Bool {
        guard package?.key == seed.recordingKey else { return false }
        if let priorityID = seed.priorityAnswerID {
            guard let answer = priorityDateAnswer, answer.id == priorityID,
                  let current = priorityReplySeed(for: answer), current.id == seed.id,
                  current.text == seed.text, current.sourceIDs == seed.sourceIDs else { return false }
        }
        // A draft opened while processing must not retain a date superseded by the ending.
        if seed.priorityAnswerID == nil, seed.noteID == nil, transcriptReady, let answer = priorityDateAnswer, answer.hasUpdate, let latest = answer.latest {
            let olderIDs = Set(answer.moments.dropLast().map { $0.source.id })
            if !olderIDs.isDisjoint(with: seed.sourceIDs) && !seed.sourceIDs.contains(latest.source.id) { return false }
        }
        if let id = seed.noteID { return shareableNotes.contains { $0.id == id && text($0) == seed.text } }
        let linked = clip(seed.sourceIDs)
        return !linked.isEmpty && linked.count == Set(seed.sourceIDs).count && linked.allSatisfy { canDraftSource($0) }
    }
    func replyText(for person: Person, seed: ReplySeed) -> String {
        guard canUseReply(seed) else { return "" }
        if seed.fullDraft { return seed.text }
        if seed.priorityAnswerID != nil { return "Hi \(person.first),\n\n\(seed.text)" }
        if seed.noteID == nil, seed.sourceIDs.count == 1, let source = clip(seed.sourceIDs).first {
            let uncertainSpeaker = allNotes.contains { note in
                note.sources.contains { $0.segmentId == source.id } && detectedFlags(note).contains { $0.id.hasSuffix(":owner") }
            }
            let attribution = speakerName(source.speaker) + (uncertainSpeaker ? " (speaker needs checking)" : "")
            return "Hi \(person.first),\n\n\(attribution): \(seed.text)"
        }
        return "Hi \(person.first),\n\nFrom \(title):\n\n\(seed.text)"
    }
    func confirmedReply(_ text: String, seed: ReplySeed, confirmed: Bool) -> String? {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard confirmed, transcriptReady, canUseReply(seed), !value.isEmpty else { return nil }
        return value
    }
}
